ALTER TABLE tenants ADD COLUMN alternate_emails JSON DEFAULT NULL;
