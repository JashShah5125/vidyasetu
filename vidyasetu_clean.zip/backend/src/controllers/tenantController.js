const tenantService = require('../services/tenantService');

const getTenants = async (req, res) => {
    try {
        const { page = 1, limit = 10, search = '', status = '', plan = '' } = req.query;
        const offset = (page - 1) * limit;

        const result = await tenantService.getTenants(limit, offset, search, status, plan);
        
        res.status(200).json({
            status: 'success',
            data: result.data,
            pagination: {
                total: result.total,
                page: Number(page),
                limit: Number(limit)
            },
            filters: {
                statuses: result.available_statuses
            }
        });
    } catch (error) {
        console.error('Error fetching tenants:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
};

const getTenantById = async (req, res) => {
    try {
        const { id } = req.params;
        const tenant = await tenantService.getTenantById(id);
        
        if (!tenant) {
            return res.status(404).json({ status: 'error', message: 'Tenant not found' });
        }

        res.status(200).json({ status: 'success', data: tenant });
    } catch (error) {
        console.error('Error fetching tenant details:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
};

const createTenant = async (req, res) => {
    try {
        // Validate request body
        const { 
            name, legal_name, slug, adminEmail, planId, address, city, state, pincode, 
            panNo, gstNo, mobile, timezone, billingCycle, alternate_emails, leadId,
            discount, finalPrice, tax, invoiceNumber, maxBranches, maxStaffUsers, maxStudents, maxParents, 
            maxTeachers, maxStorage, maxFileSize, maxSmsCredits, maxWhatsappMsgs
        } = req.body;
        
        // Data Validation Regex
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const mobileRegex = /^[0-9]{10}$/;
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        const gstRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
        const pincodeRegex = /^[0-9]{6}$/;
        const slugRegex = /^[a-z0-9-]+$/;

        // Compulsory Fields Validation
        if (!name || !name.trim()) {
            return res.status(400).json({ status: 'error', message: 'Institute / Coaching Name is compulsory' });
        }
        if (!slug || !slug.trim()) {
            return res.status(400).json({ status: 'error', message: 'Custom Subdomain Slug is compulsory' });
        }
        if (!slugRegex.test(slug.trim())) {
            return res.status(400).json({ status: 'error', message: 'Invalid format: Slug can only contain lowercase letters, numbers, and hyphens' });
        }
        if (!address || !address.trim()) {
            return res.status(400).json({ status: 'error', message: 'Address Line 1 is compulsory' });
        }
        if (!city || !city.trim()) {
            return res.status(400).json({ status: 'error', message: 'City is compulsory' });
        }
        if (!state || !state.trim()) {
            return res.status(400).json({ status: 'error', message: 'State is compulsory' });
        }
        if (!pincode || !pincodeRegex.test(pincode.trim())) {
            return res.status(400).json({ status: 'error', message: 'PIN Code is compulsory and must be exactly 6 digits' });
        }
        if (!adminEmail || !emailRegex.test(adminEmail.trim())) {
            return res.status(400).json({ status: 'error', message: 'Admin Email is compulsory and must be a valid email address without invalid special characters' });
        }

        // Check if admin email already exists in users table (Bug 18 fix)
        const existingUser = await userModel.findUserByEmail(adminEmail.trim().toLowerCase());
        if (existingUser && existingUser.length > 0) {
            return res.status(409).json({ status: 'error', message: 'An account with this email address already exists. Please use a different Admin Email.' });
        }

        const cleanMobile = (mobile || '').replace(/[^0-9]/g, '');
        if (!cleanMobile || cleanMobile.length < 10) {
            return res.status(400).json({ status: 'error', message: 'Primary Mobile Number is compulsory and must be at least 10 digits' });
        }
        if (!planId) {
            return res.status(400).json({ status: 'error', message: 'Subscription Plan is compulsory' });
        }
        if (!billingCycle) {
            return res.status(400).json({ status: 'error', message: 'Billing Cycle is compulsory' });
        }

        // Optional Format Validations
        if (panNo && !panRegex.test(panNo.toUpperCase())) {
            return res.status(400).json({ status: 'error', message: 'Invalid format: PAN Number must be 10 alphanumeric characters (e.g., ABCDE1234F)' });
        }
        if (gstNo && !gstRegex.test(gstNo.toUpperCase())) {
             return res.status(400).json({ status: 'error', message: 'Invalid format: GSTIN is incorrectly formatted' });
        }

        let logoUrl = null;
        if (req.file) {
            logoUrl = `/uploads/tenants/logo/${req.file.filename}`;
        }

        let parsedAltEmails = null;
        if (alternate_emails) {
            try { parsedAltEmails = JSON.parse(alternate_emails); } catch (e) {}
        }

        const parseNum = (val) => (val === undefined ? undefined : (val === '' || val === 'null' || val === null || isNaN(Number(val)) ? null : Number(val)));
        const parseStr = (val) => (val === undefined ? undefined : (val === '' || val === 'null' || val === null ? null : String(val).trim()));
        
        const result = await tenantService.createTenantWithAdmin({
            name, legal_name, slug, adminEmail, planId, address, city, state, pincode, panNo, gstNo, mobile, timezone, billingCycle, logoUrl, alternateEmails: parsedAltEmails,
            discount: parseNum(discount),
            finalPrice: parseNum(finalPrice),
            tax: parseNum(tax),
            invoiceNumber,
            maxBranches: parseNum(maxBranches),
            maxStaffUsers: parseNum(maxStaffUsers),
            maxStudents: parseNum(maxStudents),
            maxParents: parseNum(maxParents),
            maxTeachers: parseNum(maxTeachers),
            maxStorage: parseStr(maxStorage),
            maxFileSize: parseStr(maxFileSize),
            maxSmsCredits: parseNum(maxSmsCredits),
            maxWhatsappMsgs: parseNum(maxWhatsappMsgs)
        }, leadId ? Number(leadId) : null);

        const responseData = { ...result };
        if (process.env.NODE_ENV === 'production') {
            // Never leak the auto-generated password outside development.
            delete responseData.temporaryPassword;
        }

        res.status(201).json({ status: 'success', message: 'Tenant created successfully', data: responseData });
    } catch (error) {
        console.error('Error creating tenant:', error);
        if (error.statusCode === 409 || error.message === 'Tenant slug already exists' || error.message === 'Lead has already been converted' || (error.message && error.message.includes('already exists'))) {
            return res.status(409).json({ status: 'error', message: error.message });
        }
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
};

const updateTenantStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        const validStatuses = [0, 1, 2, 3, '0', '1', '2', '3', 'active', 'inactive', 'suspended', 'deactivated', 'draft', 'trialing', 'deleted'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ status: 'error', message: 'Invalid status. Expected 0 (inactive), 1 (active), 2 (draft), or 3 (deleted)' });
        }

        const success = await tenantService.updateTenantStatus(id, status);
        if (!success) {
            return res.status(404).json({ status: 'error', message: 'Tenant not found' });
        }

        res.status(200).json({ status: 'success', message: `Tenant status updated successfully` });
    } catch (error) {
        console.error('Error updating tenant status:', error);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
};

const updateTenant = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name, legal_name, slug, adminEmail, planId, address, city, state, pincode, panNo, gstNo, mobile, timezone, billingCycle, alternate_emails,
            discount, finalPrice, tax, invoiceNumber, maxBranches, maxStaffUsers, maxStudents, maxParents, 
            maxTeachers, maxStorage, maxFileSize, maxSmsCredits, maxWhatsappMsgs
        } = req.body;

        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const mobileRegex = /^[0-9]{10}$/;
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        const gstRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
        const pincodeRegex = /^[0-9]{6}$/;

        if (name !== undefined && !name.trim()) return res.status(400).json({ status: 'error', message: 'Institute Name cannot be empty' });
        if (address !== undefined && !address.trim()) return res.status(400).json({ status: 'error', message: 'Address Line 1 cannot be empty' });
        if (city !== undefined && !city.trim()) return res.status(400).json({ status: 'error', message: 'City cannot be empty' });
        if (state !== undefined && !state.trim()) return res.status(400).json({ status: 'error', message: 'State cannot be empty' });
        if (pincode !== undefined && (!pincode.trim() || !pincodeRegex.test(pincode.trim()))) return res.status(400).json({ status: 'error', message: 'PIN Code must be exactly 6 digits' });
        if (adminEmail && !emailRegex.test(adminEmail.trim())) return res.status(400).json({ status: 'error', message: 'Invalid format: Admin Email is incorrectly formatted or contains invalid special characters' });
        const cleanMobile = mobile ? mobile.replace(/[^0-9]/g, '') : '';
        if (mobile && cleanMobile.length < 10) return res.status(400).json({ status: 'error', message: 'Invalid format: Mobile Number must be at least 10 digits' });
        if (panNo && !panRegex.test(panNo.toUpperCase())) return res.status(400).json({ status: 'error', message: 'Invalid format: PAN Number must be 10 alphanumeric characters' });
        if (gstNo && !gstRegex.test(gstNo.toUpperCase())) return res.status(400).json({ status: 'error', message: 'Invalid format: GSTIN is incorrectly formatted' });

        let logoUrl;
        console.log("DEBUG: updateTenant req.file =", req.file, "req.body.logo =", req.body.logo, "req.body.removeLogo =", req.body.removeLogo);
        if (req.file) {
            logoUrl = `/uploads/tenants/logo/${req.file.filename}`;
        } else if (req.body.removeLogo === 'true') {
            logoUrl = null;
        }

        let parsedAltEmails;
        if (alternate_emails) {
            try { parsedAltEmails = JSON.parse(alternate_emails); } catch (e) {}
        }

        const parseNum = (val) => (val === undefined ? undefined : (val === '' || val === 'null' || val === null || isNaN(Number(val)) ? null : Number(val)));
        const parseStr = (val) => (val === undefined ? undefined : (val === '' || val === 'null' || val === null ? null : String(val).trim()));

        const success = await tenantService.updateTenant(id, {
            name, legal_name, slug, adminEmail, planId, address, city, state, pincode, panNo, gstNo, mobile, timezone, billingCycle, alternateEmails: parsedAltEmails, logoUrl,
            discount: parseNum(discount),
            finalPrice: parseNum(finalPrice),
            tax: parseNum(tax),
            invoiceNumber,
            maxBranches: parseNum(maxBranches),
            maxStaffUsers: parseNum(maxStaffUsers),
            maxStudents: parseNum(maxStudents),
            maxParents: parseNum(maxParents),
            maxTeachers: parseNum(maxTeachers),
            maxStorage: parseStr(maxStorage),
            maxFileSize: parseStr(maxFileSize),
            maxSmsCredits: parseNum(maxSmsCredits),
            maxWhatsappMsgs: parseNum(maxWhatsappMsgs)
        });

        if (!success) {
            return res.status(404).json({ status: 'error', message: 'Tenant not found' });
        }

        res.status(200).json({ status: 'success', message: 'Tenant updated successfully', data: { logoUrl } });
    } catch (error) {
        console.error('Error updating tenant:', error);
        if (error.message === 'Tenant slug already exists') {
            return res.status(409).json({ status: 'error', message: error.message });
        }
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
};

module.exports = {
    getTenants,
    getTenantById,
    createTenant,
    updateTenantStatus,
    updateTenant
};
