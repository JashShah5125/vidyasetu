const pool = require('../config/db');

const normalizeTenantStatus = (val) => {
    if (val === undefined || val === null || val === '' || val === 'All' || val === 'all') return null;
    if (typeof val === 'number') return [0, 1, 2, 3].includes(val) ? val : null;
    const s = String(val).trim().toLowerCase();
    if (s === '1' || s === 'active') return 1;
    if (s === '0' || s === 'inactive' || s === 'suspended' || s === 'deactivated' || s === 'expired' || s === 'canceled') return 0;
    if (s === '2' || s === 'draft' || s === 'trialing') return 2;
    if (s === '3' || s === 'deleted') return 3;
    return null;
};

const getTenants = async (limit = 10, offset = 0, search = '', status = '', plan = '') => {
    // Fetch warning days setting
    const [settingsRows] = await pool.query(`SELECT value FROM platform_settings WHERE category = 'billing' AND key_name = 'plan_expiry_warning_days'`);
    const expiryDays = settingsRows.length > 0 ? Number(settingsRows[0].value) : 15;

    const normStatus = normalizeTenantStatus(status);

    let query = `
        SELECT t.*, t.owner_name as legal_name, t.primary_email as contact_email, t.owner_mobile as contact_phone,
               u.name as admin_name, u.email as admin_email,
               (SELECT COUNT(*) FROM branches b WHERE b.tenant_id = t.id) as branch_count,
               (SELECT COUNT(*) FROM users u2 WHERE u2.tenant_id = t.id) as user_count,
               sp.name as plan_name, t.plan_id as subscription_id,
               t.subscription_discount, t.subscription_final_price, t.subscription_tax, t.subscription_invoice_number,
               t.override_max_branches, t.override_max_staff_users, t.override_max_students, t.override_max_parents,
               t.override_max_teachers, t.override_max_storage, t.override_max_file_size, t.override_max_sms_credits, t.override_max_whatsapp_msgs,
               (DATEDIFF(t.end_date, CURRENT_DATE) <= ${expiryDays} AND DATEDIFF(t.end_date, CURRENT_DATE) >= 0 AND t.status = 1) AS is_expiring_soon
        FROM tenants t
        LEFT JOIN users u ON t.primary_admin_user_id = u.id
        LEFT JOIN subscription_plans sp ON t.plan_id = sp.id
        WHERE t.tenant_type = 'customer' AND t.id != 1
    `;
    const params = [];

    if (search) {
        query += ` AND (t.name LIKE ? OR t.slug LIKE ? OR t.owner_name LIKE ?)`;
        const searchPattern = `%${search}%`;
        params.push(searchPattern, searchPattern, searchPattern);
    }

    if (normStatus !== null) {
        query += ` AND t.status = ?`;
        params.push(normStatus);
    } else {
        // By default exclude soft-deleted tenants if no specific status requested
        query += ` AND t.status != 3`;
    }

    if (plan && plan !== 'All') {
        query += ` AND t.plan_id = ?`;
        params.push(plan);
    }

    query += ` ORDER BY t.created_at DESC LIMIT ? OFFSET ?`;
    params.push(Number(limit), Number(offset));

    const [rows] = await pool.query(query, params);
    
    // Get total count for pagination
    let countQuery = `
        SELECT COUNT(*) as total 
        FROM tenants t
        LEFT JOIN subscription_plans sp ON t.plan_id = sp.id
        WHERE t.tenant_type = 'customer' AND t.id != 1
    `;
    const countParams = [];
    
    if (search) {
        countQuery += ` AND (t.name LIKE ? OR t.slug LIKE ? OR t.owner_name LIKE ?)`;
        const searchPattern = `%${search}%`;
        countParams.push(searchPattern, searchPattern, searchPattern);
    }

    if (normStatus !== null) {
        countQuery += ` AND t.status = ?`;
        countParams.push(normStatus);
    } else {
        countQuery += ` AND t.status != 3`;
    }

    if (plan && plan !== 'All') {
        countQuery += ` AND t.plan_id = ?`;
        countParams.push(plan);
    }

    const [countRows] = await pool.query(countQuery, countParams);
    
    // Get unique statuses for dynamic filtering (excluding deleted)
    const [statusRows] = await pool.query(`SELECT DISTINCT status FROM tenants WHERE tenant_type = 'customer' AND id != 1`);
    
    return {
        data: rows,
        total: countRows[0].total,
        available_statuses: statusRows.map(r => r.status)
    };
};

const getTenantById = async (id) => {
    const query = `
        SELECT t.*, t.owner_name as legal_name, t.primary_email as contact_email, t.owner_mobile as contact_phone, t.address_line1, t.city, t.state, t.country, t.pincode as postal_code,
               u.name as admin_name, u.email as admin_email,
               t.subscription_discount, t.subscription_final_price, t.subscription_tax, t.subscription_invoice_number,
               t.override_max_branches, t.override_max_staff_users, t.override_max_students, t.override_max_parents,
               t.override_max_teachers, t.override_max_storage, t.override_max_file_size, t.override_max_sms_credits, t.override_max_whatsapp_msgs
        FROM tenants t
        LEFT JOIN users u ON t.primary_admin_user_id = u.id
        WHERE t.id = ?
    `;
    const [rows] = await pool.query(query, [id]);
    return rows[0];
};

const checkSlugExists = async (slug) => {
    const [rows] = await pool.query('SELECT id FROM tenants WHERE slug = ?', [slug]);
    return rows.length > 0;
};

const updateTenantStatus = async (id, status) => {
    const normStatus = normalizeTenantStatus(status);
    if (normStatus === null) {
        throw new Error('Invalid status code');
    }
    const [result] = await pool.query('UPDATE tenants SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [normStatus, id]);
    return result.affectedRows > 0;
};

const updateTenant = async (id, data) => {
    let query = 'UPDATE tenants SET updated_at = CURRENT_TIMESTAMP';
    const params = [];

    const fieldMap = {
        name: 'name',
        legal_name: 'owner_name',
        slug: 'slug',
        planId: 'plan_id',
        address: 'address_line1',
        city: 'city',
        state: 'state',
        pincode: 'pincode',
        panNo: 'pan_number',
        gstNo: 'gst_number',
        timezone: 'timezone',
        billingCycle: 'billing_cycle',
        alternateEmails: 'alternate_emails',
        discount: 'subscription_discount',
        finalPrice: 'subscription_final_price',
        tax: 'subscription_tax',
        invoiceNumber: 'subscription_invoice_number',
        maxBranches: 'override_max_branches',
        maxStaffUsers: 'override_max_staff_users',
        maxStudents: 'override_max_students',
        maxParents: 'override_max_parents',
        maxTeachers: 'override_max_teachers',
        maxStorage: 'override_max_storage',
        maxFileSize: 'override_max_file_size',
        maxSmsCredits: 'override_max_sms_credits',
        maxWhatsappMsgs: 'override_max_whatsapp_msgs'
    };

    for (const [key, dbField] of Object.entries(fieldMap)) {
        if (data[key] !== undefined) {
            query += `, ${dbField} = ?`;
            if (key === 'alternateEmails' && data[key]) {
                params.push(JSON.stringify(data[key]));
            } else {
                params.push(data[key]);
            }
        }
    }

    if (data.logoUrl !== undefined) {
        query += `, logo_url = ?`;
        params.push(data.logoUrl);
    }

    query += ' WHERE id = ?';
    params.push(id);

    const [result] = await pool.query(query, params);
    
    // If adminEmail or owner_mobile is provided, update the primary contact info in tenants
    if (data.adminEmail || data.mobile) {
        let contactQuery = 'UPDATE tenants SET updated_at = CURRENT_TIMESTAMP';
        const contactParams = [];
        if (data.adminEmail !== undefined) {
            contactQuery += ', primary_email = ?';
            contactParams.push(data.adminEmail);
        }
        if (data.mobile !== undefined) {
            contactQuery += ', owner_mobile = ?';
            contactParams.push(data.mobile);
        }
        contactQuery += ' WHERE id = ?';
        contactParams.push(id);
        
        await pool.query(contactQuery, contactParams);
        
        // Also update primary user email/mobile if possible
        if (data.adminEmail) {
            await pool.query(
                'UPDATE users u JOIN tenants t ON u.id = t.primary_admin_user_id SET u.email = ?, u.updated_at = CURRENT_TIMESTAMP WHERE t.id = ?',
                [data.adminEmail, id]
            );
        }
    }

    if (data.legal_name !== undefined) {
        await pool.query(
            'UPDATE users u JOIN tenants t ON u.id = t.primary_admin_user_id SET u.name = ?, u.updated_at = CURRENT_TIMESTAMP WHERE t.id = ?',
            [data.legal_name, id]
        );
    }

    return result.affectedRows > 0;
};

module.exports = {
    getTenants,
    getTenantById,
    checkSlugExists,
    updateTenantStatus,
    updateTenant
};
