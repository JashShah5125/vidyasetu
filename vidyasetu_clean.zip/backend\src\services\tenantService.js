const pool = require('../config/db');
const tenantModel = require('../models/tenantModel');
const leadModel = require('../models/leadModel');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { sendTenantWelcomeEmail } = require('./mailService');

const generateTemporaryPassword = () => {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    const bytes = crypto.randomBytes(12);
    const suffix = Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join('');
    return `VS-${suffix}`;
};

const createTenantWithAdmin = async (tenantData, leadId = null) => {
    const { 
        name, legal_name, slug, adminEmail, mobile, planId, address, city, state, pincode, panNo, gstNo,
        timezone, billingCycle, logoUrl, alternateEmails,
        startDate, endDate, renewalDate,
        discount, finalPrice, tax, invoiceNumber, maxBranches, maxStaffUsers, maxStudents, maxParents, 
        maxTeachers, maxStorage, maxFileSize, maxSmsCredits, maxWhatsappMsgs
    } = tenantData;
    const temporaryPassword = generateTemporaryPassword();
    
    // Check if slug exists
    const slugExists = await tenantModel.checkSlugExists(slug);
    if (slugExists) {
        throw new Error('Tenant slug already exists');
    }

    // Check if admin email already exists for any user
    if (adminEmail) {
        const [existingUsers] = await pool.query(
            'SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND deleted_at IS NULL',
            [adminEmail.trim()]
        );
        if (existingUsers && existingUsers.length > 0) {
            const err = new Error('An account with this email address already exists.');
            err.statusCode = 409;
            throw err;
        }
    }

    // Auto-calculate subscription start, end and renewal dates
    const finalStartDate = startDate || new Date().toISOString().split('T')[0];
    let finalEndDate = endDate || null;
    if (!finalEndDate && finalStartDate) {
        const d = new Date(finalStartDate);
        const cycle = (billingCycle || 'annual').toLowerCase();
        if (cycle === 'yearly' || cycle === 'annual') {
            d.setFullYear(d.getFullYear() + 1);
        } else if (cycle === 'quarterly') {
            d.setMonth(d.getMonth() + 3);
        } else if (cycle === 'half-yearly' || cycle === 'half_yearly') {
            d.setMonth(d.getMonth() + 6);
        } else if (cycle === 'lifetime') {
            d.setFullYear(d.getFullYear() + 99);
        } else {
            d.setMonth(d.getMonth() + 1);
        }
        finalEndDate = d.toISOString().split('T')[0];
    }
    const finalRenewalDate = renewalDate || finalEndDate;

    // Generate unique internal code
    const code = 'T-' + Math.random().toString(36).substring(2, 8).toUpperCase();

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        // Lock the source lead (if converting from a lead) to prevent double conversion
        let lockedLead = null;
        if (leadId) {
            lockedLead = await leadModel.lockLeadForConversion(leadId, connection);
            if (!lockedLead) {
                throw new Error('Lead not found');
            }
            if (lockedLead.deleted_at) {
                throw new Error('Lead has been deleted');
            }
            if (lockedLead.converted_tenant_id) {
                throw new Error('Lead has already been converted');
            }
        }

        // Check if admin email already exists (Bug 18 fix)
        const [existingUsers] = await connection.query(
            'SELECT id FROM users WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))',
            [adminEmail]
        );
        if (existingUsers && existingUsers.length > 0) {
            const err = new Error('An account with this email address already exists. Please use a different Admin Email.');
            err.statusCode = 409;
            throw err;
        }

        // 1. Create Tenant (including profile and subscription)
        const [tenantResult] = await connection.query(
            `INSERT INTO tenants (
                name, slug, code, tenant_type, status, owner_name, primary_email, owner_mobile, plan_id, 
                subscription_status, start_date, end_date, renewal_date, address_line1, city, state, pincode, pan_number, gst_number, timezone, billing_cycle, 
                logo_url, alternate_emails, subscription_discount, subscription_final_price, subscription_tax, 
                subscription_invoice_number, override_max_branches, override_max_staff_users, override_max_students, 
                override_max_parents, override_max_teachers, override_max_storage, override_max_file_size, 
                override_max_sms_credits, override_max_whatsapp_msgs
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                name, slug, code, 'customer', 1, legal_name || name, adminEmail, mobile || '', planId || null, 
                'active', finalStartDate, finalEndDate, finalRenewalDate, address || null, city || null, state || null, pincode || null, panNo || null, gstNo || null,
                timezone || 'Asia/Kolkata', billingCycle || 'annual', logoUrl || null, 
                alternateEmails ? JSON.stringify(alternateEmails) : null,
                discount !== undefined ? discount : null, 
                finalPrice !== undefined ? finalPrice : null, 
                tax !== undefined ? tax : null, 
                invoiceNumber || null, 
                maxBranches !== undefined ? maxBranches : null, 
                maxStaffUsers !== undefined ? maxStaffUsers : null, 
                maxStudents !== undefined ? maxStudents : null, 
                maxParents !== undefined ? maxParents : null, 
                maxTeachers !== undefined ? maxTeachers : null, 
                maxStorage || null, 
                maxFileSize || null, 
                maxSmsCredits !== undefined ? maxSmsCredits : null, 
                maxWhatsappMsgs !== undefined ? maxWhatsappMsgs : null
            ]
        );
        const tenantId = tenantResult.insertId;

        // Link the source lead to the new tenant record
        if (leadId) {
            await connection.query(
                'UPDATE tenants SET source_lead_id = ? WHERE id = ?',
                [leadId, tenantId]
            );
        }

        // 3. Resolve / create the global admin role (flat RBAC: one role
        //    definition per code, shared by every tenant).
        const ADMIN_ROLE_CODE = 'inst_admin';
        let [roles] = await connection.query('SELECT id, code FROM roles WHERE code = ?', [ADMIN_ROLE_CODE]);
        if (roles.length === 0) {
            await connection.query(
                'INSERT IGNORE INTO roles (name, code, description, is_system) VALUES (?, ?, ?, ?)',
                ['Institute Admin', ADMIN_ROLE_CODE, 'Full access to institute', 0]
            );
            [roles] = await connection.query('SELECT id, code FROM roles WHERE code = ?', [ADMIN_ROLE_CODE]);
        }
        const roleId = roles[0].id;
        const roleCode = roles[0].code;

        // 4. Create Admin User (user_type mirrors the assigned role code so the
        //    users.user_type column stays consistent for listings/indexes).
        const passwordHash = await bcrypt.hash(temporaryPassword, 10);
        const [userResult] = await connection.query(
            'INSERT INTO users (tenant_id, name, email, password_hash, user_type, status, must_change_password, password_generated_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)',
            [tenantId, legal_name || 'Tenant Admin', adminEmail, passwordHash, roleCode, 'active', 1]
        );
        const adminUserId = userResult.insertId;

        // 5. Update primary admin on tenant
        await connection.query(
            'UPDATE tenants SET primary_admin_user_id = ? WHERE id = ?',
            [adminUserId, tenantId]
        );

        // 6. Assign Role
        await connection.query(
            'INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)',
            [adminUserId, roleId]
        );

        // 7. Subscription handled in Step 1

        // 7b. Mark the source lead as converted
        if (leadId) {
            await leadModel.markConverted(leadId, tenantId, connection, planId || null);
        }

        // 8. Audit Log
        await connection.query(
            'INSERT INTO audit_logs (tenant_id, user_id, action, entity_type, entity_id, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
            [tenantId, adminUserId, 'CREATE', 'tenant', tenantId, '127.0.0.1'] // Placeholder IP
        );

        await connection.commit();

        if (process.env.NODE_ENV !== 'production') {
            console.log(`[DEV] Tenant "${name}" created. Admin email: ${adminEmail}. Temporary password: ${temporaryPassword}`);
        }

        let welcomeEmailSent = false;
        try {
            await sendTenantWelcomeEmail({
                recipientEmail: adminEmail,
                ownerName: legal_name || name,
                instituteName: name,
                temporaryPassword
            });
            welcomeEmailSent = true;
        } catch (emailError) {
            console.error('Tenant created but welcome email failed:', emailError.message);
        }

        return { tenantId, adminUserId, logoUrl, welcomeEmailSent, temporaryPassword, convertedFromLeadId: leadId || null };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
};

const getTenants = async (limit, offset, search, status, plan) => {
    return await tenantModel.getTenants(limit, offset, search, status, plan);
};

const getTenantById = async (id) => {
    return await tenantModel.getTenantById(id);
};

const updateTenantStatus = async (id, status, userId = null, ipAddress = '127.0.0.1') => {
    try {
        const existing = await tenantModel.getTenantById(id);
        const oldStatus = existing ? existing.status : null;
        const newStatus = Number(status);
        if (oldStatus !== newStatus) {
            await pool.query(
                'INSERT INTO audit_logs (tenant_id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [id, userId || null, 'STATUS_CHANGE', 'tenant', id, JSON.stringify({ status: oldStatus }), JSON.stringify({ status: newStatus }), ipAddress]
            );
        }
    } catch (auditError) {
        console.error('Audit log failed, proceeding anyway:', auditError.message);
    }
    return await tenantModel.updateTenantStatus(id, status);
};

const updateTenant = async (id, tenantData, userId = null, ipAddress = '127.0.0.1') => {
    const existingTenant = await tenantModel.getTenantById(id);
    if (!existingTenant) return null;

    if (tenantData.slug && existingTenant.slug !== tenantData.slug) {
        const slugExists = await tenantModel.checkSlugExists(tenantData.slug);
        if (slugExists) {
            throw new Error('Tenant slug already exists');
        }
    }

    const formatDateVal = (d) => {
        if (!d) return null;
        if (typeof d === 'string' && /^\d{4}-\d{2}-\d{2}/.test(d)) return d.substring(0, 10);
        const date = new Date(d);
        if (isNaN(date.getTime())) return null;
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    };

    const isNumericField = (key) => [
        'status', 'discount', 'finalPrice', 'tax', 'maxBranches', 'maxStaffUsers',
        'maxStudents', 'maxParents', 'maxTeachers', 'maxSmsCredits', 'maxWhatsappMsgs'
    ].includes(key);

    const normalizeVal = (key, val) => {
        if (val === undefined || val === null || val === '') return null;
        if (['startDate', 'endDate', 'renewalDate'].includes(key)) return formatDateVal(val);
        if (isNumericField(key)) {
            const num = Number(val);
            return isNaN(num) ? String(val).trim() : num;
        }
        if (Array.isArray(val) || (typeof val === 'object' && val !== null)) return JSON.stringify(val);
        return String(val).trim();
    };

    const fieldMap = {
        name: 'name',
        legal_name: 'owner_name',
        slug: 'slug',
        status: 'status',
        planId: 'plan_id',
        address: 'address_line1',
        city: 'city',
        state: 'state',
        pincode: 'pincode',
        panNo: 'pan_number',
        gstNo: 'gst_number',
        timezone: 'timezone',
        billingCycle: 'billing_cycle',
        startDate: 'start_date',
        endDate: 'end_date',
        renewalDate: 'renewal_date',
        alternateEmails: 'alternate_emails',
        discount: 'subscription_discount',
        finalPrice: 'subscription_final_price',
        tax: 'subscription_tax',
        invoiceNumber: 'subscription_invoice_number',
        maxBranches: 'override_max_branches',
        maxStaffUsers: 'override_max_staff_users',
        maxStudents: 'override_max_students',
        maxParents: 'override_max_parents',
        maxTeachers: 'override_max_teachers',
        maxStorage: 'override_max_storage',
        maxFileSize: 'override_max_file_size',
        maxSmsCredits: 'override_max_sms_credits',
        maxWhatsappMsgs: 'override_max_whatsapp_msgs'
    };

    const changes = {};
    const oldValues = {};

    for (const [key, dbField] of Object.entries(fieldMap)) {
        if (tenantData[key] !== undefined) {
            const newValNorm = normalizeVal(key, tenantData[key]);
            const oldValNorm = normalizeVal(key, existingTenant[dbField]);

            if (newValNorm !== oldValNorm) {
                changes[key] = newValNorm;
                oldValues[key] = oldValNorm;
            }
        }
    }

    if (Object.keys(changes).length > 0) {
        try {
            await pool.query(
                'INSERT INTO audit_logs (tenant_id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [id, userId || null, 'SETTINGS_UPDATE', 'tenant', id, JSON.stringify(oldValues), JSON.stringify(changes), ipAddress]
            );
        } catch (auditError) {
            console.error('Audit log failed, proceeding anyway:', auditError.message);
        }
    }

    return await tenantModel.updateTenant(id, tenantData);
};

module.exports = {
    createTenantWithAdmin,
    getTenants,
    getTenantById,
    updateTenantStatus,
    updateTenant
};
