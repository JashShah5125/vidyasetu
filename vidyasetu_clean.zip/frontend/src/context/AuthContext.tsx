import React, { createContext, useContext, useState, useEffect } from 'react';
import type { Role, UserProfile } from '../types';
import api from '../services/api';

interface AuthContextType {
  currentUser: UserProfile | null;
  isLoading: boolean;
  login: (email: string, password?: string) => Promise<boolean>;
  logout: () => Promise<void>;
  error: string | null;
  updateCurrentUser: (fields: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const normalizeRole = (userType: string | undefined): Role => {
  const t = (userType || '').trim().toLowerCase();
  if (!t) return 'inst-admin';
  // Backend stores snake_case user types (inst_admin, branch_admin, ...)
  return t.replace(/_/g, '-') as Role;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Try to load user from local storage initially
    const savedUser = localStorage.getItem('vs_current_user');
    const accessToken = localStorage.getItem('vs_token');
    if (savedUser && accessToken) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch {
        localStorage.removeItem('vs_current_user');
      }
    } else if (savedUser) {
      // Do not restore an authenticated UI state when its access token is gone.
      localStorage.removeItem('vs_current_user');
      localStorage.removeItem('vs_refresh_token');
    }
    setIsLoading(false);

    const handleForceLogout = () => {
      setCurrentUser(null);
      localStorage.removeItem('vs_current_user');
    };

    window.addEventListener('auth:force-logout', handleForceLogout);
    return () => {
      window.removeEventListener('auth:force-logout', handleForceLogout);
    };
  }, []);

  const updateCurrentUser = (fields: Partial<UserProfile>) => {
    setCurrentUser(prev => {
      if (!prev) return prev;
      const updated = { ...prev, ...fields };
      localStorage.setItem('vs_current_user', JSON.stringify(updated));
      return updated;
    });
  };

  const login = async (email: string, password?: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await api.post('/auth/login', { email, password });
      
      if (response.data.status === 'success') {
        const { token, refreshToken, user } = response.data.data;
        
        // Store tokens
        localStorage.setItem('vs_token', token);
        if (refreshToken) {
          localStorage.setItem('vs_refresh_token', refreshToken);
        }

        // Map backend user to frontend UserProfile
        const profile: UserProfile = {
          id: user.id ? String(user.id) : undefined,
          name: user.name,
          email: user.email,
          role: (user.isSaasAdmin ? 'saas-admin' : normalizeRole(user.userType)) as Role,
          tenantId: user.tenantId !== undefined && user.tenantId !== null ? String(user.tenantId) : undefined,
          tenantName: user.tenantName || (user.isSaasAdmin ? 'Vidya Setu Platform' : 'Institute Name'),
          branch: user.branch || '',
          branchId: user.branchId ? String(user.branchId) : undefined,
          branchCode: user.branchCode || undefined,
          mustChangePassword: Boolean(user.mustChangePassword)
        };

        setCurrentUser(profile);
        localStorage.setItem('vs_current_user', JSON.stringify(profile));
        return true;
      }
      return false;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Login failed. Please check your credentials.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      const refreshToken = localStorage.getItem('vs_refresh_token');
      if (refreshToken) {
        await api.post('/auth/logout', { refreshToken });
      }
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      // Clear all auth state regardless of API success
      localStorage.removeItem('vs_token');
      localStorage.removeItem('vs_refresh_token');
      localStorage.removeItem('vs_current_user');
      setCurrentUser(null);
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ currentUser, isLoading, login, logout, error, updateCurrentUser }}>
      {children}
    </AuthContext.Provider>
  );
};

const defaultAuthContext: AuthContextType = {
  currentUser: null,
  isLoading: false,
  login: async () => false,
  logout: async () => {},
  error: null,
  updateCurrentUser: () => {},
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    return defaultAuthContext;
  }
  return context;
};

