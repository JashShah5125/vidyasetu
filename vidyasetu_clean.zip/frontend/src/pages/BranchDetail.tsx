import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Select } from '../components/ui/Select';
import { ChevronLeft, MapPin, Building, Clock, Landmark, ShieldAlert, GraduationCap, Plus, Trash2, BookOpen, ChevronDown, ChevronRight } from 'lucide-react';
import type { Branch } from '../types';
import { branchApi, toBranch } from '../services/branchApi';

// Type for a course-program mapping on a branch
interface BranchCourseMapping {
  id: string;
  courseCode: string;
  courseName: string;
  programs: string[];
  programCodes?: string[];
}

export const BranchDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { branches, setBranches, courses, addToast, currentUser } = useApp();

  const isNew = id === 'new';
  const existingBranch = branches.find(b => b.id === id || b.code === id);
  const isReadOnly = currentUser?.role === 'branch-admin'
    ? (existingBranch ? existingBranch.name !== currentUser.branch : true)
    : false;
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);
  const [loadedIdentifier, setLoadedIdentifier] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser?.role === 'branch-admin' && isNew) {
      addToast('Access denied: Branch Admins cannot create branches.');
      navigate('/branches');
    }
  }, [currentUser, isNew, navigate, addToast]);

  const [activeTab, setActiveTab] = useState<'general' | 'admin' | 'courses' | 'operations'>('general');

  const [formData, setFormData] = useState<Partial<Branch>>({
    name: '', code: '', admin: '', adminEmail: '', adminMobile: '', capacity: 0, status: 'Active',
    address: '', email: '', phone: '', operatingHours: '', programs: [],
    altEmails: [], defaultEmail: '',
    bankDetails: { accountName: '', accountNumber: '', ifsc: '', bankName: '' }
  });

  const [altEmailInput, setAltEmailInput] = useState('');

  // Course-program mappings state
  const [courseMappings, setCourseMappings] = useState<BranchCourseMapping[]>([]);
  const [expandedCourse, setExpandedCourse] = useState<string | null>(null);

  // Modal state
  const [isCourseModalOpen, setCourseModalOpen] = useState(false);
  const [editingMappingId, setEditingMappingId] = useState<string | null>(null);

  // Course modal form state
  const [modalCourseCode, setModalCourseCode] = useState('');

  // Convert the backend's flat program-mappings list into the grouped
  // BranchCourseMapping[] shape the Courses & Programs tab renders.
  const buildCourseMappings = (mappings: any[]): BranchCourseMapping[] => {
    const map = new Map<string, BranchCourseMapping>();
    for (const m of mappings || []) {
      const key = m.courseCode || m.course_name || String(m.courseId);
      if (!map.has(key)) {
        map.set(key, {
          id: `cm-${key}`,
          courseCode: m.courseCode || m.course_code || '',
          courseName: m.courseName || m.course_name || '',
          programs: [],
          programCodes: [],
        });
      }
      if (m.programName || m.program_name) {
        map.get(key)!.programs.push(m.programName || m.program_name);
        map.get(key)!.programCodes!.push(m.programCode || m.program_code || '');
      }
    }
    return Array.from(map.values());
  };

  const getCoursePrograms = (course?: any): { name: string; code: string; id: string }[] => {
    if (!course) return [];
    if (Array.isArray(course.programDetails) && course.programDetails.length > 0) {
      return course.programDetails.map((p: any, idx: number) => ({
        name: typeof p === 'string' ? p : (p.name || ''),
        code: typeof p === 'string' ? '' : (p.code || ''),
        id: String(typeof p === 'string' ? p : (p.id || p.code || p.name || idx))
      })).filter(p => Boolean(p.name));
    }
    if (Array.isArray(course.programs) && course.programs.length > 0) {
      return course.programs.map((p: any, idx: number) => ({
        name: typeof p === 'string' ? p : (p.name || ''),
        code: typeof p === 'string' ? '' : (p.code || ''),
        id: String(typeof p === 'string' ? p : (p.id || p.code || p.name || idx))
      })).filter(p => Boolean(p.name));
    }
    return [];
  };

  // Build the payload sent to the backend. Program mappings carry course/program
  // codes so the backend can resolve them to real DB ids (mock courses use string ids).
  const buildPayload = () => {
    const programMappings = courseMappings
      .map(mapping => {
        const course = courses.find(c => c.code === mapping.courseCode);
        const storedCodes = (mapping.programCodes || []).filter(Boolean);
        const programCodes = storedCodes.length > 0
          ? storedCodes
          : (mapping.programs || [])
              .map(p => {
                const pName = typeof p === 'string' ? p : (p as any)?.name;
                const found = course?.programDetails?.find(pd => pd.name === pName);
                return found?.code || '';
              })
              .filter((c): c is string => Boolean(c));
        return { courseCode: mapping.courseCode, programCodes };
      })
      .filter(m => m.courseCode && m.programCodes.length > 0);

    return {
      name: formData.name as string,
      code: formData.code as string,
      status: formData.status,
      capacity: formData.capacity,
      address: formData.address,
      email: formData.email,
      phone: formData.phone,
      operatingHours: formData.operatingHours,
      bankDetails: formData.bankDetails,
      admin: formData.admin,
      adminEmail: formData.adminEmail,
      adminMobile: formData.adminMobile,
      altEmails: formData.altEmails || [],
      defaultEmail: formData.defaultEmail || '',
      programMappings,
      replaceMappings: true,
    };
  };

  useEffect(() => {
    if (existingBranch && !isNew && !loadedIdentifier) {
      setFormData(prev => ({
        ...prev,
        ...existingBranch,
        bankDetails: existingBranch.bankDetails || prev.bankDetails,
        altEmails: existingBranch.altEmails || [],
        defaultEmail: existingBranch.defaultEmail || '',
      }));
    }
  }, [existingBranch, isNew, loadedIdentifier]);

  // When opening an existing branch, load the authoritative record from the API.
  useEffect(() => {
    if (isNew || isLoadingDetail) return;
    let cancelled = false;
    setIsLoadingDetail(true);
    branchApi.getByCode(id!)
      .then(res => {
        const row = res.data;
        const branch = toBranch(row);
        if (cancelled) return;
        setFormData(prev => ({
          ...prev,
          ...branch,
          bankDetails: branch.bankDetails || prev.bankDetails,
          altEmails: branch.altEmails || [],
          defaultEmail: branch.defaultEmail || '',
        }));
        setCourseMappings(buildCourseMappings(row.programMappings || []));
        setLoadedIdentifier(branch.id || branch.code);
        setBranches(prev => {
          const exists = prev.some(b => (b.id || b.code) === (branch.id || branch.code));
          return exists ? prev.map(b => (b.id || b.code) === (branch.id || branch.code) ? branch : b) : [...prev, branch];
        });
      })
      .catch(() => {
        if (!cancelled) addToast('Failed to load branch details.');
      })
      .finally(() => {
        if (!cancelled) setIsLoadingDetail(false);
      });
    return () => { cancelled = true; };
  }, [id, isNew]);

  const validateStep = (tab: 'general' | 'admin' | 'courses' | 'operations'): { isValid: boolean; error?: string } => {
    if (tab === 'general') {
      if (!formData.name?.trim()) {
        return { isValid: false, error: 'Please enter the Branch Name.' };
      }
      if (!formData.code?.trim()) {
        return { isValid: false, error: 'Please enter the Branch Code.' };
      }
    }
    if (tab === 'admin') {
      if (!formData.admin?.trim()) {
        return { isValid: false, error: 'Please enter the Branch Head / Admin Name.' };
      }
      if (!formData.adminEmail?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.adminEmail.trim())) {
        return { isValid: false, error: 'Please enter a valid Admin Email address.' };
      }
      const cleanPhone = (formData.adminMobile || '').replace(/[^0-9]/g, '');
      if (cleanPhone.length < 10) {
        return { isValid: false, error: 'Please enter a valid 10-digit Admin Mobile number.' };
      }
    }
    return { isValid: true };
  };

  const handleTabChange = (targetTab: 'general' | 'admin' | 'courses' | 'operations') => {
    if (isReadOnly) {
      setActiveTab(targetTab);
      return;
    }
    const order: Array<'general' | 'admin' | 'courses' | 'operations'> = ['general', 'admin', 'courses', 'operations'];
    const currentIdx = order.indexOf(activeTab);
    const targetIdx = order.indexOf(targetTab);
    if (targetIdx > currentIdx) {
      for (let i = 0; i < targetIdx; i++) {
        const res = validateStep(order[i]);
        if (!res.isValid) {
          addToast(res.error || 'Please fill required details in previous steps.', 'error');
          setActiveTab(order[i]);
          return;
        }
      }
    }
    setActiveTab(targetTab);
  };

  const handleNext = (nextTab: 'general' | 'admin' | 'courses' | 'operations') => {
    if (!isReadOnly) {
      const res = validateStep(activeTab);
      if (!res.isValid) {
        addToast(res.error || 'Please complete all required fields before proceeding.', 'error');
        return;
      }
    }
    setActiveTab(nextTab);
  };

  const handleSave = async () => {
    const generalCheck = validateStep('general');
    if (!generalCheck.isValid) {
      addToast(generalCheck.error || 'Please complete General Setup details.', 'error');
      setActiveTab('general');
      return;
    }
    const adminCheck = validateStep('admin');
    if (!adminCheck.isValid) {
      addToast(adminCheck.error || 'Please complete Admin & Access details.', 'error');
      setActiveTab('admin');
      return;
    }
    try {
      const payload = buildPayload();
      if (isNew) {
        await branchApi.create(payload);
      } else {
        await branchApi.update(loadedIdentifier || existingBranch?.id || existingBranch?.code || id!, payload);
      }
      addToast(isNew ? 'New branch created successfully.' : 'Branch details updated successfully.');
      await loadBranchList();
      navigate('/branches');
    } catch {
      addToast('Failed to save branch. Please try again.');
    }
  };

  const loadBranchList = async () => {
    try {
      const result = await branchApi.list({ limit: 1000 });
      setBranches((result.data || []).map((row: any) => toBranch(row)));
    } catch {
      /* keep current list on failure */
    }
  };

  // Already-mapped course codes
  const mappedCourseCodes = new Set(courseMappings.map(cm => cm.courseCode));

  // Available courses to add (not yet mapped)
  const availableCourses = useMemo(() => {
    return courses.filter(c => !mappedCourseCodes.has(c.code));
  }, [courses, mappedCourseCodes]);

  // Open modal to add a new course
  const handleOpenAddCourse = () => {
    setEditingMappingId(null);
    setModalCourseCode('');
    setCourseModalOpen(true);
  };

  // Save the course mapping
  const handleSaveCourse = () => {
    if (!modalCourseCode) return;
    const course = courses.find(c => c.code === modalCourseCode);
    if (!course) return;

    const newMapping: BranchCourseMapping = {
      id: `cm-${Date.now()}`,
      courseCode: course.code,
      courseName: course.name,
      programs: [],
      programCodes: [],
    };
    setCourseMappings(prev => [...prev, newMapping]);
    setExpandedCourse(newMapping.id);
    setCourseModalOpen(false);
    addToast(`"${course.name}" has been added to this branch.`);
  };

  const handleRemoveCourse = (mappingId: string) => {
    const mapping = courseMappings.find(cm => cm.id === mappingId);
    setCourseMappings(prev => prev.filter(cm => cm.id !== mappingId));
    addToast(`"${mapping?.courseName}" removed from branch.`);
  };

  const handleToggleProgram = (mappingId: string, programName: string) => {
    setCourseMappings(prev => prev.map(cm => {
      if (cm.id !== mappingId) return cm;
      const hasProg = cm.programs.includes(programName);
      if (hasProg) {
        const index = cm.programs.indexOf(programName);
        return {
          ...cm,
          programs: cm.programs.filter(p => p !== programName),
          programCodes: (cm.programCodes || []).filter((_, i) => i !== index),
        };
      }
      const course = courses.find(c => c.code === cm.courseCode);
      const code = course?.programDetails?.find(pd => pd.name === programName)?.code || '';
      return {
        ...cm,
        programs: [...cm.programs, programName],
        programCodes: [...(cm.programCodes || []), code],
      };
    }));
  };

  if (!isNew && !existingBranch && !isLoadingDetail) {
    return <div className="p-8 text-center">Branch not found.</div>;
  }
  if (!isNew && isLoadingDetail) {
    return <div className="p-12 text-center text-slate-400">Loading branch details…</div>;
  }

  const tabClass = (tab: string) =>
    `px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors cursor-pointer select-none ${
      activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
    }`;

  return (
    <div className="w-full animate-fade-in">
      {isReadOnly && (
        <div className="mx-6 mt-4 p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm font-semibold text-amber-800 shadow-sm flex items-center gap-2">
          <ShieldAlert size={16} /> Read-Only Mode: Only Institute Owners can modify branch parameters.
        </div>
      )}
      <div className="flex flex-col gap-2 p-6 pb-0">
        <button onClick={() => navigate('/branches')} className="text-sm font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 w-fit transition-colors">
          <ChevronLeft size={16} /> Back to Branches
        </button>
        <div className="flex justify-between items-center">
          <h2 className="text-3xl font-display font-bold text-slate-900">
            {isNew ? 'Create New Branch' : `Manage Branch: ${formData.name}`}
          </h2>
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => navigate('/branches')}>
              {isReadOnly ? 'Back' : 'Cancel'}
            </Button>
            {!isReadOnly && (
              <Button variant="primary" onClick={handleSave} style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}>
                Save Branch Details
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="flex border-b border-slate-200 overflow-x-auto whitespace-nowrap scrollbar-none mt-6 px-6">
        <button type="button" onClick={() => handleTabChange('general')} className={tabClass('general')}>1. General Setup</button>
        <button type="button" onClick={() => handleTabChange('admin')} className={tabClass('admin')}>2. Admin &amp; Access</button>
        <button type="button" onClick={() => handleTabChange('courses')} className={tabClass('courses')}>
          3. Courses &amp; Programs
          {courseMappings.length > 0 && (
            <span className="ml-2 px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-[10px] font-bold">
              {courseMappings.length}
            </span>
          )}
        </button>
        <button type="button" onClick={() => handleTabChange('operations')} className={tabClass('operations')}>4. Operations &amp; Finance</button>
      </div>

      <fieldset disabled={isReadOnly} className="contents">
        <div className="grid grid-cols-1 gap-6 p-6 pt-6">

        {/* GENERAL TAB */}
        {activeTab === 'general' && (
          <div className="space-y-6">
            <Card>
              <div className="p-5 border-b border-slate-100 flex items-center gap-2">
                <Building size={18} className="text-blue-600" />
                <h3 className="font-bold text-slate-800">Basic Details</h3>
              </div>
              <div className="p-5 grid grid-cols-2 gap-4">
                <Input label="Branch Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g., Mumbai West" disabled={currentUser?.role === 'branch-admin'} />
                <Input label="Branch Code" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} placeholder="e.g., MUM-WEST" disabled={currentUser?.role === 'branch-admin'} />
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-widest">Status</label>
                  <select 
                    className="w-full h-11 px-3 border border-slate-200 rounded-lg text-sm bg-white disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
                    value={formData.status}
                    onChange={e => setFormData({...formData, status: e.target.value as any})}
                    disabled={currentUser?.role === 'branch-admin'}
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
                <Input label="Student Intake Capacity" type="number" value={formData.capacity} onChange={e => setFormData({...formData, capacity: parseInt(e.target.value) || 0})} />
              </div>
            </Card>

            <Card>
              <div className="p-5 border-b border-slate-100 flex items-center gap-2">
                <MapPin size={18} className="text-blue-600" />
                <h3 className="font-bold text-slate-800">Location & Contact</h3>
              </div>
              <div className="p-5 space-y-4">
                <Input label="Full Address" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} placeholder="Street, City, State, Pincode" />
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Branch Email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="contact@branch.com" />
                  <Input label="Branch Phone" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="022-XXXXXXX" />
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* ADMIN TAB */}
        {activeTab === 'admin' && (
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <div className="p-5 border-b border-slate-100 flex items-center gap-2 bg-slate-50/50 rounded-t-xl">
                <ShieldAlert size={18} className="text-indigo-600" />
                <h3 className="font-bold text-slate-800">Branch Admin</h3>
              </div>
              <div className="p-5 space-y-5">
                <p className="text-xs text-slate-500">The assigned administrator has full operational control over this branch.</p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input label="Admin Name" value={formData.admin} onChange={e => setFormData({...formData, admin: e.target.value})} placeholder="Full Name" disabled={currentUser?.role === 'branch-admin'} />
                  <Input label="Admin Mobile" value={formData.adminMobile} onChange={e => setFormData({...formData, adminMobile: e.target.value})} placeholder="For SMS alerts" disabled={currentUser?.role === 'branch-admin'} />
                </div>

                {/* Primary Admin Email */}
                <div>
                  <label className="text-xs font-bold text-slate-600 uppercase tracking-wide block mb-1.5">Admin Email</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="email"
                      className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:border-blue-400 disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
                      placeholder="primary@branch.com"
                      value={formData.adminEmail || ''}
                      onChange={e => setFormData({...formData, adminEmail: e.target.value})}
                      disabled={currentUser?.role === 'branch-admin'}
                    />
                    <button
                      type="button"
                      disabled={currentUser?.role === 'branch-admin'}
                      onClick={() => setFormData({...formData, defaultEmail: formData.adminEmail})}
                      className={`px-3 py-2 rounded-lg text-xs font-bold border transition-colors whitespace-nowrap ${
                        formData.defaultEmail === formData.adminEmail || !formData.defaultEmail
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300 cursor-default'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-slate-400 cursor-pointer'
                      } ${currentUser?.role === 'branch-admin' ? 'opacity-70 cursor-not-allowed' : ''}`}
                    >
                      {formData.defaultEmail === formData.adminEmail || !formData.defaultEmail ? '✓ Default' : 'Set Default'}
                    </button>
                  </div>
                </div>

                {/* Alternate Emails */}
                <div>
                  <label className="text-xs font-bold text-slate-600 uppercase tracking-wide block mb-2">Alternate Emails</label>

                  {/* Existing alt emails list */}
                  {(formData.altEmails || []).length > 0 && (
                    <div className="space-y-2 mb-3">
                      {(formData.altEmails || []).map((email, idx) => (
                        <div key={idx} className={`flex items-center gap-2 px-3 py-2 border rounded-lg transition-colors ${
                          formData.defaultEmail === email ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'
                        }`}>
                          <span className="flex-1 text-sm text-slate-700 truncate">{email}</span>
                          {formData.defaultEmail === email && (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded-full border border-emerald-200">DEFAULT</span>
                          )}
                          <button
                            type="button"
                            onClick={() => setFormData({...formData, defaultEmail: email})}
                            className={`text-xs font-semibold px-2 py-1 rounded border transition-colors ${
                              formData.defaultEmail === email
                                ? 'text-emerald-600 border-emerald-200 bg-emerald-50 cursor-default'
                                : 'text-slate-500 border-slate-200 hover:text-blue-600 hover:border-blue-200 hover:bg-blue-50'
                            }`}
                          >
                            {formData.defaultEmail === email ? '✓ Default' : 'Set Default'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const updated = (formData.altEmails || []).filter((_, i) => i !== idx);
                              const newDefault = formData.defaultEmail === email
                                ? (formData.adminEmail || '')
                                : formData.defaultEmail;
                              setFormData({...formData, altEmails: updated, defaultEmail: newDefault});
                            }}
                            className="text-red-400 hover:text-red-600 text-xs font-semibold px-2 py-1 rounded border border-transparent hover:border-red-200 hover:bg-red-50 transition-colors"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add new alt email */}
                  <div className="flex gap-2">
                    <input
                      type="email"
                      className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:border-blue-400 bg-white"
                      placeholder="Enter alternate email address..."
                      value={altEmailInput}
                      onChange={e => setAltEmailInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const email = altEmailInput.trim();
                          if (!email) {
                            addToast('Please enter an email address.');
                            return;
                          }
                          if ((formData.altEmails || []).includes(email)) {
                            addToast('This email is already in the alternate emails list.');
                            return;
                          }
                          setFormData({...formData, altEmails: [...(formData.altEmails || []), email]});
                          setAltEmailInput('');
                          addToast('Alternate email added.');
                        }
                      }}
                    />
                    <Button
                      variant="primary"
                      onClick={() => {
                        const email = altEmailInput.trim();
                        if (!email) {
                          addToast('Please enter an email address.');
                          return;
                        }
                        if ((formData.altEmails || []).includes(email)) {
                          addToast('This email is already in the alternate emails list.');
                          return;
                        }
                        setFormData({...formData, altEmails: [...(formData.altEmails || []), email]});
                        setAltEmailInput('');
                        addToast('Alternate email added.');
                      }}
                      style={{ backgroundColor: '#1e293b', color: 'white', borderColor: '#1e293b' }}
                      className="whitespace-nowrap"
                    >
                      + Add
                    </Button>
                  </div>
                  <p className="text-xs text-slate-400 mt-1.5">Press Enter or click Add. Notifications will be sent to the default email.</p>
                </div>

                <Button 
                  variant="secondary" 
                  className="w-full text-xs font-bold"
                  onClick={() => addToast('Login credentials and welcome email sent to branch admin.')}
                >
                  Send / Reset Login Credentials
                </Button>
              </div>
            </Card>
          </div>
        )}

        {/* COURSES & PROGRAMS TAB */}
        {activeTab === 'courses' && (
          <div className="space-y-4">
            {/* Header */}
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-slate-800">Courses & Programs Offered</h3>
                <p className="text-sm text-slate-500 mt-0.5">Map courses and their programs available at this branch with academic year availability.</p>
              </div>
              <Button
                variant="primary"
                onClick={handleOpenAddCourse}
                disabled={availableCourses.length === 0}
                style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}
                className="flex items-center gap-1.5 disabled:opacity-50"
              >
                <Plus size={16} /> Add Course
              </Button>
            </div>

            {courseMappings.length === 0 ? (
              <div className="bg-white border border-slate-200 border-dashed rounded-xl py-16 text-center">
                <GraduationCap size={40} className="mx-auto mb-3 text-slate-300" />
                <p className="font-semibold text-slate-600">No courses mapped to this branch yet.</p>
                <p className="text-sm text-slate-400 mt-1">Click "Add Course" to start mapping courses and their programs.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {courseMappings.map(mapping => (
                  <div key={mapping.id} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                    {/* Course Header Row */}
                    <div
                      className="flex items-center justify-between p-4 cursor-pointer hover:bg-slate-50 transition-colors"
                      onClick={() => setExpandedCourse(expandedCourse === mapping.id ? null : mapping.id)}
                    >
                      <div className="flex items-center gap-3">
                        {expandedCourse === mapping.id
                          ? <ChevronDown size={16} className="text-blue-600" />
                          : <ChevronRight size={16} className="text-slate-400" />
                        }
                        <BookOpen size={18} className="text-blue-600" />
                        <div>
                          <span className="font-bold text-slate-800">{mapping.courseName}</span>
                          <span className="ml-3 text-xs font-mono text-slate-400 uppercase">{mapping.courseCode}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-slate-500 font-medium">
                          {mapping.programs.length} program{mapping.programs.length !== 1 ? 's' : ''}
                        </span>
                        <button
                          onClick={e => { e.stopPropagation(); handleRemoveCourse(mapping.id); }}
                          className="text-red-400 hover:text-red-600 transition-colors p-1 rounded hover:bg-red-50"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    {/* Expanded: Programs List */}
                    {expandedCourse === mapping.id && (
                      <div className="border-t border-slate-100 bg-slate-50/50 p-5">
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Select available programs for this course</p>
                        <div className="flex flex-wrap gap-4">
                          {(() => {
                            const course = courses.find(c => c.code === mapping.courseCode || c.name === mapping.courseName);
                            const availableProgs = getCoursePrograms(course);
                            if (availableProgs.length === 0) {
                              return <p className="text-xs text-slate-400">No programs available in this course.</p>;
                            }
                            return availableProgs.map((prog) => {
                              const progName = prog.name;
                              const isChecked = mapping.programs.includes(progName);
                              return (
                                <label key={prog.id || progName} className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg shadow-sm cursor-pointer hover:border-blue-300 transition-colors">
                                  <input 
                                    type="checkbox" 
                                    checked={isChecked}
                                    onChange={() => handleToggleProgram(mapping.id, progName)}
                                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                                  />
                                  <span className="text-sm font-semibold text-slate-700">{progName}</span>
                                </label>
                              );
                            });
                          })()}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* OPERATIONS TAB */}
        {activeTab === 'operations' && (
          <div className="space-y-6">
            <Card>
              <div className="p-5 border-b border-slate-100 flex items-center gap-2">
                <Clock size={18} className="text-blue-600" />
                <h3 className="font-bold text-slate-800">Operating Hours</h3>
              </div>
              <div className="p-5">
                 <Input label="Standard Timings" value={formData.operatingHours} onChange={e => setFormData({...formData, operatingHours: e.target.value})} placeholder="e.g. 08:00 AM - 08:00 PM" />
              </div>
            </Card>

            <Card>
              <div className="p-5 border-b border-slate-100 flex items-center gap-2">
                <Landmark size={18} className="text-blue-600" />
                <h3 className="font-bold text-slate-800">Local Bank Details</h3>
              </div>
              <div className="p-5">
                <p className="text-xs text-slate-500 mb-4">Leave blank to use Institute's global collection account. Fill this only if this branch collects fees in a separate local account.</p>
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Bank Name" value={formData.bankDetails?.bankName} onChange={e => setFormData({...formData, bankDetails: {...formData.bankDetails!, bankName: e.target.value}})} disabled={currentUser?.role === 'branch-admin'} />
                  <Input label="Account Name" value={formData.bankDetails?.accountName} onChange={e => setFormData({...formData, bankDetails: {...formData.bankDetails!, accountName: e.target.value}})} disabled={currentUser?.role === 'branch-admin'} />
                  <Input label="Account Number" value={formData.bankDetails?.accountNumber} onChange={e => setFormData({...formData, bankDetails: {...formData.bankDetails!, accountNumber: e.target.value}})} disabled={currentUser?.role === 'branch-admin'} />
                  <Input label="IFSC Code" value={formData.bankDetails?.ifsc} onChange={e => setFormData({...formData, bankDetails: {...formData.bankDetails!, ifsc: e.target.value}})} disabled={currentUser?.role === 'branch-admin'} />
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
      </fieldset>

      {/* Bottom navigation */}
      <div className="flex justify-between items-center p-6 pt-0 border-t border-slate-200 mt-6 pb-6">
        <div>
          {activeTab === 'admin' && (
            <Button type="button" variant="secondary" onClick={() => setActiveTab('general')}>&larr; Back</Button>
          )}
          {activeTab === 'courses' && (
            <Button type="button" variant="secondary" onClick={() => setActiveTab('admin')}>&larr; Back</Button>
          )}
          {activeTab === 'operations' && (
            <Button type="button" variant="secondary" onClick={() => setActiveTab('courses')}>&larr; Back</Button>
          )}
        </div>
        <div className="flex gap-3">
          {activeTab === 'general' && (
            <Button type="button" variant="primary" onClick={() => handleNext('admin')} style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}>
              Next: Admin &amp; Access <ChevronLeft size={16} className="ml-2 rotate-180" />
            </Button>
          )}
          {activeTab === 'admin' && (
            <Button type="button" variant="primary" onClick={() => handleNext('courses')} style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}>
              Next: Courses &amp; Programs <ChevronLeft size={16} className="ml-2 rotate-180" />
            </Button>
          )}
          {activeTab === 'courses' && (
            <Button type="button" variant="primary" onClick={() => handleNext('operations')} style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}>
              Next: Operations &amp; Finance <ChevronLeft size={16} className="ml-2 rotate-180" />
            </Button>
          )}
          {activeTab === 'operations' && !isReadOnly && (
            <Button type="button" variant="primary" onClick={handleSave} style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}>
              Save Branch Details
            </Button>
          )}
        </div>
      </div>

      {/* ADD COURSE MODAL */}
      <Modal
        isOpen={isCourseModalOpen}
        onClose={() => setCourseModalOpen(false)}
        title="Add Course to Branch"
        size="md"
        footer={
          <>
            <Button variant="ghost" onClick={() => setCourseModalOpen(false)}>Cancel</Button>
            <Button
              variant="primary"
              onClick={handleSaveCourse}
              disabled={!modalCourseCode}
              style={{ backgroundColor: '#2563eb', color: 'white', borderColor: '#2563eb' }}
              className="disabled:opacity-50"
            >
              Add Course
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-500">Select an existing course to add to this branch. You can then configure which programs and academic years are offered.</p>
          
          {availableCourses.length === 0 ? (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800 font-medium">
              All available courses have already been added to this branch.
            </div>
          ) : (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-600 uppercase tracking-wide block">Select Course</label>
              <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden">
                {availableCourses.map(course => (
                  <label
                    key={course.code}
                    className={`flex items-start gap-3 p-4 cursor-pointer transition-colors ${
                      modalCourseCode === course.code ? 'bg-blue-50 border-l-4 border-l-blue-500' : 'hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="courseSelect"
                      className="mt-0.5 text-blue-600"
                      checked={modalCourseCode === course.code}
                      onChange={() => setModalCourseCode(course.code)}
                    />
                    <div>
                      <div className="font-semibold text-slate-800">{course.name}</div>
                      <div className="text-xs text-slate-500 mt-0.5 font-mono">{course.code} • {course.duration}</div>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {(course.programs || []).map(p => (
                          <span key={p} className="px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-medium">{p}</span>
                        ))}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      </Modal>

    </div>
  );
};
