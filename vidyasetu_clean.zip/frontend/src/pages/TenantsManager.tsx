import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../context/AppContext';
import { tenantService } from '../services/tenantService';
import { leadService } from '../services/leadService';
import { planService } from '../services/planService';
import { Card, CardHeader, CardTitle } from '../components/ui/Card';
import { Table } from '../components/ui/Table';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Pagination } from '../components/ui/Pagination';
import { 
  Plus, Upload, Trash, Trash2, ArrowLeft, X, 
  Image as ImageIcon, AlertTriangle, Check, Eye, Edit3, ShieldAlert,
  ChevronLeft, ChevronRight, Pencil 
} from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { getTenantStatus, getTenantStatusLabel } from '../types';

const formatDate = (dateStr: string | undefined): string => {
  if (!dateStr) return '';
  if (dateStr.includes('T')) {
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) {
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      return `${day}-${month}-${year}`;
    }
  }
  const cleanStr = dateStr.split('T')[0];
  const parts = cleanStr.split('-');
  if (parts.length === 3) {
    if (parts[0].length === 4) return `${parts[2]}-${parts[1]}-${parts[0]}`;
    return cleanStr;
  }
  return dateStr;
};

export const TenantsManager: React.FC<{ initialOpenCreate?: boolean }> = ({ initialOpenCreate }) => {
  const { addToast } = useApp();
  const navigate = useNavigate();
  const [showAddModal, setShowAddModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPlan, setFilterPlan] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  
  const [tenants, setTenants] = useState<any[]>([]);
  const [availablePlans, setAvailablePlans] = useState<any[]>([]);
  const [availableStatuses, setAvailableStatuses] = useState<string[]>([]);
  const [totalItems, setTotalItems] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const fetchTenants = async () => {
    try {
      setIsLoading(true);
      // Map frontend filters to backend expectations
      const statusFilter = filterStatus !== 'All' ? filterStatus : '';

      const result = await tenantService.getTenants({
        page: currentPage,
        limit: 10,
        search: searchTerm,
        status: statusFilter,
        plan: filterPlan !== 'All' ? filterPlan : undefined
      });
      setTenants(result.data || []);
      setTotalItems(result.pagination?.total || 0);
      if (result.filters?.statuses) {
        setAvailableStatuses(result.filters.statuses);
      }
    } catch (error) {
      console.error('Failed to fetch tenants:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setFilterPlan('All');
    setFilterStatus('All');
    setCurrentPage(1);
  };

  useEffect(() => {
    fetchTenants();
  }, [currentPage, searchTerm, filterStatus, filterPlan]);

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const res = await planService.getPlans(['Active']);
        setAvailablePlans(res.data || []);
      } catch (e) {
        console.error('Failed to fetch plans', e);
      }
    };
    fetchPlans();
  }, []);

  React.useEffect(() => {
    if (initialOpenCreate) {
      handleOpenAddModal();
    } else {
      setShowAddModal(false);
    }
  }, [initialOpenCreate]);

  // ── Lead-based conversion prefill ──
  const [searchParams] = useSearchParams();
  const [sourceLead, setSourceLead] = useState<any | null>(null);
  const [leadPrefillApplied, setLeadPrefillApplied] = useState(false);

  React.useEffect(() => {
    const leadId = searchParams.get('leadId');
    if (!leadId) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await leadService.getLead(leadId);
        if (!cancelled && res?.data) setSourceLead(res.data);
        else if (!cancelled) addToast('Could not load the linked lead', 'error');
      } catch (e) {
        console.error('Failed to load lead for conversion:', e);
        if (!cancelled) addToast('Could not load the linked lead for conversion', 'error');
      }
    })();
    return () => { cancelled = true; };
  }, [searchParams, addToast]);

  // Apply lead data to the create form once plans are available
  React.useEffect(() => {
    if (!sourceLead || leadPrefillApplied || availablePlans.length === 0) return;
    const lead = sourceLead;
    setName(lead.instituteName || '');
    setOwnerName(lead.contactPerson || '');
    setEmail(lead.email || '');
    setMobile(lead.mobile || '');
    setAddress(lead.addressLine1 || '');
    setCity(lead.city || '');
    setState(lead.state || '');
    setPincode(lead.pincode || '');
    setCustomSlug(lead.preferredSlug || '');
    if (lead.planId) setPlan(String(lead.planId));
    setShowSaved(false);
    setErrorMsg('');
    setShowAddModal(true);
    setActiveTab('profile');
    setLeadPrefillApplied(true);
  }, [sourceLead, leadPrefillApplied, availablePlans]);

  // Edit / Create / View mode trackers
  const [editingTenantId, setEditingTenantId] = useState<string | null>(null);
  const [isViewOnly, setIsViewOnly] = useState(false);
  const [tenantToDelete, setTenantToDelete] = useState<any | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Forms states
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [pincode, setPincode] = useState('');
  const [panNo, setPanNo] = useState('');
  const [timezone, setTimezone] = useState('Asia/Kolkata');
  const [billingCycle, setBillingCycle] = useState('annual');
  const [customSlug, setCustomSlug] = useState('');
  const [gstNo, setGstNo] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [plan, setPlan] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [defaultPassword, setDefaultPassword] = useState('');
  const [logoUploaded, setLogoUploaded] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [logoError, setLogoError] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);
  
  // Commercial states
  const [discount, setDiscount] = useState('');
  const [finalPrice, setFinalPrice] = useState('');
  const [tax, setTax] = useState('18');
  const [invoiceNumber, setInvoiceNumber] = useState('');

  // Override limit states
  const [ovMaxBranches, setOvMaxBranches] = useState('');
  const [ovMaxStaffUsers, setOvMaxStaffUsers] = useState('');
  const [ovMaxStudents, setOvMaxStudents] = useState('');
  const [ovMaxParents, setOvMaxParents] = useState('');
  const [ovMaxTeachers, setOvMaxTeachers] = useState('');
  const [ovMaxStorage, setOvMaxStorage] = useState('');
  const [ovMaxFileSize, setOvMaxFileSize] = useState('');
  const [ovMaxSmsCredits, setOvMaxSmsCredits] = useState('');
  const [ovMaxWhatsappMsgs, setOvMaxWhatsappMsgs] = useState('');

  // Alternate email lists states
  const [altEmails, setAltEmails] = useState<string[]>([]);
  const [defaultEmailIdx, setDefaultEmailIdx] = useState<number>(-1);
  


  const [showSaved, setShowSaved] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Horizontal tab navigation for the create/edit form
  const [activeTab, setActiveTab] = useState('profile');
  const formTabs = [
    { id: 'profile', label: '1. Institute Profile' },
    { id: 'admin', label: '2. Admin Credentials' },
    { id: 'plan', label: '3. Subscription Plan' },
    { id: 'commercial', label: '4. Commercial' },
    { id: 'limits', label: '5. Override Limits' }
  ];

  // Validation function per tab/step (enforcing compulsory fields)
  const validateStep = (tabId: string): { isValid: boolean; error?: string } => {
    if (tabId === 'profile') {
      if (!name.trim()) {
        return { isValid: false, error: 'Institute / Coaching Name is compulsory. Please enter a name.' };
      }
      if (!address.trim()) {
        return { isValid: false, error: 'Address Line 1 is compulsory. Please enter the institute address.' };
      }
      if (!city.trim()) {
        return { isValid: false, error: 'City is compulsory. Please enter the city.' };
      }
      if (!state.trim()) {
        return { isValid: false, error: 'State is compulsory. Please enter the state.' };
      }
      if (!pincode.trim() || !/^\d{6}$/.test(pincode.trim())) {
        return { isValid: false, error: 'PIN Code is compulsory and must be exactly 6 digits.' };
      }
      if (customSlug.trim() && !/^[a-zA-Z0-9-]+$/.test(customSlug.trim())) {
        return { isValid: false, error: 'Custom subdomain can only contain letters, numbers, and hyphens.' };
      }
      if (panNo.trim() && !/^[A-Za-z0-9]{10}$/.test(panNo.trim())) {
        return { isValid: false, error: 'PAN number must be a 10-character alphanumeric code (e.g. ABCDE1234F).' };
      }
      if (gstNo.trim() && !/^[A-Za-z0-9]{15}$/.test(gstNo.trim())) {
        return { isValid: false, error: 'GSTIN must be a 15-character alphanumeric code.' };
      }
    }

    if (tabId === 'admin') {
      if (!ownerName.trim()) {
        return { isValid: false, error: 'Owner / Primary Admin Name is compulsory.' };
      }
      const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      if (!email.trim() || !EMAIL_REGEX.test(email.trim())) {
        return { isValid: false, error: 'Admin Email Login is compulsory and must be a valid email address without invalid special characters (e.g. admin@institute.com).' };
      }
      for (const alt of altEmails) {
        if (alt && alt.trim() && !EMAIL_REGEX.test(alt.trim())) {
          return { isValid: false, error: `Alternate Email "${alt}" is invalid. Please enter a valid email address without invalid characters.` };
        }
      }
      const cleanMobile = mobile.replace(/[^0-9]/g, '');
      if (!mobile.trim() || cleanMobile.length < 10) {
        return { isValid: false, error: 'Primary Mobile Number is compulsory and must be at least 10 digits.' };
      }
    }

    if (tabId === 'plan') {
      if (!plan) {
        return { isValid: false, error: 'Subscription Plan is compulsory. Please select a tier.' };
      }
      if (!billingCycle) {
        return { isValid: false, error: 'Billing Cycle is compulsory. Please select a billing interval.' };
      }
      if (!startDate) {
        return { isValid: false, error: 'Plan Start Date is compulsory. Please enter a valid start date.' };
      }
    }

    return { isValid: true };
  };

  const canNavigateToTab = (targetTabId: string): { allowed: boolean; error?: string; firstInvalidTab?: string } => {
    if (isViewOnly) return { allowed: true };
    const tabOrder = ['profile', 'admin', 'plan', 'commercial', 'limits'];
    const targetIdx = tabOrder.indexOf(targetTabId);
    const currentIdx = tabOrder.indexOf(activeTab);

    if (targetIdx <= currentIdx) {
      return { allowed: true };
    }

    // Check all previous steps up to target
    for (let i = 0; i < targetIdx; i++) {
      const res = validateStep(tabOrder[i]);
      if (!res.isValid) {
        return { allowed: false, error: res.error, firstInvalidTab: tabOrder[i] };
      }
    }
    return { allowed: true };
  };

  const handleTabClick = (targetTabId: string) => {
    const check = canNavigateToTab(targetTabId);
    if (!check.allowed) {
      setErrorMsg(check.error || 'Please complete all required fields in the previous step before proceeding.');
      if (check.firstInvalidTab && check.firstInvalidTab !== activeTab) {
        setActiveTab(check.firstInvalidTab);
      }
      return;
    }
    setErrorMsg('');
    setActiveTab(targetTabId);
  };

  const handleNextStep = () => {
    const tabOrder = ['profile', 'admin', 'plan', 'commercial', 'limits'];
    const currentIdx = tabOrder.indexOf(activeTab);
    const currentValidation = validateStep(activeTab);
    if (!currentValidation.isValid) {
      setErrorMsg(currentValidation.error || 'Please complete all required fields before proceeding.');
      return;
    }
    setErrorMsg('');
    if (currentIdx < tabOrder.length - 1) {
      setActiveTab(tabOrder[currentIdx + 1]);
    }
  };

  const handlePrevStep = () => {
    const tabOrder = ['profile', 'admin', 'plan', 'commercial', 'limits'];
    const currentIdx = tabOrder.indexOf(activeTab);
    setErrorMsg('');
    if (currentIdx > 0) {
      setActiveTab(tabOrder[currentIdx - 1]);
    }
  };

  // Calculate Expiry date automatically based on Plan Duration
  const calculateExpiryDate = (startStr: string, selectedPlan: string) => {
    if (!startStr) return '';
    const date = new Date(startStr);
    if (isNaN(date.getTime())) return '';

    if (selectedPlan === 'Starter Trial') {
      date.setDate(date.getDate() + 14); // 14 Days free trial
    } else if (selectedPlan === 'Pro Enterprise') {
      date.setFullYear(date.getFullYear() + 1); // 1 Year (12 months)
    } else {
      date.setMonth(date.getMonth() + 1); // 1 Month (Growth Plan)
    }
    return date.toISOString().split('T')[0];
  };

  const expiryDate = calculateExpiryDate(startDate, plan);

  const autoFinalPrice = () => {
    let base = 0;
    if (plan === 'Growth Plan') {
      base = billingCycle === 'annual' ? 15000 * 12 : 15000;
    } else if (plan === 'Pro Enterprise') {
      base = billingCycle === 'annual' ? 30000 * 12 : 30000;
    }
    const d = parseFloat(discount) || 0;
    return Math.round(base - (base * d / 100)).toString();
  };

  const handleOpenAddModal = () => {
    setEditingTenantId(null);
    setIsViewOnly(false);
    
    setActiveTab('profile');
    setDefaultPassword('Generated securely after submission');
    
    setName('');
    setAddress('');
    setCity('');
    setState('');
    setPincode('');
    setPanNo('');
    setTimezone('Asia/Kolkata');
    setBillingCycle('annual');
    setCustomSlug('');
    setGstNo('');
    setOwnerName('');
    setEmail('');
    setMobile('');
    setPlan(availablePlans.length > 0 ? availablePlans[0].id.toString() : '');
    setStartDate(new Date().toISOString().split('T')[0]);
    setLogoUploaded(false);
    setLogoFile(null);
    setLogoPreview(null);
    setLogoError(false);
    setUploadProgress(0);
    setIsUploading(false);
    setAltEmails([]);
    setDefaultEmailIdx(-1);

    setDiscount('');
    setFinalPrice('');
    setTax('18');
    setInvoiceNumber('');
    setOvMaxBranches('');
    setOvMaxStaffUsers('');
    setOvMaxStudents('');
    setOvMaxParents('');
    setOvMaxTeachers('');
    setOvMaxStorage('');
    setOvMaxFileSize('');
    setOvMaxSmsCredits('');
    setOvMaxWhatsappMsgs('');

    setShowSaved(false);
    setErrorMsg('');
    
    setShowAddModal(true);
    setTimeout(() => {
      document.getElementById('tenant-form-top')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  };

  const handleLoadTenantForm = (t: any) => {
    setEditingTenantId(t.id);
    setActiveTab('profile');
    setName(t.name || '');
    setCustomSlug(t.slug || '');
    setGstNo(t.gst_number || '');
    setPanNo(t.pan_number || '');
    setAddress(t.address_line1 || '');
    setCity(t.city || '');
    setState(t.state || '');
    setPincode(t.pincode || '');
    setTimezone(t.timezone || 'Asia/Kolkata');
    setBillingCycle(t.billing_cycle || 'annual');
    setOwnerName(t.owner_name || t.legal_name || t.admin_name || '');
    setEmail(t.primary_email || t.contact_email || t.admin_email || '');
    setMobile(t.owner_mobile || t.contact_phone || '');
    setPlan(t.plan_id ? String(t.plan_id) : (t.planId ? String(t.planId) : (availablePlans.length > 0 ? availablePlans[0].id.toString() : '')));
    setStartDate(t.created_at ? t.created_at.split('T')[0] : (t.start_date ? t.start_date.split('T')[0] : new Date().toISOString().split('T')[0]));
    setLogoUploaded(!!t.logo_url);
    setLogoFile(null);
    setLogoPreview(t.logo_url || null);
    setLogoError(false);
    setDefaultPassword('********'); // Placeholder for edit/view mode

    // Parse alternate emails if any
    if (t.alternate_emails) {
      try {
        const alts = typeof t.alternate_emails === 'string' ? JSON.parse(t.alternate_emails) : t.alternate_emails;
        setAltEmails(Array.isArray(alts) ? alts : []);
      } catch (e) {
        setAltEmails([]);
      }
    } else {
      setAltEmails([]);
    }
    
    setDefaultEmailIdx(-1);
    
    setDiscount(t.subscription_discount !== null && t.subscription_discount !== undefined ? String(t.subscription_discount) : '');
    setFinalPrice(t.subscription_final_price !== null && t.subscription_final_price !== undefined ? String(t.subscription_final_price) : '');
    setTax(t.subscription_tax !== null && t.subscription_tax !== undefined ? String(t.subscription_tax) : '18');
    setInvoiceNumber(t.subscription_invoice_number || '');
    setOvMaxBranches(t.override_max_branches !== null && t.override_max_branches !== undefined ? String(t.override_max_branches) : '');
    setOvMaxStaffUsers(t.override_max_staff_users !== null && t.override_max_staff_users !== undefined ? String(t.override_max_staff_users) : '');
    setOvMaxStudents(t.override_max_students !== null && t.override_max_students !== undefined ? String(t.override_max_students) : '');
    setOvMaxParents(t.override_max_parents !== null && t.override_max_parents !== undefined ? String(t.override_max_parents) : '');
    setOvMaxTeachers(t.override_max_teachers !== null && t.override_max_teachers !== undefined ? String(t.override_max_teachers) : '');
    setOvMaxStorage(t.override_max_storage || '');
    setOvMaxFileSize(t.override_max_file_size || '');
    setOvMaxSmsCredits(t.override_max_sms_credits !== null && t.override_max_sms_credits !== undefined ? String(t.override_max_sms_credits) : '');
    setOvMaxWhatsappMsgs(t.override_max_whatsapp_msgs !== null && t.override_max_whatsapp_msgs !== undefined ? String(t.override_max_whatsapp_msgs) : '');
    
    setShowAddModal(true);
    setTimeout(() => {
      document.getElementById('tenant-form-top')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  };

  const handleViewTenant = (t: any) => {
    setIsViewOnly(true);
    handleLoadTenantForm(t);
  };

  const handleEditTenant = (t: any) => {
    setIsViewOnly(false);
    handleLoadTenantForm(t);
  };

  const handleConfirmDelete = async () => {
    if (!tenantToDelete) return;
    try {
      setIsDeleting(true);
      await tenantService.updateTenantStatus(tenantToDelete.id, 3);
      addToast(`Tenant "${tenantToDelete.name}" soft-deleted successfully.`, 'success');
      setTenantToDelete(null);
      fetchTenants();
    } catch (err: any) {
      console.error('Failed to delete tenant:', err);
      addToast(err.response?.data?.message || 'Failed to delete tenant.', 'error');
    } finally {
      setIsDeleting(false);
    }
  };



  const handleAddAltEmail = () => {
    setAltEmails(prev => [...prev, '']);
  };

  const handleUpdateAltEmail = (idx: number, val: string) => {
    setAltEmails(prev => prev.map((item, i) => i === idx ? val : item));
  };

  const handleRemoveAltEmail = (idx: number) => {
    setAltEmails(prev => prev.filter((_, i) => i !== idx));
    if (defaultEmailIdx === idx) {
      setDefaultEmailIdx(-1);
    } else if (defaultEmailIdx > idx) {
      setDefaultEmailIdx(prev => prev - 1);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/svg+xml'];
      if (!validTypes.includes(file.type)) {
        alert("Invalid file format! Only JPG, PNG, and SVG are allowed.");
        e.target.value = '';
        return;
      }
      if (file.size > 500 * 1024) {
        alert("File size exceeds 500KB. Please upload a smaller image.");
        e.target.value = ''; // Reset the input
        return;
      }
      setLogoUploaded(true);
      setLogoFile(file);
      setLogoPreview(URL.createObjectURL(file));
      setLogoError(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isViewOnly) return;
    
    // Validate all required steps
    const requiredSteps = ['profile', 'admin', 'plan'];
    for (const stepId of requiredSteps) {
      const res = validateStep(stepId);
      if (!res.isValid) {
        setErrorMsg(res.error || 'Please complete all required fields.');
        setActiveTab(stepId);
        return;
      }
    }
    setErrorMsg('');

    const cleanAlts = altEmails.filter(Boolean);
    
    const currentPrimaryEmail = email.trim();
    const selectedAlternateEmail = defaultEmailIdx >= 0 ? altEmails[defaultEmailIdx]?.trim() : '';
    const finalDefaultEmail = selectedAlternateEmail || currentPrimaryEmail;
    const alternateEmailsForSave = Array.from(new Set([
      ...cleanAlts.filter(value => value !== finalDefaultEmail),
      ...(finalDefaultEmail !== currentPrimaryEmail ? [currentPrimaryEmail] : [])
    ]));
    
    // Auto-generate slug from name
    const generatedSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const finalSlug = customSlug.trim() || generatedSlug;

    // Map plan to planId
    let planId = plan;

    try {
        const formData = new FormData();
        formData.append('name', name);
        formData.append('legal_name', ownerName);
        formData.append('slug', finalSlug);
        formData.append('adminEmail', finalDefaultEmail);
        if (planId) formData.append('planId', String(planId));
        if (sourceLead && !editingTenantId) formData.append('leadId', String(sourceLead.id));
        if (address) formData.append('address', address);
        if (city) formData.append('city', city);
        if (state) formData.append('state', state);
        if (pincode) formData.append('pincode', pincode);
        if (panNo) formData.append('panNo', panNo);
        if (gstNo) formData.append('gstNo', gstNo);
        if (mobile) formData.append('mobile', mobile);
        if (timezone) formData.append('timezone', timezone);
        if (billingCycle) formData.append('billingCycle', billingCycle);
        if (logoFile) {
            formData.append('logo', logoFile);
        } else if (!logoPreview && editingTenantId) {
            formData.append('removeLogo', 'true');
        }
        formData.append('alternate_emails', JSON.stringify(alternateEmailsForSave));

        if (discount) formData.append('discount', discount);
        if (finalPrice) formData.append('finalPrice', finalPrice);
        if (tax) formData.append('tax', tax);
        if (invoiceNumber) formData.append('invoiceNumber', invoiceNumber);
        if (ovMaxBranches) formData.append('maxBranches', ovMaxBranches);
        if (ovMaxStaffUsers) formData.append('maxStaffUsers', ovMaxStaffUsers);
        if (ovMaxStudents) formData.append('maxStudents', ovMaxStudents);
        if (ovMaxParents) formData.append('maxParents', ovMaxParents);
        if (ovMaxTeachers) formData.append('maxTeachers', ovMaxTeachers);
        if (ovMaxStorage) formData.append('maxStorage', ovMaxStorage);
        if (ovMaxFileSize) formData.append('maxFileSize', ovMaxFileSize);
        if (ovMaxSmsCredits) formData.append('maxSmsCredits', ovMaxSmsCredits);
        if (ovMaxWhatsappMsgs) formData.append('maxWhatsappMsgs', ovMaxWhatsappMsgs);

        setIsUploading(true);
        setUploadProgress(0);

        const onProgress = (progressEvent: any) => {
          if (progressEvent.total) {
            const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploadProgress(percentCompleted);
          }
        };

        if (editingTenantId) {
          // Edit mode using real backend
          await tenantService.updateTenant(editingTenantId.toString(), formData, onProgress);
          setSuccessMsg(`Tenant "${name}" settings updated successfully!`);
          addToast(`Tenant "${name}" settings updated successfully!`, 'success');
        } else {
          // Create mode using real backend
          const result = await tenantService.createTenant(formData, onProgress);
          const emailStatus = result?.data?.welcomeEmailSent
            ? ' Welcome email sent.'
            : ' Tenant created, but the welcome email could not be sent.';
          setSuccessMsg(`Tenant "${name}" created successfully.${emailStatus}`);
          addToast(
            result?.data?.welcomeEmailSent
              ? `Tenant "${name}" created successfully. Welcome email sent.`
              : `Tenant "${name}" created, but the welcome email could not be sent.`,
            result?.data?.welcomeEmailSent ? 'success' : 'warning'
          );
        }
        
        setIsUploading(false);
        fetchTenants();
      
      // Reset form
      setName('');
      setAddress('');
      setCity('');
      setState('');
      setPincode('');
      setPanNo('');
      setTimezone('Asia/Kolkata');
      setBillingCycle('annual');
      setCustomSlug('');
      setGstNo('');
      setOwnerName('');
      setEmail('');
      setMobile('');
      setPlan(availablePlans.length > 0 ? availablePlans[0].id.toString() : '');
      setLogoUploaded(false);
      setLogoFile(null);
      setAltEmails([]);
      setDefaultEmailIdx(-1);
      setEditingTenantId(null);
      
      setShowAddModal(false);
      setShowSaved(true);
      setTimeout(() => {
        setShowSaved(false);
        setSuccessMsg('');
      }, 8000);
    } catch (error: any) {
      console.error('Failed to save tenant:', error);
      setErrorMsg(error.response?.data?.message || 'Failed to save tenant. Please check your inputs and try again.');
      setIsUploading(false);
    }
  };

  // With server-side pagination, 'tenants' is already the current page of items
  const filteredAndSortedTenants = tenants;

  const handleExportCSV = () => {
    if (filteredAndSortedTenants.length === 0) return;
    
    const dataToExport = filteredAndSortedTenants.map(t => ({
      'Tenant ID': t.id,
      'Institute Name': t.name,
      'Owner': t.ownerName,
      'Email': t.email,
      'Mobile': t.mobile,
      'Status': getTenantStatusLabel(t.status),
      'Plan Tier': t.plan,
      'Start Date': t.start_date || '',
      'Renewal Date': t.end_date || t.renewal_date || '',
      'Branch Count': t.branchCount,
      'Student Count': t.studentCount,
      'Address': t.address || '123 Educational Way, Block C, New Delhi',
      'GST Number': t.gstNo || '07AAAAA1111A1Z1',
      'Max Branches Limit': t.maxBranches || '10',
      'Max Students Limit': t.maxStudents || '500',
      'Max Storage Limit': t.maxStorage || '20 GB',
      'Max File Size Limit': t.maxFileSize || '10 MB',
      'Default Email': t.defaultEmail || t.email,
      'Alternative Emails': (t.altEmails || []).join('; ')
    }));

    const headers = Object.keys(dataToExport[0]);
    const csvRows = [];
    csvRows.push(headers.map(h => `"${h.replace(/"/g, '""')}"`).join(','));
    
    for (const row of dataToExport) {
      const values = headers.map(header => {
        const val = row[header as keyof typeof row];
        const escaped = String(val ?? '').replace(/"/g, '""');
        return `"${escaped}"`;
      });
      csvRows.push(values.join(','));
    }
    
    const csvContent = "data:text/csv;charset=utf-8," + encodeURIComponent(csvRows.join("\n"));
    const link = document.createElement("a");
    link.setAttribute("href", csvContent);
    link.setAttribute("download", "institutes_directory.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (showAddModal) {
    return (
      <div id="tenant-form-top" className="space-y-6 w-full animate-fade-in">
        {sourceLead && !editingTenantId && (
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-sm font-semibold text-blue-800 shadow-sm animate-fade-in flex items-start gap-2">
            <ShieldAlert size={18} className="text-blue-600 shrink-0 mt-0.5" />
            <div>
              Converting lead <strong>#{sourceLead.id} — {sourceLead.instituteName}</strong> into a tenant.
              On submission the lead will be marked as converted. Fields below are pre-filled from the lead record.
            </div>
          </div>
        )}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddModal(false)}
            className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer animate-fade-in"
          >
            <ArrowLeft size={26} />
          </button>
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {isViewOnly ? `Tenant Information: ${name}` : (editingTenantId ? `Edit Tenant Settings: ${name}` : "Register Institute Tenant")}
            </h2>
            <p className="text-base text-slate-500 mt-1">
              {isViewOnly 
                ? "Read-only overview of workspace configurations, credentials, subscription, and limits." 
                : "Configure profile fields, admin account logins, alternative emails, and system limits."}
            </p>
          </div>
        </div>

        <div className="w-full">
          {errorMsg && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-sm font-medium text-red-800 shadow-sm animate-fade-in flex items-start gap-2">
              <span className="text-red-500 font-bold mt-0.5">!</span>
              <div>{errorMsg}</div>
            </div>
          )}

          {/* Horizontal Tabs */}
          <div className="mb-8 border-b border-slate-200 overflow-x-auto">
            <nav className="flex gap-1 min-w-max">
              {formTabs.map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => handleTabClick(tab.id)}
                    className={`px-4 py-3 text-sm font-bold whitespace-nowrap border-b-[3px] -mb-px transition-colors cursor-pointer ${
                      isActive
                        ? 'border-blue-600 text-blue-700 bg-blue-50/50'
                        : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <form onSubmit={handleSubmit} noValidate className="space-y-6">
            <fieldset disabled={isViewOnly} className="space-y-6 group">
            
            {/* === TAB 1: Institute Profile & Branding === */}
            {activeTab === 'profile' && (
            <div className="space-y-4">
              <h4 className="text-sm font-extrabold text-blue-600 uppercase tracking-widest border-b border-slate-100 pb-1.5 flex items-center gap-1.5 select-none">
                <span>01.</span> Institute Profile & Branding
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input 
                  label="Institute / Coaching Name" 
                  required 
                  placeholder="e.g. Apex IIT Academy" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)} 
                />
                <Input 
                  label="Custom URL Subdomain (Optional)" 
                  placeholder="e.g. apex-academy" 
                  value={customSlug} 
                  onChange={(e) => setCustomSlug(e.target.value)} 
                />
              </div>


              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch mt-6">
                
                {/* Left Column: Logo Upload / Display */}
                <div className="flex flex-col gap-1.5 w-full md:w-3/4 mx-auto lg:w-full">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Brand Logo File</label>
                  <div className="flex flex-col gap-1.5 w-full bg-white p-6 rounded-2xl border border-slate-100 shadow-sm justify-start items-center">
                    <div className="text-center mb-4 mt-1 w-full">
                       <h3 className="text-lg font-bold text-slate-900">
                         {logoPreview && !logoError ? (logoFile ? 'New Logo Selected' : 'Current Brand Logo') : 'Brand Logo'}
                       </h3>
                       <p className="text-xs text-slate-500 font-medium">
                         {logoPreview && !logoError ? (logoFile ? 'Ready to save with institute profile' : 'Active logo for tenant portal branding') : (isViewOnly ? 'No custom brand logo is currently configured' : 'Select a PNG, JPG, or SVG image (Max 500KB)')}
                       </p>
                    </div>
                    {!isViewOnly && (
                      <input 
                        type="file" 
                        id="logo-file-input" 
                        accept=".jpg,.jpeg,.png,.svg" 
                        className="hidden" 
                        onChange={handleLogoChange} 
                      />
                    )}
                    {logoPreview && !logoError ? (
                        <div className="flex flex-col items-center w-full mb-2">
                           <div className="w-full aspect-square max-w-[280px] flex flex-col relative bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                               {!isViewOnly && (
                                 <button 
                                   type="button" 
                                   onClick={(e) => { 
                                     e.preventDefault(); 
                                     setLogoFile(null); 
                                     setLogoPreview(null); 
                                     setLogoUploaded(false); 
                                     setLogoError(false);
                                   }} 
                                   title="Remove logo"
                                   className="absolute top-2.5 right-2.5 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-slate-400 hover:text-red-500 hover:bg-white shadow-sm transition-colors z-10 cursor-pointer"
                                 >
                                    <X size={14} />
                                 </button>
                               )}
                               <div className="w-full flex-1 flex flex-col items-center justify-center p-4">
                                   <img 
                                     src={logoPreview} 
                                     alt="Brand Logo" 
                                     onError={() => setLogoError(true)}
                                     className="max-w-full max-h-[140px] object-contain drop-shadow-sm mb-3" 
                                   />
                                   <div className="text-xs font-semibold text-slate-700 truncate max-w-[220px]">
                                     {logoFile?.name || (logoPreview ? logoPreview.split('/').pop()?.split('?')[0] : 'logo.png')}
                                   </div>
                                   <div className="text-[11px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
                                     <Check size={12} /> {logoFile ? 'Ready to upload' : 'Active on platform'}
                                   </div>
                               </div>
                           </div>
                           
                           {!isViewOnly && (
                             <div className="flex gap-2 w-full max-w-[280px] mt-3.5">
                               <label 
                                 htmlFor="logo-file-input" 
                                 className="flex-1 py-2 px-3 bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold rounded-lg transition-colors text-center cursor-pointer flex items-center justify-center gap-1.5 border border-blue-100"
                               >
                                 <Upload size={13} />
                                 Change Logo
                               </label>
                               <button 
                                 type="button" 
                                 onClick={() => {
                                   setLogoFile(null);
                                   setLogoPreview(null);
                                   setLogoUploaded(false);
                                   setLogoError(false);
                                 }} 
                                 className="py-2 px-3.5 bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-600 text-xs font-semibold rounded-lg transition-colors cursor-pointer border border-slate-200"
                               >
                                 Remove
                               </button>
                             </div>
                           )}
                        </div>
                    ) : (
                       isViewOnly ? (
                         <div className="flex flex-col items-center justify-center aspect-square w-full max-w-[280px] p-6 gap-3 bg-slate-50 border border-slate-200 rounded-2xl mb-2 text-center">
                            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                              <ImageIcon size={24} />
                            </div>
                            <span className="text-sm font-bold text-slate-600">No Logo Uploaded</span>
                            <span className="text-xs text-slate-400">Default brand avatar active</span>
                         </div>
                       ) : (
                         <label htmlFor="logo-file-input" className="flex flex-col items-center justify-center aspect-square w-full max-w-[280px] p-6 gap-3.5 bg-slate-50 border-2 border-dashed border-slate-300 rounded-2xl cursor-pointer hover:border-blue-500 hover:bg-blue-50/20 transition-all mb-2 text-center group">
                            <div className="w-12 h-12 rounded-full bg-blue-100/70 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                              <ImageIcon size={24} />
                            </div>
                            <div className="flex flex-col items-center gap-1">
                               <span className="text-sm font-bold text-slate-700">
                                 {logoError ? 'Logo preview unavailable' : 'No Logo Uploaded'}
                               </span>
                               <span className="text-xs text-slate-400 max-w-[190px]">
                                 {logoError ? 'Upload a fresh file to replace it' : 'Supports PNG, JPG, or SVG up to 500KB'}
                               </span>
                            </div>
                            <div className="bg-blue-600 text-white text-xs font-bold py-2 px-5 rounded-lg shadow-sm group-hover:bg-blue-700 transition-colors mt-1 flex items-center gap-1.5">
                              <Upload size={13} />
                              Browse & Upload Logo
                            </div>
                         </label>
                       )
                    )}
                  </div>
                </div>

                {/* Right Column: Location & Settings */}
                <div className="flex flex-col gap-4">
                  <div className="grid grid-cols-1 gap-4 items-start">
                    <Input 
                      label="Address Line 1" 
                      required
                      placeholder="e.g. 401, Western Express Highway, Mumbai" 
                      value={address} 
                      onChange={(e) => setAddress(e.target.value)} 
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input 
                      label="GSTIN Number (Optional)" 
                      placeholder="e.g. 27AAAAA0000A1Z5" 
                      value={gstNo} 
                      onChange={(e) => setGstNo(e.target.value)} 
                    />
                    <Input 
                      label="PAN Number (Optional)" 
                      placeholder="e.g. ABCDE1234F" 
                      value={panNo} 
                      onChange={(e) => setPanNo(e.target.value)} 
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Input 
                      label="City" 
                      required
                      placeholder="e.g. Mumbai" 
                      value={city} 
                      onChange={(e) => setCity(e.target.value)} 
                    />
                    <Input 
                      label="State" 
                      required
                      placeholder="e.g. Maharashtra" 
                      value={state} 
                      onChange={(e) => setState(e.target.value)} 
                    />
                    <Input 
                      label="PIN Code" 
                      required
                      placeholder="e.g. 400001" 
                      value={pincode} 
                      onChange={(e) => setPincode(e.target.value)} 
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Select
                      label="Timezone"
                      required
                      value={timezone}
                      onChange={(e) => setTimezone(e.target.value)}
                      options={[
                        { value: 'Asia/Kolkata', label: 'Asia/Kolkata (IST)' },
                        { value: 'UTC', label: 'UTC' },
                        { value: 'America/New_York', label: 'America/New_York (EST)' }
                      ]}
                    />
                    <Input 
                      label="Country" 
                      value="India" 
                      disabled
                      placeholder="India" 
                    />
                  </div>
                </div>
              </div>
            </div>
            )}

            {/* === TAB 2: Admin Credentials === */}
            {activeTab === 'admin' && (
            <div className="space-y-4 pt-1">
              <h4 className="text-sm font-extrabold text-blue-600 uppercase tracking-widest border-b border-slate-100 pb-1.5 flex items-center justify-between select-none">
                <span><span>02.</span> Admin User Credentials</span>
                <span className="text-[11px] font-semibold text-slate-400 normal-case tracking-normal">Primary admin for initial institute access</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input 
                  label="Owner / Primary Admin Name" 
                  required 
                  placeholder="Dr. Ramesh Kumar (or admin_apex)" 
                  value={ownerName} 
                  onChange={(e) => setOwnerName(e.target.value)} 
                />
                <div className="flex flex-col gap-1.5 w-full">
                  <div className="flex justify-between items-center select-none">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center">
                      Admin Email Login <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    {!isViewOnly && (
                      <button
                        type="button"
                        onClick={() => setDefaultEmailIdx(-1)}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded cursor-pointer transition-colors ${
                          defaultEmailIdx === -1 
                            ? 'bg-blue-600 text-white shadow-sm' 
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {defaultEmailIdx === -1 ? '★ Default Login' : 'Set as Default'}
                      </button>
                    )}
                  </div>
                  <input
                    type="email"
                    required
                    disabled={isViewOnly}
                    placeholder="ramesh@apex.com"
                    className="w-full bg-white disabled:bg-slate-50 disabled:text-slate-600 border border-slate-200 focus:border-blue-500 focus:ring-blue-100 rounded-lg px-3 py-2 text-base text-slate-800 placeholder-slate-400 outline-none transition duration-150 focus:ring-4"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              {/* Dynamic Alternate Emails Lists */}
              <div className="space-y-3">
                <div className="flex justify-between items-center select-none">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
                    Alternate Email Addresses (Optional)
                  </span>
                  {!isViewOnly && (
                    <Button 
                      type="button" 
                      variant="secondary" 
                      size="sm"
                      style={{ padding: '4px 10px', fontSize: '11px', gap: '4px' }}
                      onClick={handleAddAltEmail}
                    >
                      <Plus size={12} /> Add Alternate
                    </Button>
                  )}
                </div>
                
                {altEmails.length > 0 ? (
                  <div className="space-y-3 animate-fade-in pt-1">
                    {altEmails.map((emailVal, idx) => (
                      <div key={idx} className="flex gap-2 items-end">
                        <div className="flex-1 flex flex-col gap-1.5 w-full">
                          <div className="flex justify-between items-center select-none">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                              Alternate Email #{idx + 1}
                            </label>
                            {!isViewOnly && (
                              <button
                                type="button"
                                onClick={() => setDefaultEmailIdx(idx)}
                                className={`text-[10px] font-bold px-2 py-0.5 rounded cursor-pointer transition-colors ${
                                  defaultEmailIdx === idx 
                                    ? 'bg-blue-600 text-white shadow-sm' 
                                    : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                                }`}
                              >
                                {defaultEmailIdx === idx ? '★ Default Login' : 'Set as Default'}
                              </button>
                            )}
                          </div>
                          <input
                            type="email"
                            required
                            disabled={isViewOnly}
                            placeholder={`alternate-${idx + 1}@apex.com`}
                            className="w-full bg-white disabled:bg-slate-50 disabled:text-slate-600 border border-slate-200 focus:border-blue-500 focus:ring-blue-100 rounded-lg px-3 py-2 text-base text-slate-800 placeholder-slate-400 outline-none transition duration-150 focus:ring-4"
                            value={emailVal}
                            onChange={(e) => handleUpdateAltEmail(idx, e.target.value)}
                          />
                        </div>
                        {!isViewOnly && (
                          <button
                            type="button"
                            onClick={() => handleRemoveAltEmail(idx)}
                            className="p-2 border border-red-200 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg cursor-pointer transition-colors shadow-sm self-end"
                            style={{ height: '38px', width: '38px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                          >
                            <Trash size={16} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  isViewOnly && (
                    <p className="text-xs text-slate-400 italic py-1">No alternate emails configured.</p>
                  )
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                <Input 
                  label="Primary Mobile Contact" 
                  required
                  placeholder="9876543210" 
                  value={mobile} 
                  maxLength={10}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))} 
                />
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Temporary Password (Sent by Email)</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      readOnly
                      className="flex-1 bg-slate-100 border border-slate-200 text-slate-600 rounded-lg px-3 py-2 text-base font-semibold select-all outline-none"
                      value={editingTenantId ? defaultPassword : 'Generated securely after submission'}
                    />
                  </div>
                </div>
              </div>
            </div>
            )}

            {/* === TAB 3: Subscription Plan === */}
            {activeTab === 'plan' && (
            <div className="space-y-4 pt-1">
              <h4 className="text-sm font-extrabold text-blue-600 uppercase tracking-widest border-b border-slate-100 pb-1.5">
                <span>03.</span> Subscription Plan
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select 
                  label="Subscription Tier" 
                  required
                  value={plan} 
                  onChange={(e) => setPlan(e.target.value)} 
                  options={availablePlans.map((p) => ({ value: p.id.toString(), label: p.name }))}
                />
                <Select
                  label="Billing Cycle"
                  required
                  value={billingCycle}
                  onChange={(e) => setBillingCycle(e.target.value)}
                  options={[
                    { value: 'Monthly', label: 'Monthly' },
                    { value: 'Quarterly', label: 'Quarterly' },
                    { value: 'Half-Yearly', label: 'Half-Yearly' },
                    { value: 'Yearly', label: 'Yearly' },
                    { value: 'Lifetime', label: 'Lifetime' }
                  ]}
                />
                <Input 
                  label="Plan Start Date" 
                  type="date" 
                  required
                  value={startDate} 
                  onChange={(e) => setStartDate(e.target.value)} 
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Expiration Date (Auto Calculated)</label>
                  <input 
                    type="date" 
                    readOnly 
                    className="w-full bg-slate-100 border border-slate-200 text-slate-600 rounded-lg px-3 py-2 text-base font-semibold select-none cursor-not-allowed outline-none"
                    value={expiryDate} 
                  />
                </div>
              </div>
            </div>
            )}

            {/* === TAB 4: Commercial === */}
            {activeTab === 'commercial' && (
            <div className="space-y-4 pt-1">
              <h4 className="text-sm font-extrabold text-blue-600 uppercase tracking-widest border-b border-slate-100 pb-1.5">
                <span>03.</span> Commercial
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Input label="Discount %" type="number" min={0} max={100} placeholder="e.g. 10"
                    value={discount} onChange={e => { setDiscount(e.target.value); setFinalPrice(autoFinalPrice()); }} />
                </div>
                <div>
                  <Input label="Final Price" type="number" placeholder="Auto-calculated or override"
                    value={finalPrice || autoFinalPrice()} onChange={e => setFinalPrice(e.target.value)} />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Tax %" type="number" placeholder="e.g. 18" value={tax} onChange={e => setTax(e.target.value)} />
                <Input label="Invoice Number" placeholder="e.g. INV-2026-042" value={invoiceNumber} onChange={e => setInvoiceNumber(e.target.value)} />
              </div>
            </div>
            )}

            {/* === TAB 5: Override Limits === */}
            {activeTab === 'limits' && (
            <div className="space-y-4 pt-1">
              <h4 className="text-sm font-extrabold text-blue-600 uppercase tracking-widest border-b border-slate-100 pb-1.5">
                <span>04.</span> Override Limits <span className="text-slate-400 font-normal normal-case tracking-normal text-xs ml-2">(leave blank to use plan defaults)</span>
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <Input label="Max Branches" type="number" placeholder="Plan default" value={ovMaxBranches} onChange={e => setOvMaxBranches(e.target.value)} />
                <Input label="Max Staff Users" type="number" placeholder="Plan default" value={ovMaxStaffUsers} onChange={e => setOvMaxStaffUsers(e.target.value)} />
                <Input label="Max Students" type="number" placeholder="Plan default" value={ovMaxStudents} onChange={e => setOvMaxStudents(e.target.value)} />
                <Input label="Max Parents" type="number" placeholder="Plan default" value={ovMaxParents} onChange={e => setOvMaxParents(e.target.value)} />
                <Input label="Max Teachers" type="number" placeholder="Plan default" value={ovMaxTeachers} onChange={e => setOvMaxTeachers(e.target.value)} />
                <Select label="Max Storage" value={ovMaxStorage} onChange={e => setOvMaxStorage(e.target.value)}
                  options={[{ value: '', label: 'Plan default' }, { value: '5 GB', label: '5 GB' }, { value: '20 GB', label: '20 GB' }, { value: '100 GB', label: '100 GB' }, { value: '500 GB', label: '500 GB' }]} />
                <Select label="Max File Size" value={ovMaxFileSize} onChange={e => setOvMaxFileSize(e.target.value)}
                  options={[{ value: '', label: 'Plan default' }, { value: '5 MB', label: '5 MB' }, { value: '20 MB', label: '20 MB' }, { value: '50 MB', label: '50 MB' }, { value: '200 MB', label: '200 MB' }]} />
                <Input label="Max SMS Credits" type="number" placeholder="Plan default" value={ovMaxSmsCredits} onChange={e => setOvMaxSmsCredits(e.target.value)} />
                <Input label="Max WhatsApp Msgs" type="number" placeholder="Plan default" value={ovMaxWhatsappMsgs} onChange={e => setOvMaxWhatsappMsgs(e.target.value)} />
              </div>
            </div>
            )}

            </fieldset>

            {isViewOnly ? (
              <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-4 border-t border-slate-100">
                <div className="flex gap-2">
                  {formTabs.findIndex(t => t.id === activeTab) > 0 && (
                    <Button type="button" variant="secondary" onClick={handlePrevStep} className="flex items-center gap-1">
                      <ChevronLeft size={16} /> Previous
                    </Button>
                  )}
                  {formTabs.findIndex(t => t.id === activeTab) < formTabs.length - 1 && (
                    <Button type="button" variant="secondary" onClick={handleNextStep} className="flex items-center gap-1">
                      Next <ChevronRight size={16} />
                    </Button>
                  )}
                </div>
                <div className="flex gap-3">
                  <Button type="button" variant="secondary" onClick={() => setShowAddModal(false)}>Close</Button>
                  <Button 
                    type="button" 
                    variant="primary" 
                    onClick={() => setIsViewOnly(false)} 
                    className="flex items-center gap-1.5"
                  >
                    <Pencil size={15} /> Switch to Edit
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-4 border-t border-slate-100">
                <div>
                  {formTabs.findIndex(t => t.id === activeTab) > 0 && (
                    <Button type="button" variant="secondary" onClick={handlePrevStep} className="flex items-center gap-1">
                      <ChevronLeft size={16} /> Back
                    </Button>
                  )}
                </div>
                <div className="flex gap-3 items-center">
                  <Button type="button" variant="secondary" onClick={() => setShowAddModal(false)}>Cancel</Button>
                  {formTabs.findIndex(t => t.id === activeTab) < formTabs.length - 1 ? (
                    <Button type="button" variant="primary" onClick={handleNextStep} className="flex items-center gap-1.5 shadow-sm">
                      Next: {formTabs[formTabs.findIndex(t => t.id === activeTab) + 1].label.replace(/^\d+\.\s*/, '')} <ChevronRight size={16} />
                    </Button>
                  ) : (
                    <Button type="submit" variant="primary" disabled={isUploading} className="flex items-center gap-1.5 shadow-sm">
                      {isUploading ? (editingTenantId ? 'Saving Changes...' : 'Creating Institute...') : (editingTenantId ? 'Save Changes' : 'Provision Tenant')}
                    </Button>
                  )}
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {showSaved && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-sm font-semibold text-emerald-800 animate-fade-in shadow-sm">
          ✓ {successMsg}
        </div>
      )}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Tenant Institutes Directory</h2>
          <p className="text-base text-slate-500 mt-2">Provision new coaching center workspaces, set allowed limits, and manage billing statuses.</p>
        </div>
        <Button variant="primary" style={{ gap: '6px' }} className="px-5 py-2.5 text-sm shadow-sm" onClick={handleOpenAddModal}>
          <Plus size={18} /> Create Tenant
        </Button>
      </div>

      {/* Search, Filter, Sort Controls & Export CSV */}
      <div className="flex flex-col md:flex-row gap-4 bg-white border border-slate-200 p-4 rounded-xl shadow-sm items-end justify-between">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 flex-1 w-full items-end">
          <Input label="Search" placeholder="Search by ID, name, owner..." 
            value={searchTerm} 
            onChange={(e) => {
              setSearchTerm(e.target.value.replace(/[^a-zA-Z0-9\s]/g, ''));
              setCurrentPage(1);
            }} 
            wrapperClassName="sm:col-span-2"
          />
          <Select 
            label="Plan" 
            value={filterPlan}
            onChange={(e) => setFilterPlan(e.target.value)}
            options={[
              { value: 'All', label: 'All Plans' },
              ...availablePlans.map((p) => ({ value: p.id.toString(), label: p.name }))
            ]}
          />
          <Select 
            label="Status" 
            value={filterStatus} 
            onChange={(e) => {
              setFilterStatus(e.target.value);
              setCurrentPage(1);
            }} 
            options={[
              { value: 'All', label: 'All Statuses' },
              { value: '1', label: 'Active' },
              { value: '0', label: 'Inactive' },
              { value: '2', label: 'Draft' },
              { value: '3', label: 'Deleted' }
            ]} 
          />
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="secondary" onClick={handleClearFilters} className="text-slate-500 hover:text-slate-700">Clear</Button>
          <Button variant="secondary" onClick={handleExportCSV}>Export CSV</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Platform Tenant Registry</CardTitle>
        </CardHeader>
        <Table 
          dense 
          minWidth="1200px"
          colWidths={['55px', '190px', '140px', '210px', '120px', '110px', '140px', '100px', '135px']}
          headers={['ID', 'Institute Name', 'Owner', 'Email / Contact', 'Plan Tier', 'Start Date', 'Expiry Date', 'Status', 'Actions']}
        >
          {(() => {
            const itemsPerPage = 10; // Match backend limit
            const paginatedTenants = filteredAndSortedTenants;
            return (
              <>
                {paginatedTenants.map((t, idx) => (
                  <tr 
                    key={idx} 
                    onClick={() => handleViewTenant(t)}
                    className="hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    <td className="px-3.5 py-3 font-semibold text-slate-900 text-sm whitespace-nowrap">{t.id}</td>
                    <td className="px-3.5 py-3 font-semibold text-slate-900 text-sm">{t.name}</td>
                    <td className="px-3.5 py-3 text-sm text-slate-700 whitespace-nowrap">{t.legal_name || t.admin_name || 'N/A'}</td>
                    <td className="px-3.5 py-3 text-sm">
                      <div className="text-slate-800 font-medium truncate">
                        {t.contact_email || t.admin_email || 'N/A'}
                      </div>
                      {t.contact_phone && (
                        <div className="text-sm text-slate-500 mt-0.5">{t.contact_phone}</div>
                      )}
                    </td>
                    <td className="px-3.5 py-3 text-sm whitespace-nowrap">
                      <span className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded text-sm font-medium">
                        {t.plan_name || 'Standard'}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 text-sm text-slate-700 whitespace-nowrap">{t.start_date ? formatDate(t.start_date) : 'N/A'}</td>
                    <td className="px-3.5 py-3 text-sm text-slate-700 whitespace-nowrap">
                      <div className="flex flex-col gap-1 items-start">
                        <span>{t.end_date ? formatDate(t.end_date) : 'N/A'}</span>
                        {t.is_expiring_soon === 1 && (
                          <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 font-medium rounded text-[11px] flex items-center gap-1 border border-amber-200 w-fit whitespace-nowrap">
                            <AlertTriangle size={11} className="shrink-0 text-amber-600" /> Expiring Soon
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-3.5 py-3 whitespace-nowrap">
                      {(() => {
                        const s = t.status;
                        const label = getTenantStatusLabel(s);
                        let badgeColors = 'bg-slate-50 text-slate-700 border-slate-200';
                        if (s === 1 || s === '1' || label === 'Active') {
                          badgeColors = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                        } else if (s === 0 || s === '0' || label === 'Inactive') {
                          badgeColors = 'bg-red-50 text-red-700 border-red-200';
                        } else if (s === 2 || s === '2' || label === 'Draft') {
                          badgeColors = 'bg-amber-50 text-amber-800 border-amber-200';
                        } else if (s === 3 || s === '3' || label === 'Deleted') {
                          badgeColors = 'bg-slate-100 text-slate-600 border-slate-300';
                        }
                        return (
                          <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize border ${badgeColors}`}>
                            {label}
                          </span>
                        );
                      })()}
                    </td>
                    <td className="px-3.5 py-3 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => handleViewTenant(t)}
                          title="View Details (Read Only)"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                        >
                          <Eye size={16} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleEditTenant(t)}
                          title="Edit Tenant Settings"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setTenantToDelete(t)}
                          title="Delete Tenant"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </>
            );
          })()}
        </Table>
        <Pagination
          currentPage={currentPage}
          totalPages={Math.ceil(totalItems / 10)}
          totalItems={totalItems}
          pageSize={10}
          onPageChange={setCurrentPage}
        />
      </Card>

      {/* Soft Delete Confirmation Modal */}
      {tenantToDelete && createPortal(
        <div 
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in"
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
          onClick={() => !isDeleting && setTenantToDelete(null)}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-2xl space-y-4 animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 text-red-600">
              <div className="w-12 h-12 rounded-full bg-red-50 border border-red-100 flex items-center justify-center shrink-0">
                <AlertTriangle size={24} className="text-red-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Delete Tenant Institute</h3>
                <p className="text-xs text-slate-500">Soft-delete confirmation warning</p>
              </div>
            </div>
            
            <p className="text-sm text-slate-600 leading-relaxed">
              Are you sure you want to delete <span className="font-bold text-slate-900">"{tenantToDelete.name}"</span>? 
              This action will soft-delete the institute workspace, revoke portal access for its users, and remove it from active directories.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => setTenantToDelete(null)}
                disabled={isDeleting}
              >
                Cancel
              </Button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors cursor-pointer flex items-center gap-2"
              >
                <Trash2 size={15} />
                {isDeleting ? 'Deleting...' : 'Yes, Delete Tenant'}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
};
