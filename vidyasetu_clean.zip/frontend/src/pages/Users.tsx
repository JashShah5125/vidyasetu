import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Card, CardHeader, CardTitle } from '../components/ui/Card';
import { Table } from '../components/ui/Table';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Pagination } from '../components/ui/Pagination';
import { Modal } from '../components/ui/Modal';
import { Plus, ArrowLeft, Upload, Loader2, Eye, Edit3, Trash2, AlertTriangle, User, Briefcase, DollarSign, Shield } from 'lucide-react';
import type { Staff } from '../types';
import { BulkImportModal } from '../components/ui/BulkImportModal';
import { staffApi } from '../services/staffApi';
import { formatDate } from '../utils/dateFormatter';

export type StaffColumnKey =
  | 'contact_number'
  | 'email'
  | 'official_email'
  | 'department'
  | 'designation'
  | 'joining_date'
  | 'employment_type'
  | 'employment_status'
  | 'qualification'
  | 'experience'
  | 'salary_amount'
  | 'salary_type'
  | 'subjects_taught'
  | 'location'
  | 'gender'
  | 'dob'
  | 'aadhaar_number'
  | 'pan_number'
  | 'bank_details'
  | 'max_lectures';

const STAFF_COLUMN_OPTIONS: Array<{ value: StaffColumnKey; label: string; header: string }> = [
  { value: 'contact_number', label: 'Contact Mobile', header: 'Contact Mobile' },
  { value: 'email', label: 'Email Address', header: 'Email' },
  { value: 'subjects_taught', label: 'Subjects Taught', header: 'Subjects' },
  { value: 'department', label: 'Department', header: 'Department' },
  { value: 'designation', label: 'Designation', header: 'Designation' },
  { value: 'joining_date', label: 'Joining Date', header: 'Date of Joining' },
  { value: 'employment_type', label: 'Employment Type', header: 'Employment Type' },
  { value: 'employment_status', label: 'Employment Status', header: 'Employment Status' },
  { value: 'qualification', label: 'Qualification', header: 'Qualification' },
  { value: 'experience', label: 'Experience (Years)', header: 'Experience' },
  { value: 'salary_amount', label: 'Salary Amount (₹)', header: 'Salary Amount' },
  { value: 'salary_type', label: 'Salary Type', header: 'Salary Type' },
  { value: 'location', label: 'Address & City', header: 'Location' },
  { value: 'gender', label: 'Gender', header: 'Gender' },
  { value: 'dob', label: 'Date of Birth', header: 'Date of Birth' },
  { value: 'aadhaar_number', label: 'Aadhaar Number', header: 'Aadhaar No.' },
  { value: 'pan_number', label: 'PAN Number', header: 'PAN No.' },
  { value: 'bank_details', label: 'Bank Account & Name', header: 'Bank Details' },
  { value: 'max_lectures', label: 'Max Lectures (Day / Wk)', header: 'Max Lectures' },
];

const renderCustomColumnCell = (s: any, colKey: StaffColumnKey) => {
  switch (colKey) {
    case 'contact_number':
      return <span className="font-mono text-xs text-slate-700 whitespace-nowrap truncate block" title={s.contact_number || s.mobile || '—'}>{s.contact_number || s.mobile || '—'}</span>;
    case 'email':
    case 'official_email':
      return <span className="font-mono text-xs text-slate-700 whitespace-nowrap truncate block" title={s.email || '—'}>{s.email || '—'}</span>;
    case 'subjects_taught':
      const subs = s.subjects_taught || (Array.isArray(s.subjects) ? s.subjects.join(', ') : '') || '—';
      return <span className="text-xs font-medium text-blue-700 whitespace-nowrap truncate block" title={subs}>{subs}</span>;
    case 'department':
      return <span className="text-xs font-semibold text-slate-800 whitespace-nowrap truncate block" title={s.department || '—'}>{s.department || '—'}</span>;
    case 'designation':
      return <span className="text-xs font-medium text-slate-700 whitespace-nowrap truncate block" title={s.designation || '—'}>{s.designation || '—'}</span>;
    case 'joining_date':
      const jDate = s.joining_date ? formatDate(s.joining_date) : (s.joiningDate ? formatDate(s.joiningDate) : '—');
      return <span className="text-xs text-slate-600 whitespace-nowrap truncate block" title={jDate}>{jDate}</span>;
    case 'employment_type':
      const empType = (s.employment_type || '').replace(/_/g, ' ') || 'Full Time';
      return <span className="capitalize text-xs font-medium text-slate-700 whitespace-nowrap truncate block" title={empType}>{empType}</span>;
    case 'employment_status':
      const empStatus = s.employment_status || 'Confirmed';
      return <span className="capitalize text-xs font-medium text-slate-700 whitespace-nowrap truncate block" title={empStatus}>{empStatus}</span>;
    case 'qualification':
      return <span className="text-xs text-slate-700 whitespace-nowrap truncate block" title={s.qualification || '—'}>{s.qualification || '—'}</span>;
    case 'experience':
      const exp = s.experience ? `${s.experience} Years` : '—';
      return <span className="text-xs text-slate-700 whitespace-nowrap truncate block" title={exp}>{exp}</span>;
    case 'salary_amount':
      const sal = s.salary_amount ? `₹${Number(s.salary_amount).toLocaleString('en-IN')}` : (s.monthlySalary ? `₹${Number(s.monthlySalary).toLocaleString('en-IN')}` : '—');
      return <span className="font-mono font-semibold text-xs text-emerald-700 whitespace-nowrap truncate block" title={sal}>{sal}</span>;
    case 'salary_type':
      const salType = s.salary_type || s.salaryType || 'Monthly';
      return <span className="capitalize text-xs text-slate-700 whitespace-nowrap truncate block" title={salType}>{salType}</span>;
    case 'location':
      const loc = s.address || [s.city, s.state].filter(Boolean).join(', ') || '—';
      return <span className="text-xs text-slate-700 whitespace-nowrap truncate block" title={loc}>{loc}</span>;
    case 'gender':
      return <span className="text-xs text-slate-700 whitespace-nowrap truncate block" title={s.gender || '—'}>{s.gender || '—'}</span>;
    case 'dob':
      const dobStr = s.dob ? formatDate(s.dob) : '—';
      return <span className="text-xs text-slate-600 whitespace-nowrap truncate block" title={dobStr}>{dobStr}</span>;
    case 'aadhaar_number':
      return <span className="font-mono text-xs text-slate-700 whitespace-nowrap truncate block" title={s.aadhaar_number || '—'}>{s.aadhaar_number || '—'}</span>;
    case 'pan_number':
      return <span className="font-mono uppercase text-xs text-slate-700 whitespace-nowrap truncate block" title={s.pan_number || '—'}>{s.pan_number || '—'}</span>;
    case 'bank_details':
      const bankInfo = `${s.bank_name || s.bankName || 'Bank'} • ${s.bank_account_number || s.accountNumber || '—'}`;
      return <span className="text-xs font-semibold text-slate-800 whitespace-nowrap truncate block" title={bankInfo}>{bankInfo}</span>;
    case 'max_lectures':
      const lecStr = s.max_lectures_per_day ? `${s.max_lectures_per_day}/day • ${s.max_lectures_per_week || '—'}/wk` : '—';
      return <span className="text-xs text-slate-700 whitespace-nowrap truncate block" title={lecStr}>{lecStr}</span>;
    default:
      return <span className="text-xs text-slate-400 whitespace-nowrap truncate block">—</span>;
  }
};

const getColumnTextValue = (s: any, colKey: StaffColumnKey): string => {
  switch (colKey) {
    case 'contact_number': return s.contact_number || s.mobile || '';
    case 'email':
    case 'official_email': return s.email || '';
    case 'subjects_taught': return s.subjects_taught || (Array.isArray(s.subjects) ? s.subjects.join(', ') : '');
    case 'department': return s.department || '';
    case 'designation': return s.designation || '';
    case 'joining_date': return s.joining_date ? new Date(s.joining_date).toISOString().split('T')[0] : (s.joiningDate || '');
    case 'employment_type': return (s.employment_type || '').replace(/_/g, ' ');
    case 'employment_status': return s.employment_status || '';
    case 'qualification': return s.qualification || '';
    case 'experience': return s.experience ? `${s.experience} Years` : '';
    case 'salary_amount': return s.salary_amount ? `${s.salary_amount}` : (s.monthlySalary || '');
    case 'salary_type': return s.salary_type || s.salaryType || '';
    case 'location': return s.address || [s.city, s.state].filter(Boolean).join(', ');
    case 'gender': return s.gender || '';
    case 'dob': return s.dob ? new Date(s.dob).toISOString().split('T')[0] : '';
    case 'aadhaar_number': return s.aadhaar_number || '';
    case 'pan_number': return s.pan_number || '';
    case 'bank_details': return `${s.bank_name || ''} ${s.bank_account_number || ''}`;
    case 'max_lectures': return s.max_lectures_per_day ? `${s.max_lectures_per_day}/day` : '';
    default: return '';
  }
};

export const Users: React.FC = () => {
  const { staff, addStaff, setStaff, currentUser, addToast, branches } = useApp();
  const navigate = useNavigate();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingEmail, setEditingEmail] = useState<string | null>(null);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [staffProfileTab, setStaffProfileTab] = useState<'overview' | 'employment' | 'salary' | 'access'>('overview');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  const isBranchAdmin = currentUser?.role === 'branch-admin';
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('All');
  const [filterBranch, setFilterBranch] = useState(isBranchAdmin ? currentUser.branch || 'All' : 'All');
  const [selectedCustomColumn, setSelectedCustomColumn] = useState<StaffColumnKey>('contact_number');

  const [loading, setLoading] = useState(false);
  const [apiStaff, setApiStaff] = useState<any[]>([]);
  const [totalStaff, setTotalStaff] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const itemsPerPage = 10;

  const fetchStaff = async () => {
    setLoading(true);
    try {
      const filters = {
        page: currentPage,
        limit: itemsPerPage,
        search: searchTerm || undefined,
        branchId: !isBranchAdmin && filterBranch !== 'All' ? filterBranch : undefined,
        role: filterRole !== 'All' ? filterRole : undefined,
      };
      const res = await staffApi.list(filters);
      if (res?.data) {
        setApiStaff(res.data);
        setTotalStaff(res.pagination?.total || res.data.length);
      }
    } catch (err) {
      console.error('Failed to fetch staff:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await staffApi.delete(deleteTarget.id);
      addToast(`Staff member "${deleteTarget.first_name || ''} ${deleteTarget.last_name || ''}" deleted successfully.`, 'success');
      setDeleteTarget(null);
      if (selectedStaff && String(selectedStaff.id) === String(deleteTarget.id)) {
        setSelectedStaff(null);
      }
      fetchStaff();
    } catch (err: any) {
      addToast(err?.response?.data?.message || err?.message || 'Failed to delete staff member', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleViewStaff = (s: any) => {
    const fullName = ((s.first_name || '') + ' ' + (s.last_name || '')).trim() || s.name || 'Personnel Member';
    let branchName = s.primary_branch_name || s.branch || 'Main Branch';
    if (s.branch_ids) {
      try {
        const bIds = Array.isArray(s.branch_ids) ? s.branch_ids : JSON.parse(s.branch_ids);
        const names = bIds.map((id: any) => {
          const b = (branches || []).find(branch => String(branch.id) === String(id));
          return b ? b.name : null;
        }).filter(Boolean);
        if (names.length > 0) {
          branchName = names.join(', ');
        }
      } catch (e) {}
    }

    let subjectsTaught = '';
    if (Array.isArray(s.subjects)) {
      subjectsTaught = s.subjects.join(', ');
    } else if (s.subjects_taught) {
      subjectsTaught = s.subjects_taught;
    }

    setSelectedStaff({
      id: s.id,
      employeeId: s.employee_id || `EMP-${s.id}`,
      name: fullName,
      firstName: s.first_name || '',
      lastName: s.last_name || '',
      email: s.email || s.official_email || '',
      mobile: s.contact_number || s.mobile || '',
      alternateMobile: s.alternate_mobile || '',
      role: s.role_name || s.role || (s.employee_type === 'Teaching' ? 'Teacher' : (s.designation || 'Staff')),
      designation: s.designation || '',
      department: s.department || '',
      branch: branchName,
      additionalBranches: [],
      roles: s.role_name ? s.role_name.split(', ') : (s.role ? [s.role] : []),
      status: s.status || 'Active',
      employeeType: s.employee_type || 'Teaching',
      employmentType: s.employment_type || 'Full-Time',
      employmentStatus: s.status || 'Active',
      joiningDate: s.joining_date ? new Date(s.joining_date).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '',
      experience: s.experience || '',
      qualification: s.qualification || '',
      gender: s.gender || '',
      dob: s.dob ? new Date(s.dob).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '',
      aadhaar: s.aadhaar_number || '',
      pan: s.pan_number || '',
      address: s.address || s.current_address || '',
      city: s.city || '',
      state: s.state || '',
      pinCode: s.pincode || '',
      salaryType: s.salary_type || 'Monthly',
      monthlySalary: s.salary_amount || (s.monthly_salary ? Number(s.monthly_salary) : null),
      bankName: s.bank_name || '',
      accountHolder: s.bank_account_holder || fullName,
      accountNumber: s.bank_account_number || '',
      ifsc: s.bank_ifsc || '',
      upiId: s.upi_id || '',
      subjects_taught: subjectsTaught,
      raw: s
    } as any);
  };

  React.useEffect(() => {
    fetchStaff();
  }, [currentPage, searchTerm, filterBranch, filterRole]);

  const ROLE_FILTER_OPTIONS = isBranchAdmin
    ? [
        { value: 'All', label: 'All Operational Roles' },
        { value: 'Teacher', label: 'Teacher / Faculty' },
        { value: 'Counsellor', label: 'Counsellor' },
        { value: 'Finance', label: 'Finance Staff' },
        { value: 'Non-Teaching', label: 'Non-Teaching Staff' }
      ]
    : [
        { value: 'All', label: 'All Roles' },
        { value: 'Teacher', label: 'Teacher / Faculty' },
        { value: 'Branch Admin', label: 'Branch Admin' },
        { value: 'Institute Admin', label: 'Institute Admin' },
        { value: 'Counsellor', label: 'Counsellor' },
        { value: 'Finance', label: 'Finance Staff' },
        { value: 'Teaching', label: 'Teaching Staff' },
        { value: 'Non-Teaching', label: 'Non-Teaching Staff' }
      ];

  const branchFilterOptions = [
    { value: 'All', label: 'All Branches' },
    ...(branches && branches.length > 0 
      ? branches.map(b => ({ value: b.name, label: b.name }))
      : Array.from(new Set(staff.map(s => s.branch))).filter(Boolean).map(b => ({ value: b as string, label: b as string }))
    )
  ];

  const filteredAndSortedStaff = apiStaff;

  const handleExportCSV = () => {
    const selectedColDef = STAFF_COLUMN_OPTIONS.find(c => c.value === selectedCustomColumn) || STAFF_COLUMN_OPTIONS[0];
    const dataToExport = filteredAndSortedStaff.map(s => ({
      'Employee ID': (s as any).employee_id || s.id || '',
      'Name': s.first_name + ' ' + (s.last_name || ''),
      'Official Email': s.email || '',
      'Primary Branch': s.primary_branch_name || s.branch || '',
      [selectedColDef.header]: getColumnTextValue(s, selectedCustomColumn),
      'Role': s.employee_type || s.role || 'Staff',
      'Status': s.status || ''
    }));

    if (dataToExport.length === 0) return;
    const csvRows = [];
    const headers = Object.keys(dataToExport[0]);
    csvRows.push(headers.join(','));

    for (const row of dataToExport) {
      const values = headers.map(header => {
        const val = row[header as keyof typeof row] || '';
        const escaped = ('' + val).replace(/"/g, '\\"');
        return `"${escaped}"`;
      });
      csvRows.push(values.join(','));
    }

    const csvContent = "data:text/csv;charset=utf-8," + csvRows.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `staff_directory_${selectedCustomColumn}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  const totalPages = Math.ceil(totalStaff / itemsPerPage);
  const paginatedStaff = apiStaff;

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [role, setRole] = useState('Teacher');
  const [branch, setBranch] = useState('Mumbai West');

  const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const handleOpenAddModal = () => {
    setEditingEmail(null);
    setName('');
    setEmail('');
    setEmailError('');
    setRole('Teacher');
    setBranch(currentUser?.role === 'branch-admin' ? currentUser.branch || 'Mumbai West' : 'Mumbai West');
    setShowAddModal(true);
  };

  const handleEditStaff = (item: any) => {
    setEditingEmail(item.email);
    setName(item.name);
    setEmail(item.email);
    setEmailError('');
    setRole(item.role);
    setBranch(item.branch);
    setShowAddModal(true);
  };

  const handleDeactivateStaff = (emailVal: string) => {
    setStaff(prev => prev.map(s => s.email === emailVal
      ? { ...s, status: s.status === 'Active' ? 'Inactive' : 'Active' }
      : s
    ));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError('');

    if (!name.trim()) return;

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setEmailError('Email address is required.');
      return;
    }

    if (!EMAIL_REGEX.test(cleanEmail)) {
      setEmailError('Please enter a valid email address without invalid characters (e.g. name@apexiit.com)');
      return;
    }

    // Check duplicate email
    const duplicate = staff.some(s => 
      s.email && s.email.toLowerCase() === cleanEmail.toLowerCase() && 
      (!editingEmail || s.email.toLowerCase() !== editingEmail.toLowerCase())
    );
    if (duplicate) {
      setEmailError('A staff member with this email address already exists.');
      return;
    }

    if (editingEmail) {
      setStaff(prev => prev.map(s => s.email === editingEmail
        ? { ...s, name: name.trim(), email: cleanEmail, role, branch }
        : s
      ));
    } else {
      const names = name.trim().split(/\s+/);
      const firstName = names[0] || '';
      const lastName = names.slice(1).join(' ') || '';
      addStaff({
        firstName,
        lastName,
        name: name.trim(),
        email: cleanEmail,
        mobile: '9876543210',
        role,
        branch,
        status: 'Active'
      });
    }

    setName('');
    setEmail('');
    setEmailError('');
    setShowAddModal(false);
    setEditingEmail(null);
    addToast(editingEmail ? 'Staff details updated successfully!' : 'New staff profile created successfully!', 'success');
  };

  if (showAddModal) {
    return (
      <div className="space-y-6 w-full animate-fade-in">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddModal(false)}
            className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer"
          >
            <ArrowLeft size={26} />
          </button>
          <div>
            <h2 className="text-2xl font-display font-bold text-slate-900">
              {editingEmail ? `Edit Staff Profile: ${name}` : 'Create Staff Profile'}
            </h2>
            <p className="text-sm text-slate-500">Configure staff account parameters, login access, branch office, and security roles.</p>
          </div>
        </div>

        <div className="w-full">
          <form onSubmit={handleFormSubmit} noValidate className="space-y-4">
            <Input label="Full Name" required placeholder="e.g. Mrs. Seema Deshpande" value={name} onChange={(e) => setName(e.target.value)} />
            <Input 
              label="Email Address Login" 
              type="email" 
              required 
              placeholder="seema@apexiit.com" 
              value={email} 
              error={emailError}
              onChange={(e) => {
                setEmail(e.target.value);
                if (emailError && (EMAIL_REGEX.test(e.target.value.trim()) || !e.target.value.trim())) {
                  setEmailError('');
                }
              }} 
            />
            <div className="grid grid-cols-2 gap-4">
              <Select 
                label="Primary Security Role" 
                value={role} 
                onChange={(e) => setRole(e.target.value)} 
                options={[
                  { value: 'SuperAdmin', label: 'Super Admin' },
                  { value: 'Admin', label: 'Admin Executive' },
                  { value: 'Counsellor', label: 'Counsellor' },
                  { value: 'Teacher', label: 'Teacher / Faculty' },
                  { value: 'Finance', label: 'Finance Staff' }
                ]}
              />
              <Select 
                label="Allotted Branch Office" 
                value={branch} 
                onChange={(e) => setBranch(e.target.value)} 
                options={[
                  { value: 'Mumbai West', label: 'Mumbai West' },
                  { value: 'Pune Camp', label: 'Pune Camp' }
                ]}
                disabled={currentUser?.role === 'branch-admin'}
              />
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setShowAddModal(false)}>Cancel</Button>
              <Button type="submit" variant="primary">
                {editingEmail ? 'Update Details' : 'Register Staff Member'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  if (selectedStaff) {
    return (
      <div className="space-y-6 w-full animate-fade-in">
        {/* Header section with back button & actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedStaff(null)}
              className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer"
            >
              <ArrowLeft size={26} />
            </button>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-2xl font-display font-bold text-slate-900">
                  Staff Profile: {selectedStaff.name}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  Profile View
                </span>
              </div>
              <p className="text-sm text-slate-500">Review complete employee details, assignments, salary structure, and security credentials.</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <Button
              variant="primary"
              onClick={() => navigate(`/staff/${selectedStaff.id}`, { state: { staffData: (selectedStaff as any).raw || selectedStaff } })}
              className="flex items-center gap-1.5 font-semibold"
            >
              <Edit3 size={15} /> Edit Profile
            </Button>
            <Button
              variant="secondary"
              onClick={() => setDeleteTarget((selectedStaff as any).raw || selectedStaff)}
              className="flex items-center gap-1.5 font-semibold text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
            >
              <Trash2 size={15} /> Delete Staff
            </Button>
          </div>
        </div>

        <div className="space-y-6 flex flex-col h-full bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
          {/* Tabs selectors inside profile */}
          <div className="flex gap-2 border-b border-slate-200 overflow-x-auto">
            {[
              { id: 'overview', label: '1. Personal & Contact' },
              { id: 'employment', label: '2. Employment & Assignment' },
              { id: 'salary', label: '3. Salary & Banking' },
              { id: 'access', label: '4. System & Access' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStaffProfileTab(tab.id as any)}
                className={`py-3 px-4 font-bold text-sm border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                  staffProfileTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Profile Tab Contents */}
          <div className="py-2">
            {staffProfileTab === 'overview' && (
              <div className="space-y-6">
                {/* Header summary card */}
                <div className="flex items-center gap-5 p-5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl">
                  <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center text-white font-black text-xl shadow-md">
                    {selectedStaff.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h4 className="font-display font-extrabold text-slate-900 text-lg">{selectedStaff.name}</h4>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1.5 text-xs font-medium text-slate-500">
                      <span>Staff ID: <strong className="font-mono text-slate-700">{selectedStaff.employeeId || `EMP-${selectedStaff.id || '2938'}`}</strong></span>
                      <span>&bull;</span>
                      <span>Role: <strong className="text-slate-700">{selectedStaff.role}</strong></span>
                      <span>&bull;</span>
                      <span>Primary Branch: <strong className="text-slate-700">{selectedStaff.branch}</strong></span>
                      <span>&bull;</span>
                      <span>Designation: <strong className="text-slate-700">{selectedStaff.designation || 'Specialist Staff'}</strong></span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Basic details */}
                  <Card className="p-5 border border-slate-200/80 shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                      1. Identity &amp; Personal Info
                    </h3>
                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Gender</span>
                        <strong className="text-slate-700">{selectedStaff.gender || '—'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Date of Birth</span>
                        <strong className="text-slate-700">{selectedStaff.dob || '—'}</strong>
                      </div>
                      {(selectedStaff as any).subjects_taught && (
                        <div className="col-span-2">
                          <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Subjects Taught</span>
                          <strong className="text-blue-700">{(selectedStaff as any).subjects_taught}</strong>
                        </div>
                      )}
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Aadhaar Card No</span>
                        <strong className="text-slate-700 font-mono">{selectedStaff.aadhaar || (selectedStaff as any).aadhaar_number || '—'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">PAN Card No</span>
                        <strong className="text-slate-700 font-mono uppercase">{selectedStaff.pan || (selectedStaff as any).pan_number || '—'}</strong>
                      </div>
                    </div>
                  </Card>

                  {/* Contact details */}
                  <Card className="p-5 border border-slate-200/80 shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                      2. Contact Details
                    </h3>
                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                      <div className="col-span-2">
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Email Address</span>
                        <strong className="text-slate-750 font-mono text-xs block truncate">{selectedStaff.email}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Primary Mobile</span>
                        <strong className="text-slate-700 font-mono">{selectedStaff.mobile || (selectedStaff as any).contact_number || '—'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Alternate Mobile</span>
                        <strong className="text-slate-700 font-mono">{selectedStaff.alternateMobile || '—'}</strong>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Address */}
                <Card className="p-5 border border-slate-200/80 shadow-sm">
                  <span className="text-slate-400 text-xs font-semibold uppercase block mb-1">Residential Address</span>
                  <strong className="text-slate-700 font-medium block mb-3">{selectedStaff.address || (selectedStaff as any).currentAddress || '—'}</strong>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400 text-[10px] font-semibold uppercase block">City</span>
                      <strong className="text-slate-600">{selectedStaff.city || '—'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] font-semibold uppercase block">State</span>
                      <strong className="text-slate-600">{selectedStaff.state || '—'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] font-semibold uppercase block">Pin Code</span>
                      <strong className="text-slate-600 font-mono">{selectedStaff.pinCode || (selectedStaff as any).pin_code || '—'}</strong>
                    </div>
                  </div>
                </Card>
              </div>
            )}

            {staffProfileTab === 'employment' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Employment setup */}
                  <Card className="p-5 border border-slate-200/80 shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                      Employment Setup Details
                    </h3>
                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Employee Type</span>
                        <strong className="text-slate-750">{selectedStaff.employeeType || 'Teaching'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Department</span>
                        <strong className="text-slate-750">{selectedStaff.department || 'Academics'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Joining Date</span>
                        <strong className="text-slate-700">{selectedStaff.joiningDate || (selectedStaff as any).joining_date || '—'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Employment Model</span>
                        <strong className="text-slate-700">{selectedStaff.employmentType || (selectedStaff as any).employment_type || 'Full-Time'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Work Experience</span>
                        <strong className="text-slate-700">{selectedStaff.experience ? `${selectedStaff.experience} Years` : '—'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Employment Status</span>
                        <strong className="text-slate-700">{selectedStaff.employmentStatus || (selectedStaff as any).employment_status || 'Active'}</strong>
                      </div>
                      <div className="col-span-2">
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Qualifications</span>
                        <strong className="text-slate-700 block">{selectedStaff.qualification || '—'}</strong>
                      </div>
                    </div>
                  </Card>

                  {/* Branch Office details */}
                  <Card className="p-5 border border-slate-200/80 shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                      Branch &amp; Security Roles Assigned
                    </h3>
                    <div className="space-y-4 text-sm">
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Primary Branch Office</span>
                        <strong className="text-slate-700 font-bold">{selectedStaff.branch}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Additional Hub Permissions</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {selectedStaff.additionalBranches && selectedStaff.additionalBranches.length > 0 ? (
                            selectedStaff.additionalBranches.map((b: string) => (
                              <span key={b} className="bg-slate-100 text-slate-700 text-xs font-semibold px-2 py-0.5 rounded border border-slate-200">{b}</span>
                            ))
                          ) : (
                            <span className="text-slate-455 italic text-xs">No additional branches configured</span>
                          )}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Assigned Security Roles</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {selectedStaff.roles && selectedStaff.roles.length > 0 ? (
                            selectedStaff.roles.map((r: string) => (
                              <span key={r} className="bg-blue-50 text-blue-700 text-xs font-semibold px-2 py-0.5 rounded border border-blue-100">{r}</span>
                            ))
                          ) : (
                            <span className="bg-blue-50 text-blue-700 text-xs font-semibold px-2 py-0.5 rounded border border-blue-100">{selectedStaff.role}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Teacher configurations */}
                {(selectedStaff.role?.toLowerCase().includes('teacher') || selectedStaff.employeeType === 'Teaching') && (
                  <Card className="p-5 border border-slate-200/80 shadow-sm space-y-4">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">
                      Teacher Specific Academic Assignments
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-sm">
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Subjects Assigned</span>
                        <strong className="text-slate-700 block">{selectedStaff.subjects?.join(', ') || 'Chemistry, Biochemistry'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Assigned Courses</span>
                        <strong className="text-slate-700 block">{selectedStaff.coursesAssigned?.join(', ') || 'JEE Prep, Advanced Medical Prep'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Lecture Limits</span>
                        <strong className="text-slate-700 block">{selectedStaff.maxLecturesPerDay || 4} lectures/day &bull; {selectedStaff.maxLecturesPerWeek || 20} lectures/week</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Teaching Modes</span>
                        <strong className="text-slate-700 block">{selectedStaff.teachingMode?.join(', ') || 'Offline, Hybrid'}</strong>
                      </div>
                    </div>
                  </Card>
                )}
              </div>
            )}

            {staffProfileTab === 'salary' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div className="bg-slate-50 p-5 border border-slate-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Compensation Model</span>
                    <div className="text-3xl font-display font-extrabold text-slate-800 mt-1">{selectedStaff.salaryType || 'Monthly Salary'}</div>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-1">Structured Payroll Cycle</span>
                  </div>
                  <div className="bg-blue-50/50 p-5 border border-blue-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Payout Rate</span>
                    <div className="text-3xl font-display font-extrabold text-blue-700 mt-1">
                      ₹{selectedStaff.monthlySalary ? selectedStaff.monthlySalary.toLocaleString() : selectedStaff.hourlyRate ? `${selectedStaff.hourlyRate.toLocaleString()}/hr` : '85,000'}
                    </div>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-1">Gross Salary / Base Hourly Charge</span>
                  </div>
                  <div className="bg-emerald-50/50 p-5 border border-emerald-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">PF &amp; Taxes Deductions</span>
                    <div className="text-3xl font-display font-extrabold text-emerald-700 mt-1">Structure Configured</div>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-1">Professional Tax &amp; TDS Enforced</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="p-5 border border-slate-200/80 shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                      Bank Payout Account Details
                    </h3>
                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Beneficiary Bank</span>
                        <strong className="text-slate-700">{selectedStaff.bankName || 'HDFC Bank Ltd'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Account Holder Name</span>
                        <strong className="text-slate-700">{selectedStaff.accountHolder || selectedStaff.name}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Account Number</span>
                        <strong className="text-slate-750 font-mono block truncate">{selectedStaff.accountNumber || '50100492837311'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">IFSC Routing Code</span>
                        <strong className="text-slate-700 font-mono uppercase">{selectedStaff.ifsc || 'HDFC0000120'}</strong>
                      </div>
                      <div className="col-span-2 border-t border-slate-50 pt-2">
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Primary UPI Address</span>
                        <strong className="text-slate-700 font-mono">{selectedStaff.upiId || `${selectedStaff.mobile || '9876543210'}@hdfcbank`}</strong>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-5 border border-slate-200/80 shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                      Government Statutory Registrations
                    </h3>
                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Professional Tax (PT)</span>
                        <strong className="text-emerald-700">PT Deductible</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">TDS Deductions</span>
                        <strong className="text-emerald-700">TDS Applicable (10% standard)</strong>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            )}

            {staffProfileTab === 'access' && (
              <div className="space-y-6">
                <Card className="p-5 border border-slate-200/80 shadow-sm max-w-2xl">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                    Portal Security &amp; Credentials
                  </h3>
                  <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                    <div>
                      <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Login Account Username</span>
                      <strong className="text-slate-750 font-mono block">{selectedStaff.username || selectedStaff.email}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Permission Profile</span>
                      <strong className="text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-xs">{selectedStaff.permissionProfile || `${selectedStaff.role} Access Profile`}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Mobile Login Permission</span>
                      <strong className="text-emerald-700">Enabled</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs font-semibold uppercase block mb-0.5">Next Force Pass Reset</span>
                      <strong className="text-slate-450 italic">Not Required (Pass Reset Checked)</strong>
                    </div>
                  </div>
                </Card>
              </div>
            )}
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100 mt-6">
            <Button type="button" variant="secondary" onClick={() => setSelectedStaff(null)}>
              Close Profile
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Staff Members Directory</h2>
          <p className="text-base text-slate-500 mt-2">
            {isBranchAdmin
              ? "Manage branch personnel profiles, assign operational roles, and update staff details."
              : "Manage personnel profile records, assign security role boundaries, and allocate active branch hubs."}
          </p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="secondary" onClick={() => setIsImportModalOpen(true)} className="flex items-center gap-1.5 font-bold">
            <Upload size={14} /> Bulk Import
          </Button>
          <Button variant="secondary" onClick={handleExportCSV}>
            Export CSV
          </Button>
          <Button variant="primary" style={{ gap: '6px' }} className="px-5 py-2.5 text-sm shadow-sm" onClick={() => navigate('/staff/new')}>
            <Plus size={18} /> Add Staff
          </Button>
        </div>
      </div>

      {/* Search, Filter, Sort Controls & Export CSV */}
      <div className="flex flex-col md:flex-row gap-4 bg-white border border-slate-200 p-4 rounded-xl shadow-sm items-end justify-between">
        <div className={`grid grid-cols-1 ${isBranchAdmin ? 'sm:grid-cols-3' : 'sm:grid-cols-4'} gap-4 flex-1 w-full items-end`}>
          <Input
            label="Search"
            placeholder="Search by ID, name, email..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
          />
          <Select
            label="Role"
            value={filterRole}
            onChange={(e) => {
              setFilterRole(e.target.value);
              setCurrentPage(1);
            }}
            options={ROLE_FILTER_OPTIONS}
          />
          {!isBranchAdmin && (
            <Select
              label="Branch"
              value={filterBranch}
              onChange={(e) => {
                setFilterBranch(e.target.value);
                setCurrentPage(1);
              }}
              options={branchFilterOptions}
            />
          )}
          <Select
            label="Display Column"
            value={selectedCustomColumn}
            onChange={(e) => setSelectedCustomColumn(e.target.value as StaffColumnKey)}
            options={STAFF_COLUMN_OPTIONS.map(opt => ({
              value: opt.value,
              label: opt.label
            }))}
          />
        </div>
        <div className="flex gap-2 shrink-0">
          <Button
            variant="secondary"
            onClick={() => {
              setSearchTerm('');
              setFilterRole('All');
              setFilterBranch('All');
              setCurrentPage(1);
            }}
            className="text-slate-500 hover:text-slate-700"
          >
            Clear
          </Button>
          <Button variant="secondary" onClick={handleExportCSV}>Export CSV</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            Staff Directory Registry {loading && <Loader2 size={16} className="inline animate-spin ml-2" />}
          </CardTitle>
        </CardHeader>
        <Table 
          minWidth="100%"
          colWidths={['15%', '19%', '15%', '15%', '13%', '10%', '13%']}
          headers={[
            { label: 'ID', minWidth: '120px' },
            { label: 'Staff Name', minWidth: '140px' },
            { label: 'Branch / Hubs', minWidth: '120px' },
            { label: (STAFF_COLUMN_OPTIONS.find(c => c.value === selectedCustomColumn) || STAFF_COLUMN_OPTIONS[0]).header, minWidth: '120px' },
            { label: 'Assigned Role', minWidth: '100px' },
            { label: 'Status', minWidth: '80px', align: 'center' },
            { label: 'Actions', minWidth: '95px', align: 'center' }
          ]}
        >
          {paginatedStaff.map((s, idx) => {
            const nameStr = ((s.first_name || '') + ' ' + (s.last_name || '')).trim();
            const empId = (s as any).employee_id || s.id || `EMP-${idx + 1}`;
            
            let branchStr = s.primary_branch_name || s.branch_id || 'Unknown';
            if (s.branch_ids) {
              try {
                const bIds = Array.isArray(s.branch_ids) ? s.branch_ids : JSON.parse(s.branch_ids);
                const names = bIds.map((id: any) => {
                  const b = (branches || []).find(branch => String(branch.id) === String(id));
                  return b ? b.name : null;
                }).filter(Boolean);
                if (names.length > 0) {
                  branchStr = names.join(', ');
                }
              } catch (e) {}
            }

            const roleStr = s.role_name || (s.employee_type === 'Teaching' ? 'Teacher' : (s.designation || s.employee_type || 'Staff'));
            const statusStr = (s.status || 'Active').toLowerCase();
            
            let statusBadgeClass = 'bg-red-50 text-red-600 border-red-200';
            if (statusStr === 'active') {
              statusBadgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
            } else if (statusStr === 'inactive' || statusStr === 'suspended') {
              statusBadgeClass = 'bg-amber-50 text-amber-700 border-amber-200';
            }

            return (
              <tr 
                key={idx} 
                className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                onClick={() => handleViewStaff(s)}
              >
                <td className="px-3.5 py-2.5 font-mono text-xs font-semibold text-slate-600 whitespace-nowrap truncate max-w-[140px]" title={empId}>
                  {empId}
                </td>
                <td className="px-3.5 py-2.5 whitespace-nowrap truncate max-w-[180px]">
                  <div className="font-bold text-sm text-slate-900 whitespace-nowrap truncate" title={nameStr || 'Personnel Member'}>
                    {nameStr || 'Personnel Member'}
                  </div>
                </td>
                <td className="px-3.5 py-2.5 text-xs font-medium text-slate-700 whitespace-nowrap truncate max-w-[150px]">
                  <span className="whitespace-nowrap truncate block" title={branchStr}>
                    {branchStr}
                  </span>
                </td>
                <td className="px-3.5 py-2.5 whitespace-nowrap truncate max-w-[150px]">
                  {renderCustomColumnCell(s, selectedCustomColumn)}
                </td>
                <td className="px-3.5 py-2.5 whitespace-nowrap truncate max-w-[130px]">
                  <span className={`inline-flex px-2.5 py-0.5 rounded text-xs font-semibold border whitespace-nowrap truncate ${roleBadgeColors(roleStr)}`}>
                    {roleStr}
                  </span>
                </td>
                <td className="px-3.5 py-2.5 whitespace-nowrap text-center">
                  <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-bold capitalize border whitespace-nowrap ${statusBadgeClass}`}>
                    {s.status || 'Active'}
                  </span>
                </td>
                <td className="px-3.5 py-2.5 whitespace-nowrap text-center" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center justify-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      title="View Profile Details"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                      onClick={() => handleViewStaff(s)}
                    >
                      <Eye size={16} />
                    </button>
                    <button
                      type="button"
                      title="Edit Staff Form"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                      onClick={() => navigate(`/staff/${s.id}`, { state: { staffData: s } })}
                    >
                      <Edit3 size={16} />
                    </button>
                    <button
                      type="button"
                      title="Delete Staff"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                      onClick={() => setDeleteTarget(s)}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </Table>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={totalStaff}
          pageSize={itemsPerPage}
          onPageChange={setCurrentPage}
        />
      </Card>

      {/* Delete Staff Confirmation Modal */}
      <Modal
        isOpen={Boolean(deleteTarget)}
        onClose={() => !isDeleting && setDeleteTarget(null)}
        title="Delete Staff Member"
        size="md"
        footer={
          <div className="flex items-center justify-end gap-2.5 w-full">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setDeleteTarget(null)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="danger"
              className="bg-red-600 hover:bg-red-700 text-white flex items-center gap-1.5"
              onClick={handleConfirmDelete}
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
              {isDeleting ? 'Deleting...' : 'Confirm Delete'}
            </Button>
          </div>
        }
      >
        <div className="flex items-start gap-3.5 p-1">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 text-red-600">
            <AlertTriangle size={20} />
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-800">
              Are you sure you want to delete <strong className="text-slate-900">{deleteTarget ? `${deleteTarget.first_name || ''} ${deleteTarget.last_name || ''}`.trim() || 'this staff member' : ''}</strong>?
            </p>
            <p className="text-xs text-slate-500">
              This action will mark the staff member as <span className="font-semibold text-red-600">Deleted</span> and revoke their portal access immediately.
            </p>
          </div>
        </div>
      </Modal>

      <BulkImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        title="Bulk Import Staff Directory"
        description="Select a CSV spreadsheet to import multiple staff profiles at once. Columns must match the template below exactly."
        sampleHeaders={['Name', 'Email', 'Role', 'Mobile', 'Branch']}
        sampleRows={[
          ['Rajesh Kadam', 'rajesh@apexiit.com', 'teacher', '9811223344', 'Mumbai West'],
          ['Meera Sen', 'meera@apexiit.com', 'counsellor', '9677889900', 'Pune Camp']
        ]}
        onImport={(importedRows) => {
          const newStaff = importedRows.map((row, rIdx) => {
            const fullName = row['Name'] || 'Imported Personnel';
            const parts = fullName.trim().split(/\s+/);
            const firstName = parts[0] || 'Imported';
            const lastName = parts.slice(1).join(' ') || 'Personnel';
            return {
              id: `STF-${Math.floor(10000 + Math.random() * 90000)}-${rIdx}`,
              firstName,
              lastName,
              name: fullName,
              email: row['Email'] || `staff-${Math.floor(1000 + Math.random() * 9000)}@vidyasetu.com`,
              role: row['Role'] || 'teacher',
              mobile: row['Mobile'] || '9999999999',
              branch: row['Branch'] || 'Mumbai West',
              designation: row['Role'] === 'teacher' ? 'Senior Lecturer' : 'Admissions Manager',
              status: 'Active' as const,
              joiningDate: new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
            } as any;
          });
          setStaff(prev => [...newStaff, ...prev] as any[]);
        }}
      />
    </div>
  );
};

const roleBadgeColors = (role: string) => {
  const r = (role || '').toLowerCase();
  if (r.includes('superadmin') || r.includes('saas')) return 'bg-purple-50 text-purple-700 border-purple-200';
  if (r.includes('admin') || r.includes('institute') || r.includes('branch')) return 'bg-blue-50 text-blue-700 border-blue-200';
  if (r.includes('counsellor')) return 'bg-amber-50 text-amber-700 border-amber-200';
  if (r.includes('teacher') || r.includes('teaching') || r.includes('faculty')) return 'bg-orange-50 text-orange-700 border-orange-200';
  if (r.includes('finance')) return 'bg-pink-50 text-pink-700 border-pink-200';
  return 'bg-slate-50 text-slate-700 border-slate-200';
};
