import api from './api';

export interface StudentRosterItem {
  id: number;
  tenant_id: number;
  primary_branch_id: number;
  branch_name?: string;
  student_code: string;
  full_name: string;
  dob?: string;
  gender?: string;
  mobile?: string;
  email?: string;
  street?: string;
  city?: string;
  state?: string;
  pincode?: string;
  category?: string;
  school_name?: string;
  current_class?: string;
  target_exam?: string;
  year_of_attempt?: string;
  blood_group?: string;
  profile_photo_url?: string;
  status: number | string;
  created_at: string;
  updated_at: string;
  enrollment_id?: number;
  batch_id?: number;
  batch_name?: string;
  batch_code?: string;
  academic_year_id?: number;
  academic_year_name?: string;
  guardian_name?: string;
  guardian_mobile?: string;
  guardian_relation?: string;
  guardian_email?: string;
  total_fees_gross?: number;
  total_concession?: number;
  total_fees?: number;
  down_payment?: number;
  installment_count?: number;
  installment_amount?: number;
  fees_paid?: number;
  fees_outstanding?: number;
  fees_remaining?: number;
  expected_due_till_date?: number;
  fees_overdue?: number;
  is_defaulter?: boolean;
  fee_status?: string;
}

export interface FeeAssignment {
  id: number;
  gross_amount: number;
  total_concession?: number;
  discount_amount?: number;
  net_amount: number;
  down_payment?: number;
  downpayment_amount?: number;
  installment_count: number;
  installment_amount: number;
  paid_amount: number;
  balance_amount?: number;
  balance_due?: number;
  status: 'pending' | 'partially_paid' | 'paid' | 'overdue' | string;
  created_at: string;
}

export interface StudentInvoice {
  id: number;
  invoice_number: string;
  installment_number: number;
  issue_date: string;
  due_date: string;
  amount?: number;
  billed_amount?: number;
  paid_amount: number;
  balance_due: number;
  status: 'pending' | 'partially_paid' | 'paid' | 'overdue' | string;
  payment_date?: string;
  payment_mode?: string;
  transaction_reference?: string;
  transaction_ref?: string;
}

export interface StudentDetail extends StudentRosterItem {
  enrolled_date?: string;
  enrollment_status?: string;
  guardian_id?: number;
  guardian_occupation?: string;
  subjectBundle?: {
    id: number;
    name: string;
    description?: string;
    subject_ids?: number[];
  } | null;
  subject_selection_type?: 'bundle' | 'custom';
  bundle_id?: number | null;
  custom_subject_ids?: number[] | null;
  subjectsList?: Array<{
    id: number;
    name: string;
    code: string;
  }>;
  feeAssignment?: FeeAssignment | null;
  invoicesList?: StudentInvoice[];
}

export interface AcademicOptions {
  branch?: { id: number; name: string };
  branches: Array<{ id: number; name: string }>;
  courses: Array<{ id: number; name: string; code?: string }>;
  programs: Array<{ id: number; course_id: number; name: string; code?: string }>;
  courseBranches?: Array<{ course_id: number; branch_id: number }>;
  branchPrograms?: Array<{ program_id: number; course_id: number; branch_id: number }>;
  levels: Array<{ id: number; course_id?: number; program_id?: number; name: string }>;
  batches: Array<{ id: number; branch_id: number; level_id: number; name: string; code: string }>;
  bundles: Array<{ id: number; branch_id: number; level_id: number; name: string; description: string; fee_amount?: number; subject_ids: number[] }>;
  subjects?: Array<{ id: number; name: string; code: string; type?: string }>;
  levelSubjects?: Array<{ level_id: number; course_id?: number; program_id?: number; id: number; name: string; code: string; type?: string; fee_amount?: number }>;
  academicYears: Array<{ id: number; name: string; status: string }>;
}

export interface CreateStudentPayload {
  primary_branch_id: number;
  full_name: string;
  mobile?: string;
  email?: string;
  dob?: string;
  gender?: string;
  blood_group?: string;
  street?: string;
  city?: string;
  state?: string;
  pincode?: string;
  category?: string;
  school_name?: string;
  current_class?: string;
  target_exam?: string;
  year_of_attempt?: string;
  batch_id?: number;
  bundle_id?: number;
  subject_selection_type?: 'bundle' | 'custom';
  custom_subject_ids?: number[];
  academic_year_id?: number;
  guardian_name?: string;
  guardian_mobile?: string;
  guardian_relation?: string;
  guardian_email?: string;
  guardian_occupation?: string;
  gross_amount?: number | string;
  discount_amount?: number | string;
  downpayment_amount?: number | string;
  installment_count?: number | string;
  status?: string;
}

const getStudentBasePath = (): string => {
  try {
    const savedUser = localStorage.getItem('vs_current_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      const role = String(user.role || '').toLowerCase().replace(/_/g, '-');
      const userType = String(user.userType || '').toLowerCase();
      if (role === 'finance' || userType === 'finance') {
        return '/branch/finance/students';
      }
      if (role === 'branch-admin' || role === 'branch_admin') {
        return '/branch/students';
      }
    }
  } catch {
    // fallback
  }
  return '/admin/students';
};

export const getStudents = async (params: {
  page?: number;
  limit?: number;
  search?: string;
  branchId?: string | number;
  batchId?: string | number;
  bundleId?: string | number;
  courseId?: string | number;
  programId?: string | number;
  levelId?: string | number;
  academicYearId?: string | number;
  status?: string;
  feeStatus?: string;
}) => {
  const basePath = getStudentBasePath();
  const cleanParams = { ...params };
  if (basePath === '/branch/students') {
    delete cleanParams.branchId;
  }
  const response = await api.get(basePath, { params: cleanParams });
  return response.data;
};

export const getStudentById = async (id: number) => {
  const basePath = getStudentBasePath();
  const response = await api.get(`${basePath}/${id}`);
  return response.data;
};

export const createStudent = async (payload: CreateStudentPayload) => {
  const basePath = getStudentBasePath();
  const cleanPayload = { ...payload };
  if (basePath === '/branch/students' && !cleanPayload.primary_branch_id) {
    delete (cleanPayload as any).primary_branch_id;
  }
  const response = await api.post(basePath, cleanPayload);
  return response.data;
};

export const updateStudent = async (id: number, payload: Partial<CreateStudentPayload>) => {
  const basePath = getStudentBasePath();
  const cleanPayload = { ...payload };
  if (basePath === '/branch/students') {
    delete cleanPayload.primary_branch_id;
  }
  const response = await api.put(`${basePath}/${id}`, cleanPayload);
  return response.data;
};

export const patchStudent = async (id: number, partialPayload: Record<string, any>) => {
  const basePath = getStudentBasePath();
  const cleanPayload = { ...partialPayload };
  if (basePath === '/branch/students') {
    delete cleanPayload.primary_branch_id;
  }
  const response = await api.patch(`${basePath}/${id}`, cleanPayload);
  return response.data;
};

export const deleteStudent = async (id: number) => {
  const basePath = getStudentBasePath();
  const response = await api.delete(`${basePath}/${id}`);
  return response.data;
};

export interface StudentDocument {
  id: number;
  tenant_id: number;
  student_id: number;
  document_type_id: number;
  document_type_name: string;
  document_type_code: string;
  is_required: number | boolean;
  storage_key: string;
  file_name: string;
  mime_type?: string;
  status: 0 | 1 | 2; // 0=Pending, 1=Verified, 2=Rejected
  statusLabel: 'Verification Pending' | 'Verified' | 'Rejected';
  verified_by?: number;
  verified_by_name?: string;
  verified_at?: string;
  rejection_reason?: string;
  created_at: string;
}

export const getAcademicOptions = async () => {
  const basePath = getStudentBasePath();
  const response = await api.get(`${basePath}/options/academic`);
  return response.data;
};

export const uploadStudentDocumentFile = async (file: File): Promise<{
  fileName: string;
  storageKey: string;
  url: string;
  mimeType: string;
  fileSize: string;
}> => {
  const basePath = getStudentBasePath();
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post(`${basePath}/upload-document`, formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
  return response.data.data;
};

export const getStudentDocuments = async (studentId: number | string): Promise<StudentDocument[]> => {
  const basePath = getStudentBasePath();
  const response = await api.get(`${basePath}/${studentId}/documents`);
  return response.data.data || [];
};

export const updateStudentDocumentStatus = async (
  studentId: number | string,
  docId: number | string,
  status: 0 | 1 | 2,
  rejectionReason?: string
): Promise<StudentDocument[]> => {
  const basePath = getStudentBasePath();
  const response = await api.patch(`${basePath}/${studentId}/documents/${docId}/status`, {
    status,
    rejectionReason
  });
  return response.data.data || [];
};

