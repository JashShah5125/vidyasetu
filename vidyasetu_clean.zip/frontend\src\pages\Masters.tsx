import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, CardHeader, CardTitle } from '../components/ui/Card';
import { Table } from '../components/ui/Table';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Pagination } from '../components/ui/Pagination';
import { Plus, Edit3, Trash2, ArrowLeft, Upload, RotateCcw } from 'lucide-react';
import { BulkImportModal } from '../components/ui/BulkImportModal';
import { Modal } from '../components/ui/Modal';
import { ConfirmDeleteModal } from '../components/ui/ConfirmDeleteModal';

interface MastersProps {
  initialSubTab?: 'courses' | 'batches' | 'subjects' | 'branches';
}

export const Masters: React.FC<MastersProps> = ({ initialSubTab = 'courses' }) => {
  const {
    courses, 
    batches, 
    branches,
    addCourse, 
    addBatch, 
    setCourses,
    setBatches,
    setBranches,
    addToast
  } = useApp();
  const [subTab, setSubTab] = useState<'courses' | 'batches' | 'subjects' | 'branches'>(initialSubTab);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingName, setEditingName] = useState<string | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  const [coursesPage, setCoursesPage] = useState(1);
  const [batchesPage, setBatchesPage] = useState(1);
  const [subjectsPage, setSubjectsPage] = useState(1);
  const itemsPerPage = 3;

  const [searchTerm, setSearchTerm] = useState('');

  const [subjects] = useState([
    { name: 'Organic Chemistry', department: 'Chemistry Department', batches: 'JEE-Morning-A, NEET-Regular-B' },
    { name: 'Electromagnetism', department: 'Physics Department', batches: 'JEE-Evening-B' }
  ]);

  // Form states - Course
  const [courseName, setCourseName] = useState('');
  const [courseCode, setCourseCode] = useState('');
  const [courseFees, setCourseFees] = useState(120000);
  const [courseDuration, setCourseDuration] = useState('2 Years');

  // Form states - Batch
  const [batchName, setBatchName] = useState('');
  const [batchCourse, setBatchCourse] = useState('');
  const [batchTiming, setBatchTiming] = useState('09:00 AM - 10:30 AM');
  const [batchRoom, setBatchRoom] = useState('Room 101');
  const [batchTeacher, setBatchTeacher] = useState('Prof. Arvind Kelkar');

  React.useEffect(() => {
    setSubTab(initialSubTab);
  }, [initialSubTab]);

  const handleOpenAddModal = () => {
    if (subTab === 'subjects') {
      addToast('Adding new Subject Masters is disabled in Demo Mode.', 'info');
      return;
    }
    setEditingName(null);

    setCourseName('');
    setCourseCode('');
    setCourseFees(120000);
    setCourseDuration('2 Years');

    setBatchName('');
    setBatchCourse(courses[0]?.name || 'JEE Prep');
    setBatchTiming('09:00 AM - 10:30 AM');
    setBatchRoom('Room 101');
    setBatchTeacher('Prof. Arvind Kelkar');

    setShowAddModal(true);
  };

  const [editingItemOriginal, setEditingItemOriginal] = useState<any | null>(null);
  const [showConfirmUpdateModal, setShowConfirmUpdateModal] = useState(false);
  const [courseFilterDuration, setCourseFilterDuration] = useState('all');
  const [deleteTarget, setDeleteTarget] = useState<{ name: string; type: string } | null>(null);

  const handleEdit = (item: any) => {
    setEditingItemOriginal(item);
    setEditingName(item.name);
    if (subTab === 'courses') {
      setCourseName(item.name);
      setCourseCode(item.code);
      setCourseFees(item.fees);
      setCourseDuration(item.duration);
    } else if (subTab === 'batches') {
      setBatchName(item.name);
      setBatchCourse(item.course);
      setBatchTiming(item.timing);
      setBatchRoom(item.room);
      setBatchTeacher(item.teacher);
    }
    setShowAddModal(true);
  };

  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    const { name, type } = deleteTarget;
    if (type === 'branch') {
      setBranches(prev => prev.filter(b => b.name !== name));
      addToast(`Branch "${name}" deleted.`, 'success');
    } else if (type === 'course') {
      setCourses(prev => prev.filter(c => c.name !== name));
      addToast(`Course "${name}" deleted.`, 'success');
    } else if (type === 'batch') {
      setBatches(prev => prev.filter(b => b.name !== name));
      addToast(`Batch "${name}" deleted.`, 'success');
    }
    setDeleteTarget(null);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (subTab === 'courses') {
      if (!courseName.trim() || !courseCode.trim()) {
        addToast('Course Name and Course Code are required.', 'error');
        return;
      }
      // Duplicate check
      if (!editingItemOriginal) {
        const isDup = courses.some(c => c.name.toLowerCase() === courseName.trim().toLowerCase() || c.code.toLowerCase() === courseCode.trim().toLowerCase());
        if (isDup) {
          addToast(`Course with name "${courseName}" or code "${courseCode}" already exists.`, 'error');
          return;
        }
      } else {
        const isDup = courses.some(c => c !== editingItemOriginal && (c.name.toLowerCase() === courseName.trim().toLowerCase() || c.code.toLowerCase() === courseCode.trim().toLowerCase()));
        if (isDup) {
          addToast(`Another course with name "${courseName}" or code "${courseCode}" already exists.`, 'error');
          return;
        }
      }
    }

    if (editingItemOriginal) {
      setShowConfirmUpdateModal(true);
      return;
    }

    executeSubmit();
  };

  const executeSubmit = () => {
    if (subTab === 'courses') {
      if (editingItemOriginal) {
        setCourses(prev => prev.map(c => c === editingItemOriginal || c.code === editingItemOriginal.code
          ? { ...c, name: courseName.trim(), code: courseCode.trim(), fees: courseFees, duration: courseDuration } 
          : c
        ));
        addToast(`Course "${courseName}" updated successfully.`, 'success');
      } else {
        addCourse({
          name: courseName.trim(),
          code: courseCode.trim(),
          fees: Number(courseFees),
          duration: courseDuration,
          batches: '0 Batches',
          programs: []
        });
        addToast(`Course "${courseName}" added successfully.`, 'success');
      }
    } else if (subTab === 'batches') {
      if (!batchName.trim()) return;
      if (editingItemOriginal) {
        setBatches(prev => prev.map(b => b === editingItemOriginal || b.name === editingItemOriginal.name
          ? { ...b, name: batchName.trim(), course: batchCourse, timing: batchTiming, room: batchRoom, teacher: batchTeacher } 
          : b
        ));
        addToast(`Batch "${batchName}" updated successfully.`, 'success');
      } else {
        addBatch({
          name: batchName.trim(),
          course: batchCourse || courses[0]?.name || 'JEE Prep',
          timing: batchTiming,
          room: batchRoom,
          teacher: batchTeacher
        });
        addToast(`Batch "${batchName}" added successfully.`, 'success');
      }
    }
    setShowConfirmUpdateModal(false);
    setShowAddModal(false);
    setEditingName(null);
    setEditingItemOriginal(null);
  };

  const filteredAndSortedBranches = branches
    .filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase()) || b.code.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name));

  const filteredAndSortedCourses = courses
    .filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.code.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDuration = courseFilterDuration === 'all' || c.duration === courseFilterDuration;
      return matchesSearch && matchesDuration;
    })
    .sort((a, b) => a.name.localeCompare(b.name));

  const filteredAndSortedBatches = batches
    .filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase()) || b.course.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name));

  const filteredAndSortedSubjects = subjects
    .filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.department.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name));

  const handleExportCSV = () => {
    let dataToExport: any[] = [];
    let filename = '';
    
    if (subTab === 'branches') {
      dataToExport = filteredAndSortedBranches.map(b => ({ 'Branch Name': b.name, 'Branch Code': b.code, 'Admin Owner': b.admin, 'Capacity': b.capacity }));
      filename = 'branches.csv';
    } else if (subTab === 'courses') {
      dataToExport = filteredAndSortedCourses.map(c => ({ 'Course Name': c.name, 'Course Code': c.code, 'Fees (Rs.)': c.fees, 'Duration': c.duration }));
      filename = 'courses.csv';
    } else if (subTab === 'batches') {
      dataToExport = filteredAndSortedBatches.map(b => ({ 'Batch Name': b.name, 'Course': b.course, 'Room': b.room, 'Teacher': b.teacher, 'Timings': b.timing }));
      filename = 'batches.csv';
    } else if (subTab === 'subjects') {
      dataToExport = filteredAndSortedSubjects.map(s => ({ 'Subject Name': s.name, 'Department': s.department, 'Batches': s.batches }));
      filename = 'subjects.csv';
    }
    
    if (dataToExport.length === 0) return;
    const csvRows = [];
    const headers = Object.keys(dataToExport[0]);
    csvRows.push(headers.join(','));
    
    for (const row of dataToExport) {
      const values = headers.map(header => {
        const val = row[header as keyof typeof row] || '';
        const escaped = ('' + val).replace(/"/g, '\\"');
        return `"${escaped}"`;
      });
      csvRows.push(values.join(','));
    }
    
    const csvContent = "data:text/csv;charset=utf-8," + csvRows.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (showAddModal) {
    return (
      <div className="space-y-6 w-full animate-fade-in">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddModal(false)}
            className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer"
          >
            <ArrowLeft size={26} />
          </button>
          <div>
            <h2 className="text-2xl font-display font-bold text-slate-900">
              {editingName ? `Edit Record: ${editingName}` : `Create Master Record: ${subTab.toUpperCase()}`}
            </h2>
            <p className="text-sm text-slate-500">Configure core attributes for course templates, branch locations, batches, or subject structures.</p>
          </div>
        </div>

        <div className="w-full">
          <form onSubmit={handleFormSubmit} className="space-y-4">
            {subTab === 'courses' && (
              <>
                <Input label="Course Title Name" required placeholder="e.g. NEET Batch Premium" value={courseName} onChange={(e) => setCourseName(e.target.value)} />
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Course Unique Code" required placeholder="e.g. NEET-PREM" value={courseCode} onChange={(e) => setCourseCode(e.target.value)} />
                  <Input label="Target Duration" placeholder="e.g. 1 Year" value={courseDuration} onChange={(e) => setCourseDuration(e.target.value)} />
                </div>
                <Input label="Course Fee Amount (Rs.)" type="number" value={courseFees} onChange={(e) => setCourseFees(Number(e.target.value))} />
              </>
            )}

            {subTab === 'batches' && (
              <>
                <Input label="Batch Name Label" required placeholder="e.g. NEET-Regular-B" value={batchName} onChange={(e) => setBatchName(e.target.value)} />
                <Select 
                  label="Target Course Mapping" 
                  value={batchCourse} 
                  onChange={(e) => setBatchCourse(e.target.value)} 
                  options={courses.map(c => ({ value: c.name, label: c.name }))}
                />
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Daily Lecture Timings" placeholder="e.g. 09:00 AM - 10:30 AM" value={batchTiming} onChange={(e) => setBatchTiming(e.target.value)} />
                  <Input label="Allotted Classroom" placeholder="e.g. Room 102" value={batchRoom} onChange={(e) => setBatchRoom(e.target.value)} />
                </div>
                <Input label="Primary Lecturer / Teacher" placeholder="Prof. Arvind Kelkar" value={batchTeacher} onChange={(e) => setBatchTeacher(e.target.value)} />
              </>
            )}

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setShowAddModal(false)}>Cancel</Button>
              <Button type="submit" variant="primary">
                {editingName ? 'Update Record' : 'Save Master Record'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900">Masters Configuration</h2>
          <p className="text-sm text-slate-500 mt-1">Configure active branches, course details, timetable sessions, and subjects master.</p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="secondary" onClick={() => setIsImportModalOpen(true)} className="flex items-center gap-1.5 font-bold">
            <Upload size={14} /> Bulk Import
          </Button>
          <Button variant="secondary" onClick={handleExportCSV}>Export CSV</Button>
          <Button variant="primary" style={{ gap: '6px' }} onClick={handleOpenAddModal}>
            <Plus size={16} /> Add Master Record
          </Button>
        </div>
      </div>

      {/* Search, Filter, Sort Controls */}
      <div className="flex flex-col sm:flex-row gap-4 bg-white border border-slate-200/80 p-4 rounded-xl shadow-sm items-center">
        <Input 
          placeholder={`Search ${subTab}...`} 
          value={searchTerm} 
          onChange={(e) => setSearchTerm(e.target.value)} 
          wrapperClassName="flex-1 w-full"
        />

        {subTab === 'courses' && (
          <div className="w-full sm:w-48">
            <Select
              label=""
              value={courseFilterDuration}
              onChange={(e) => setCourseFilterDuration(e.target.value)}
              options={[
                { value: 'all', label: 'All Durations' },
                { value: '1 Year', label: '1 Year' },
                { value: '2 Years', label: '2 Years' },
                { value: '3 Months', label: '3 Months' },
                { value: '6 Months', label: '6 Months' }
              ]}
            />
          </div>
        )}

        {(searchTerm || (subTab === 'courses' && courseFilterDuration !== 'all')) && (
          <Button
            variant="secondary"
            onClick={() => {
              setSearchTerm('');
              setCourseFilterDuration('all');
            }}
            className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 shrink-0"
          >
            <RotateCcw size={13} /> Reset
          </Button>
        )}
      </div>

      {/* Tab Selectors */}
      <div className="flex border-b border-slate-200 overflow-x-auto whitespace-nowrap scrollbar-none">
        <button
          onClick={() => setSubTab('courses')}
          className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors cursor-pointer select-none ${
            subTab === 'courses' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Courses
        </button>
        <button
          onClick={() => setSubTab('batches')}
          className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors cursor-pointer select-none ${
            subTab === 'batches' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Batches
        </button>
        <button
          onClick={() => setSubTab('subjects')}
          className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors cursor-pointer select-none ${
            subTab === 'subjects' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Subjects Master
        </button>
      </div>

      {/* Render sub-tabs */}

      {subTab === 'courses' && (
        (() => {
          const paginatedCourses = filteredAndSortedCourses.slice((coursesPage - 1) * itemsPerPage, coursesPage * itemsPerPage);
          const totalPages = Math.ceil(filteredAndSortedCourses.length / itemsPerPage);
          return (
            <Card>
              <CardHeader>
                <CardTitle>Offered Courses &amp; Curriculums</CardTitle>
              </CardHeader>
              <Table headers={['Course Title', 'Code', 'Course Fees', 'Duration', 'Actions']}>
                {paginatedCourses.map((c, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="px-6 py-4 font-semibold text-slate-800">{c.name}</td>
                    <td className="px-6 py-4 font-mono font-bold text-xs">{c.code}</td>
                    <td className="px-6 py-4 font-semibold text-slate-700">Rs. {c.fees}</td>
                    <td className="px-6 py-4">{c.duration}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <button 
                          type="button"
                          onClick={() => handleEdit(c)}
                          title="Edit Course"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button 
                          type="button"
                          onClick={() => setDeleteTarget({ name: c.name, type: 'course' })}
                          title="Delete Course"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </Table>
              <Pagination
                currentPage={coursesPage}
                totalPages={totalPages}
                totalItems={filteredAndSortedCourses.length}
                pageSize={itemsPerPage}
                onPageChange={setCoursesPage}
              />
            </Card>
          );
        })()
      )}

      {subTab === 'batches' && (
        (() => {
          const paginatedBatches = filteredAndSortedBatches.slice((batchesPage - 1) * itemsPerPage, batchesPage * itemsPerPage);
          const totalPages = Math.ceil(filteredAndSortedBatches.length / itemsPerPage);
          return (
            <Card>
              <CardHeader>
                <CardTitle>Academic Batches Allocation</CardTitle>
              </CardHeader>
              <Table headers={['Batch Name', 'Mapped Course', 'Lecture Timings', 'Allotted Classroom', 'Primary Teacher', 'Actions']}>
                {paginatedBatches.map((b, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="px-6 py-4 font-semibold text-slate-800">{b.name}</td>
                    <td className="px-6 py-4 text-xs text-slate-500">{b.course}</td>
                    <td className="px-6 py-4 font-mono text-xs">{b.timing}</td>
                    <td className="px-6 py-4">{b.room}</td>
                    <td className="px-6 py-4">{b.teacher}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <button 
                          type="button"
                          onClick={() => handleEdit(b)}
                          title="Edit Batch"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button 
                          type="button"
                          onClick={() => setDeleteTarget({ name: b.name, type: 'batch' })}
                          title="Delete Batch"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </Table>
              <Pagination
                currentPage={batchesPage}
                totalPages={totalPages}
                totalItems={filteredAndSortedBatches.length}
                pageSize={itemsPerPage}
                onPageChange={setBatchesPage}
              />
            </Card>
          );
        })()
      )}

      {subTab === 'subjects' && (
        (() => {
          const paginatedSubjects = filteredAndSortedSubjects.slice((subjectsPage - 1) * itemsPerPage, subjectsPage * itemsPerPage);
          const totalPages = Math.ceil(filteredAndSortedSubjects.length / itemsPerPage);
          return (
            <Card>
              <CardHeader>
                <CardTitle>Subjects Syllabus Config</CardTitle>
              </CardHeader>
              <Table headers={['Subject Name', 'Primary Department', 'Assigned Batches', 'Actions']}>
                {paginatedSubjects.map((s, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="px-6 py-4 font-semibold text-slate-800">{s.name}</td>
                    <td className="px-6 py-4">{s.department}</td>
                    <td className="px-6 py-4 text-xs">{s.batches}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <button 
                          type="button"
                          onClick={() => handleEdit(s)}
                          title="Edit Subject"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button 
                          type="button"
                          onClick={() => setDeleteTarget({ name: s.name, type: 'subject' })}
                          title="Delete Subject"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </Table>
              <Pagination
                currentPage={subjectsPage}
                totalPages={totalPages}
                totalItems={filteredAndSortedSubjects.length}
                pageSize={itemsPerPage}
                onPageChange={setSubjectsPage}
              />
            </Card>
          );
        })()
      )}

      <BulkImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        title={`Bulk Import Master: ${subTab}`}
        description={`Select a CSV spreadsheet to import multiple master records for ${subTab} at once. Columns must match the template below exactly.`}
        sampleHeaders={
          subTab === 'branches' ? ['Name', 'Code', 'Admin', 'Capacity', 'Status'] :
          subTab === 'courses' ? ['Name', 'Code', 'Description'] :
          subTab === 'batches' ? ['Name', 'Branch', 'Course', 'Program', 'Level', 'AcademicYear', 'Timing', 'Room'] :
          ['Name', 'Code', 'Type']
        }
        sampleRows={
          subTab === 'branches' ? [['Mumbai South', 'MUM-SOUTH', 'Alok Mehta', '150', 'Active']] :
          subTab === 'courses' ? [['NEET Foundation', 'NEET-FOUND', 'NEET Pre-foundation for class X']] :
          subTab === 'batches' ? [['JEE-Morning-B', 'Mumbai West', 'JEE Prep Course', '2 Year', 'Class XI', '2026-2027', '08:00 AM - 11:00 AM', 'Room 102']] :
          [['Electromagnetic Induction', 'PHY-104', 'Core']]
        }
        onImport={(importedRows) => {
          if (subTab === 'branches') {
            const mapped = importedRows.map((row, rIdx) => ({
              id: `BRN-${Math.floor(10000 + Math.random() * 90000)}-${rIdx}`,
              name: row['Name'] || 'Imported Branch',
              code: row['Code'] || `B-${Math.floor(100 + Math.random() * 900)}`,
              admin: row['Admin'] || 'Admin',
              capacity: parseInt(row['Capacity'], 10) || 100,
              status: (row['Status'] || 'Active') as any
            }));
            setBranches(prev => [...mapped, ...prev]);
            addToast('Branches master list updated.', 'success');
          } else if (subTab === 'courses') {
            const mapped = importedRows.map((row, rIdx) => ({
              id: `CRS-${Math.floor(10000 + Math.random() * 90000)}-${rIdx}`,
              name: row['Name'] || 'Imported Course',
              code: row['Code'] || `C-${Math.floor(100 + Math.random() * 900)}`,
              description: row['Description'] || '',
              branches: ['Mumbai West'],
              programs: []
            }));
            setCourses(prev => [...mapped, ...prev]);
            addToast('Courses master list updated.', 'success');
          } else if (subTab === 'batches') {
            const mapped = importedRows.map((row, rIdx) => ({
              id: `BAT-${Math.floor(10000 + Math.random() * 90000)}-${rIdx}`,
              name: row['Name'] || 'Imported Batch',
              branch: row['Branch'] || 'Mumbai West',
              course: row['Course'] || 'JEE Prep Course',
              program: row['Program'] || '2 Year',
              level: row['Level'] || 'Class XI',
              academicYear: row['AcademicYear'] || '2026-2027',
              timing: row['Timing'] || '08:00 AM - 11:00 AM',
              room: row['Room'] || 'Room 101'
            }));
            setBatches(prev => [...mapped, ...prev]);
            addToast('Batches master list updated.', 'success');
          } else {
            addToast('Bulk import for this sub-tab is managed under Subject Setup.', 'info');
          }
        }}
      />

      <Modal
        isOpen={showConfirmUpdateModal}
        onClose={() => setShowConfirmUpdateModal(false)}
        title={`Confirm ${subTab === 'courses' ? 'Course' : subTab === 'batches' ? 'Batch' : 'Record'} Update`}
        size="md"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Are you sure you want to apply and save changes to this {subTab === 'courses' ? 'course' : subTab === 'batches' ? 'batch' : 'record'}?
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setShowConfirmUpdateModal(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={executeSubmit}>
              Confirm & Update
            </Button>
          </div>
        </div>
      </Modal>

      <ConfirmDeleteModal
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleConfirmDelete}
        itemType={deleteTarget?.type || 'record'}
        itemName={deleteTarget?.name}
        description={`Deleting this ${deleteTarget?.type || 'record'} will remove it from the active master catalog.`}
      />
    </div>
  );
};
