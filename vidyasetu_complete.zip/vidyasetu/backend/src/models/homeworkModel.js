const pool = require('../config/db');

const STATUS_ALLOWED = ['draft', 'published', 'closed'];

const titleize = (token) =>
    String(token || '')
        .split('_')
        .map(w => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ');

const normalizeStatus = (status) => {
    if (!status) return 'draft';
    const token = String(status).toLowerCase().trim().replace(/\s+/g, '_');
    return STATUS_ALLOWED.includes(token) ? token : 'draft';
};

const parseJsonArray = (value) => {
    if (Array.isArray(value)) return value;
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            return [];
        }
    }
    return [];
};

const safeNumber = (value) =>
    (value === undefined || value === null || value === '') ? null : Number(value);

const toDbDateTime = (value) => {
    if (!value) return null;
    if (value instanceof Date) {
        const pad = (n) => String(n).padStart(2, '0');
        return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())} ` +
            `${pad(value.getHours())}:${pad(value.getMinutes())}:${pad(value.getSeconds())}`;
    }
    const str = String(value);
    const dateOnly = str.match(/^(\d{4}-\d{2}-\d{2})$/);
    if (dateOnly) return `${dateOnly[1]} 23:59:59`;
    return str.replace('T', ' ').substring(0, 19);
};

const normalizeCreatePayload = (data) => {
    const batchIds = parseJsonArray(data.batch_ids ?? data.batchIds).map(Number).filter(Boolean);
    const files = parseJsonArray(data.files).map(f => String(f));
    return {
        branchId: Number(data.branch_id ?? data.branchId),
        academicYearId: Number(data.academic_year_id ?? data.academicYearId),
        subjectId: Number(data.subject_id ?? data.subjectId),
        title: String(data.title || '').trim(),
        description: data.description ? String(data.description).trim() : '',
        assignmentType: data.assignment_type ?? data.assignmentType ?? 'homework',
        batchIds,
        files,
        dueDate: toDbDateTime(data.due_date ?? data.dueDate),
        maxMarks: safeNumber(data.max_marks ?? data.maxMarks)
    };
};

const rowToHomework = (row) => {
    const batchIds = parseJsonArray(row.batch_ids);
    const files = parseJsonArray(row.files);
    return {
        id: String(row.id),
        branchId: String(row.branch_id),
        branchName: row.branch_name || '',
        academicYearId: String(row.academic_year_id),
        academicYearName: row.academic_year_name || '',
        subjectId: String(row.subject_id),
        subjectName: row.subject_name || '',
        subjectCode: row.subject_code || '',
        title: row.title,
        description: row.description || '',
        assignmentType: row.assignment_type || 'homework',
        batchIds,
        batchNames: Array.isArray(row.batch_names) ? row.batch_names : [],
        files,
        dueDate: row.due_date ? new Date(row.due_date).toISOString().slice(0, 10) : '',
        dueDateTime: row.due_date ? String(row.due_date).replace(' ', 'T') : '',
        maxMarks: row.max_marks === null || row.max_marks === undefined ? null : Number(row.max_marks),
        status: titleize(row.status),
        publishedAt: row.published_at || null,
        closedAt: row.closed_at || null,
        submittedCount: Number(row.submitted_count || 0),
        totalCount: Number(row.total_count || 0),
        createdBy: row.created_by ? String(row.created_by) : '',
        updatedAt: row.updated_at || null
    };
};

const getBranchInTenant = async (conn, tenantId, branchId) => {
    const [rows] = await conn.query(
        `SELECT id FROM branches WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
        [tenantId, Number(branchId)]
    );
    return rows.length ? rows[0].id : null;
};

const getAcademicYearInBranch = async (conn, tenantId, branchId, academicYearId) => {
    const [rows] = await conn.query(
        `SELECT id, name FROM academic_years
         WHERE tenant_id = ? AND deleted_at IS NULL AND branch_id = ? AND id = ?`,
        [tenantId, Number(branchId), Number(academicYearId)]
    );
    return rows.length ? rows[0] : null;
};

const getSubjectInTenant = async (conn, tenantId, subjectId) => {
    const [rows] = await conn.query(
        `SELECT id, name, code FROM subjects
         WHERE tenant_id = ? AND deleted_at IS NULL AND status = 'active' AND id = ?`,
        [tenantId, Number(subjectId)]
    );
    return rows.length ? rows[0] : null;
};

const getBatchesInBranchYear = async (conn, tenantId, branchId, academicYearId, batchIds) => {
    if (!batchIds || !batchIds.length) return [];
    const [rows] = await conn.query(
        `SELECT id, name FROM batches
         WHERE tenant_id = ? AND deleted_at IS NULL AND status = 'active'
           AND branch_id = ? AND academic_year_id = ? AND id IN (?)`,
        [tenantId, Number(branchId), Number(academicYearId), batchIds]
    );
    return rows;
};

const getTeacherAssignedBatchIds = async (tenantId, teacherUserId) => {
    const [rows] = await pool.query(
        `SELECT batch_id FROM teacher_allocations
         WHERE tenant_id = ? AND teacher_user_id = ? AND deleted_at IS NULL`,
        [tenantId, Number(teacherUserId)]
    );
    return rows.map(r => Number(r.batch_id));
};

const enrichCounts = async (tenantId, homeworkRows, batchIdsById) => {
    const homeworkIds = homeworkRows.map(h => Number(h.id));
    if (!homeworkIds.length) return homeworkRows;

    const idList = [...new Set(homeworkIds)];

    // Total enrolled students across each homework's targeted batches
    const pairs = [];
    idList.forEach(id => {
        (batchIdsById.get(id) || []).forEach(b => pairs.push([id, b]));
    });
    if (pairs.length) {
        const derived = pairs.map(() => 'SELECT ? AS homework_id, ? AS batch_id').join(' UNION ALL ');
        const [totalRows] = await pool.query(
            `SELECT hb.homework_id, COUNT(DISTINCT se.student_id) AS total
               FROM (${derived}) hb
               JOIN student_enrollments se
                 ON se.tenant_id = ? AND se.status = 'active' AND se.deleted_at IS NULL
                AND se.batch_id = hb.batch_id
              GROUP BY hb.homework_id`,
            [...pairs.flat(), tenantId]
        );
        totalRows.forEach(r => {
            const hw = homeworkRows.find(h => Number(h.id) === Number(r.homework_id));
            if (hw) hw.total_count = Number(r.total);
        });
    }

    const [submittedRows] = await pool.query(
        `SELECT homework_id, COUNT(*) AS cnt
           FROM homework_submissions
          WHERE tenant_id = ? AND deleted_at IS NULL AND homework_id IN (?)
          GROUP BY homework_id`,
        [tenantId, idList]
    );
    submittedRows.forEach(r => {
        const hw = homeworkRows.find(h => Number(h.id) === Number(r.homework_id));
        if (hw) hw.submitted_count = Number(r.cnt);
    });

    return homeworkRows;
};

const HOMEWORK_SELECT = `
    SELECT hw.*,
           s.name AS subject_name, s.code AS subject_code,
           b.name AS branch_name,
           ay.name AS academic_year_name
    FROM homeworks hw
    LEFT JOIN subjects s ON s.id = hw.subject_id
    LEFT JOIN branches b ON b.id = hw.branch_id
    LEFT JOIN academic_years ay ON ay.id = hw.academic_year_id
`;

const fetchHomeworkRows = async (tenantId, teacherUserId) => {
    const [rows] = await pool.query(
        `${HOMEWORK_SELECT}
         WHERE hw.tenant_id = ? AND hw.deleted_at IS NULL
         ORDER BY hw.updated_at DESC`,
        [tenantId]
    );

    const assignedBatchIds = await getTeacherAssignedBatchIds(tenantId, teacherUserId);

    // Batch id -> names lookup for output
    const allBatchIds = [...new Set(rows.flatMap(r => parseJsonArray(r.batch_ids).map(Number)))];
    const batchNamesById = new Map();
    if (allBatchIds.length) {
        const [batchRows] = await pool.query(
            `SELECT id, name FROM batches WHERE tenant_id = ? AND deleted_at IS NULL AND id IN (?)`,
            [tenantId, allBatchIds]
        );
        batchRows.forEach(br => batchNamesById.set(Number(br.id), br.name));
    }

    const batchIdsById = new Map();
    const filtered = rows.filter(r => {
        const batchIds = parseJsonArray(r.batch_ids).map(Number);
        batchIdsById.set(Number(r.id), batchIds);
        if (assignedBatchIds.length && !batchIds.some(id => assignedBatchIds.includes(id))) return false;
        return true;
    });

    const enriched = await enrichCounts(tenantId, filtered, batchIdsById);
    return enriched
        .map(r => rowToHomework({
            ...r,
            batch_names: parseJsonArray(r.batch_ids).map(id => batchNamesById.get(Number(id)) || '')
        }));
};

// Teacher: fetch homeworks scoped to the teacher's allocated batches.
const getHomeworks = async (tenantId, teacherUserId, filters = {}) => {
    const { status = 'all', subject = 'all', batch = 'all', branch = 'all', search = '' } = filters;
    const rows = await fetchHomeworkRows(tenantId, teacherUserId);

    return rows.filter(hw => {
        if (status && String(status).toLowerCase() !== 'all' && hw.status.toLowerCase() !== String(status).toLowerCase()) return false;
        if (subject && String(subject).toLowerCase() !== 'all' && Number(hw.subjectId) !== Number(subject)) return false;
        if (batch && String(batch).toLowerCase() !== 'all' && !hw.batchIds.includes(Number(batch))) return false;
        if (branch && String(branch).toLowerCase() !== 'all' && Number(hw.branchId) !== Number(branch)) return false;
        if (search.trim()) {
            const q = search.toLowerCase();
            if (!hw.title.toLowerCase().includes(q) && !hw.subjectName.toLowerCase().includes(q) && !hw.batchNames.some(n => n.toLowerCase().includes(q))) return false;
        }
        return true;
    });
};

const getHomework = async (tenantId, id, teacherUserId) => {
    const rows = await fetchHomeworkRows(tenantId, teacherUserId);
    return rows.find(h => h.id === String(id)) || null;
};

const getTeacherScoping = async (tenantId, teacherUserId) => {
    const params = [tenantId, Number(teacherUserId)];

    const [branches] = await pool.query(
        `SELECT DISTINCT b.id, b.name
           FROM teacher_allocations ta
           JOIN branches b ON b.id = ta.branch_id
          WHERE ta.tenant_id = ? AND ta.teacher_user_id = ? AND ta.deleted_at IS NULL
            AND b.deleted_at IS NULL
          ORDER BY b.name ASC`,
        params
    );

    const [batches] = await pool.query(
        `SELECT DISTINCT ta.batch_id AS id, bt.name
           FROM teacher_allocations ta
           JOIN batches bt ON bt.id = ta.batch_id
          WHERE ta.tenant_id = ? AND ta.teacher_user_id = ? AND ta.deleted_at IS NULL
            AND bt.deleted_at IS NULL AND bt.status = 'active'
          ORDER BY bt.name ASC`,
        params
    );

    const [subjects] = await pool.query(
        `SELECT DISTINCT ts.subject_id AS id, s.name, s.code
           FROM teacher_subjects ts
           JOIN subjects s ON s.id = ts.subject_id
          WHERE ts.tenant_id = ? AND ts.teacher_user_id = ?
            AND s.deleted_at IS NULL AND s.status = 'active'
          ORDER BY s.name ASC`,
        params
    );

    const [academicYears] = await pool.query(
        `SELECT DISTINCT ay.id, ay.name, ay.start_date
           FROM teacher_allocations ta
           JOIN academic_years ay ON ay.id = ta.academic_year_id
          WHERE ta.tenant_id = ? AND ta.teacher_user_id = ? AND ta.deleted_at IS NULL
            AND ay.deleted_at IS NULL
          ORDER BY ay.start_date DESC`,
        params
    );

    // Fallback: if the teacher has no allocations, expose the tenant's full scope
    // so the page stays usable even before allocations are configured.
    if (!branches.length && !batches.length && !subjects.length) {
        const [allBranches] = await pool.query(
            `SELECT id, name FROM branches WHERE tenant_id = ? AND deleted_at IS NULL ORDER BY name ASC`, [tenantId]);
        const [allBatches] = await pool.query(
            `SELECT bt.id, bt.name FROM batches bt
              JOIN academic_years ay ON ay.id = bt.academic_year_id
             WHERE bt.tenant_id = ? AND bt.deleted_at IS NULL AND bt.status = 'active'
             ORDER BY bt.name ASC`, [tenantId]);
        const [allSubjects] = await pool.query(
            `SELECT id, name, code FROM subjects WHERE tenant_id = ? AND deleted_at IS NULL AND status = 'active' ORDER BY name ASC`, [tenantId]);
        const [allYears] = await pool.query(
            `SELECT id, name FROM academic_years WHERE tenant_id = ? AND deleted_at IS NULL ORDER BY start_date DESC`, [tenantId]);

        return {
            scoped: false,
            branches: allBranches.map(b => ({ id: String(b.id), name: b.name })),
            batches: allBatches.map(b => ({ id: String(b.id), name: b.name })),
            subjects: allSubjects.map(s => ({ id: String(s.id), name: s.name, code: s.code || '' })),
            academicYears: allYears.map(ay => ({ id: String(ay.id), name: ay.name }))
        };
    }

    return {
        scoped: true,
        branches: branches.map(b => ({ id: String(b.id), name: b.name })),
        batches: batches.map(b => ({ id: String(b.id), name: b.name })),
        subjects: subjects.map(s => ({ id: String(s.id), name: s.name, code: s.code || '' })),
        academicYears: academicYears.map(ay => ({ id: String(ay.id), name: ay.name }))
    };
};

const createHomework = async (tenantId, data, userId) => {
    const payload = normalizeCreatePayload(data);

    if (!payload.title || !payload.subjectId || !payload.branchId || !payload.academicYearId || !payload.dueDate) {
        const error = new Error('Missing required fields (title, subjectId, branchId, academicYearId, dueDate)');
        error.code = 'ER_HW_REQUIRED';
        throw error;
    }
    if (!payload.batchIds || !payload.batchIds.length) {
        const error = new Error('At least one target batch is required');
        error.code = 'ER_HW_BATCH_REQUIRED';
        throw error;
    }

    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const branchId = await getBranchInTenant(conn, tenantId, payload.branchId);
        if (!branchId) {
            await conn.rollback();
            const error = new Error('Branch not found for this institute');
            error.code = 'ER_BRANCH_NOT_FOUND';
            throw error;
        }

        const academicYear = await getAcademicYearInBranch(conn, tenantId, branchId, payload.academicYearId);
        if (!academicYear) {
            await conn.rollback();
            const error = new Error('Academic year not found for this branch');
            error.code = 'ER_AY_NOT_FOUND';
            throw error;
        }

        const subject = await getSubjectInTenant(conn, tenantId, payload.subjectId);
        if (!subject) {
            await conn.rollback();
            const error = new Error('Subject not found for this institute');
            error.code = 'ER_SUBJECT_NOT_FOUND';
            throw error;
        }

        const batches = await getBatchesInBranchYear(conn, tenantId, branchId, academicYear.id, payload.batchIds);
        if (batches.length !== payload.batchIds.length) {
            await conn.rollback();
            const error = new Error('One or more target batches are invalid for this branch/academic year');
            error.code = 'ER_HW_BATCH_INVALID';
            throw error;
        }

        const [insert] = await conn.query(
            `INSERT INTO homeworks
                (tenant_id, branch_id, academic_year_id, subject_id, title, description,
                 assignment_type, batch_ids, files, due_date, max_marks, status, created_by, updated_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?)`,
            [tenantId, branchId, academicYear.id, subject.id, payload.title, payload.description,
             payload.assignmentType, JSON.stringify(payload.batchIds), JSON.stringify(payload.files),
             payload.dueDate, payload.maxMarks, userId, userId]
        );

        await conn.commit();
        return { id: String(insert.insertId) };
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

const updateHomework = async (tenantId, id, data, userId) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [existingRows] = await conn.query(
            `SELECT * FROM homeworks WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
            [tenantId, Number(id)]
        );
        if (!existingRows.length) {
            await conn.rollback();
            return null;
        }
        const current = existingRows[0];

        const payload = normalizeCreatePayload({
            branchId: current.branch_id,
            academicYearId: current.academic_year_id,
            subjectId: current.subject_id,
            title: current.title,
            description: current.description,
            assignmentType: current.assignment_type,
            batchIds: parseJsonArray(current.batch_ids),
            files: parseJsonArray(current.files),
            dueDate: current.due_date ? toDbDateTime(current.due_date) : current.due_date,
            maxMarks: current.max_marks,
            ...data
        });

        if (!payload.title || !payload.dueDate) {
            await conn.rollback();
            const error = new Error('Missing required fields (title, dueDate)');
            error.code = 'ER_HW_REQUIRED';
            throw error;
        }
        if (!payload.batchIds.length) {
            await conn.rollback();
            const error = new Error('At least one target batch is required');
            error.code = 'ER_HW_BATCH_REQUIRED';
            throw error;
        }

        // Batches cannot be changed once the homework is published.
        if (current.status === 'published' && JSON.stringify(payload.batchIds) !== JSON.stringify(parseJsonArray(current.batch_ids))) {
            await conn.rollback();
            const error = new Error('Target batches cannot be changed once the homework is published');
            error.code = 'ER_HW_LOCKED';
            throw error;
        }

        const branchId = await getBranchInTenant(conn, tenantId, payload.branchId);
        if (!branchId) {
            await conn.rollback();
            const error = new Error('Branch not found for this institute');
            error.code = 'ER_BRANCH_NOT_FOUND';
            throw error;
        }

        const academicYear = await getAcademicYearInBranch(conn, tenantId, branchId, payload.academicYearId);
        if (!academicYear) {
            await conn.rollback();
            const error = new Error('Academic year not found for this branch');
            error.code = 'ER_AY_NOT_FOUND';
            throw error;
        }

        const subject = await getSubjectInTenant(conn, tenantId, payload.subjectId);
        if (!subject) {
            await conn.rollback();
            const error = new Error('Subject not found for this institute');
            error.code = 'ER_SUBJECT_NOT_FOUND';
            throw error;
        }

        const batches = await getBatchesInBranchYear(conn, tenantId, branchId, academicYear.id, payload.batchIds);
        if (batches.length !== payload.batchIds.length) {
            await conn.rollback();
            const error = new Error('One or more target batches are invalid for this branch/academic year');
            error.code = 'ER_HW_BATCH_INVALID';
            throw error;
        }

        await conn.query(
            `UPDATE homeworks
                SET branch_id = ?, academic_year_id = ?, subject_id = ?, title = ?, description = ?,
                    assignment_type = ?, batch_ids = ?, files = ?, due_date = ?, max_marks = ?,
                    updated_by = ?, updated_at = CURRENT_TIMESTAMP
              WHERE id = ? AND deleted_at IS NULL`,
            [branchId, academicYear.id, subject.id, payload.title, payload.description,
             payload.assignmentType, JSON.stringify(payload.batchIds), JSON.stringify(payload.files),
             payload.dueDate, payload.maxMarks, userId, current.id]
        );

        await conn.commit();
        return { id: String(current.id) };
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

const deleteHomework = async (tenantId, id) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [rows] = await conn.query(
            `SELECT status FROM homeworks WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
            [tenantId, Number(id)]
        );
        if (!rows.length) {
            await conn.rollback();
            return 'not_found';
        }
        if (rows[0].status === 'published') {
            await conn.rollback();
            return 'active';
        }

        await conn.query(
            `UPDATE homeworks SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
              WHERE id = ? AND deleted_at IS NULL`,
            [Number(id)]
        );

        await conn.commit();
        return 'deleted';
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

const publishHomework = async (tenantId, id, userId) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [rows] = await conn.query(
            `SELECT status FROM homeworks WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
            [tenantId, Number(id)]
        );
        if (!rows.length) {
            await conn.rollback();
            return 'not_found';
        }
        if (rows[0].status === 'closed') {
            await conn.rollback();
            return 'closed';
        }
        if (rows[0].status === 'published') {
            await conn.commit();
            return 'published';
        }

        await conn.query(
            `UPDATE homeworks
                SET status = 'published', published_at = CURRENT_TIMESTAMP,
                    updated_by = ?, updated_at = CURRENT_TIMESTAMP
              WHERE id = ? AND deleted_at IS NULL`,
            [userId, Number(id)]
        );

        await conn.commit();
        return 'published';
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

const closeHomework = async (tenantId, id, userId) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [rows] = await conn.query(
            `SELECT status FROM homeworks WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
            [tenantId, Number(id)]
        );
        if (!rows.length) {
            await conn.rollback();
            return 'not_found';
        }
        if (rows[0].status !== 'published') {
            await conn.rollback();
            return 'not_published';
        }

        await conn.query(
            `UPDATE homeworks
                SET status = 'closed', closed_at = CURRENT_TIMESTAMP,
                    updated_by = ?, updated_at = CURRENT_TIMESTAMP
              WHERE id = ? AND deleted_at IS NULL`,
            [userId, Number(id)]
        );

        await conn.commit();
        return 'closed';
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

const getSubmissions = async (tenantId, homeworkId) => {
    const [hwRows] = await pool.query(
        `SELECT id, status FROM homeworks WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
        [tenantId, Number(homeworkId)]
    );
    if (!hwRows.length) return null;

    const [rows] = await pool.query(
        `SELECT hs.id, hs.homework_id, hs.student_id, hs.response_text, hs.files, hs.status,
                hs.marks_obtained, hs.teacher_feedback, hs.submitted_at, hs.graded_at,
                st.full_name AS student_name, st.student_code
           FROM homework_submissions hs
           JOIN students st ON st.id = hs.student_id
          WHERE hs.tenant_id = ? AND hs.homework_id = ? AND hs.deleted_at IS NULL
          ORDER BY hs.submitted_at ASC`,
        [tenantId, Number(homeworkId)]
    );

    return {
        homework: { id: String(hwRows[0].id), status: hwRows[0].status },
        submissions: rows.map(r => ({
            id: String(r.id),
            homeworkId: String(r.homework_id),
            studentId: String(r.student_id),
            studentName: r.student_name,
            studentCode: r.student_code || '',
            responseText: r.response_text || '',
            files: parseJsonArray(r.files),
            status: titleize(r.status),
            marksObtained: r.marks_obtained === null || r.marks_obtained === undefined ? null : Number(r.marks_obtained),
            feedback: r.teacher_feedback || '',
            submittedAt: r.submitted_at || null,
            gradedAt: r.graded_at || null
        }))
    };
};

const gradeSubmission = async (tenantId, homeworkId, submissionId, data, userId) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [rows] = await conn.query(
            `SELECT id FROM homework_submissions
              WHERE tenant_id = ? AND homework_id = ? AND id = ? AND deleted_at IS NULL`,
            [tenantId, Number(homeworkId), Number(submissionId)]
        );
        if (!rows.length) {
            await conn.rollback();
            return null;
        }

        const marks = safeNumber(data.marks_obtained ?? data.marksObtained);
        const feedback = data.teacher_feedback ?? data.feedback ?? '';
        if (marks === null) {
            await conn.rollback();
            const error = new Error('Marks are required for grading');
            error.code = 'ER_HW_MARKS_REQUIRED';
            throw error;
        }

        await conn.query(
            `UPDATE homework_submissions
                SET marks_obtained = ?, teacher_feedback = ?, status = 'graded',
                    graded_by = ?, graded_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
              WHERE id = ?`,
            [marks, String(feedback), userId, Number(submissionId)]
        );

        await conn.commit();
        return { id: String(submissionId) };
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

// ─── Student-facing ─────────────────────────────────────────────────────────

const resolveStudentByUserId = async (tenantId, userId) => {
    const [rows] = await pool.query(
        `SELECT id FROM students WHERE tenant_id = ? AND user_id = ? AND deleted_at IS NULL`,
        [tenantId, Number(userId)]
    );
    return rows.length ? rows[0].id : null;
};

const getStudentEnrolledBatchIds = async (tenantId, studentId) => {
    const [rows] = await pool.query(
        `SELECT batch_id FROM student_enrollments
          WHERE tenant_id = ? AND student_id = ? AND status = 'active' AND deleted_at IS NULL`,
        [tenantId, Number(studentId)]
    );
    return rows.map(r => Number(r.batch_id));
};

const getStudentHomeworks = async (tenantId, studentId) => {
    const enrolledBatchIds = await getStudentEnrolledBatchIds(tenantId, studentId);

    const [rows] = await pool.query(
        `${HOMEWORK_SELECT}
         WHERE hw.tenant_id = ? AND hw.deleted_at IS NULL AND hw.status IN ('published', 'closed')
         ORDER BY hw.due_date ASC`,
        [tenantId]
    );

    const [submissionRows] = await pool.query(
        `SELECT homework_id, status, marks_obtained, teacher_feedback, submitted_at
           FROM homework_submissions
          WHERE tenant_id = ? AND student_id = ? AND deleted_at IS NULL`,
        [tenantId, Number(studentId)]
    );
    const submissionByHomework = new Map(submissionRows.map(s => [Number(s.homework_id), s]));

    const batchNamesById = new Map();
    const allBatchIds = [...new Set(rows.flatMap(r => parseJsonArray(r.batch_ids).map(Number)))];
    if (allBatchIds.length) {
        const [batchRows] = await pool.query(
            `SELECT id, name FROM batches WHERE tenant_id = ? AND deleted_at IS NULL AND id IN (?)`,
            [tenantId, allBatchIds]
        );
        batchRows.forEach(br => batchNamesById.set(Number(br.id), br.name));
    }

    return rows
        .filter(r => {
            const batchIds = parseJsonArray(r.batch_ids).map(Number);
            return enrolledBatchIds.length && batchIds.some(id => enrolledBatchIds.includes(id));
        })
        .map(r => {
            const sub = submissionByHomework.get(Number(r.id));
            return {
                ...rowToHomework({
                    ...r,
                    batch_names: parseJsonArray(r.batch_ids).map(id => batchNamesById.get(Number(id)) || ''),
                    submitted_count: sub ? 1 : 0,
                    total_count: 0
                }),
                mySubmission: sub ? {
                    status: titleize(sub.status),
                    marksObtained: sub.marks_obtained === null || sub.marks_obtained === undefined ? null : Number(sub.marks_obtained),
                    feedback: sub.teacher_feedback || '',
                    submittedAt: sub.submitted_at || null,
                    isLate: Boolean(r.due_date && sub.submitted_at && new Date(sub.submitted_at) > new Date(r.due_date))
                } : null
            };
        });
};

const getStudentHomework = async (tenantId, studentId, id) => {
    const list = await getStudentHomeworks(tenantId, studentId);
    return list.find(h => h.id === String(id)) || null;
};

const submitHomework = async (tenantId, studentId, homeworkId, data) => {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const enrolledBatchIds = await getStudentEnrolledBatchIds(tenantId, studentId);

        const [hwRows] = await conn.query(
            `SELECT batch_ids, status, due_date FROM homeworks
              WHERE tenant_id = ? AND deleted_at IS NULL AND id = ?`,
            [tenantId, Number(homeworkId)]
        );
        if (!hwRows.length) {
            await conn.rollback();
            return 'not_found';
        }
        const hw = hwRows[0];
        if (hw.status !== 'published') {
            await conn.rollback();
            return 'not_open';
        }
        const batchIds = parseJsonArray(hw.batch_ids).map(Number);
        if (!enrolledBatchIds.some(id => batchIds.includes(id))) {
            await conn.rollback();
            return 'not_assigned';
        }

        const responseText = String(data.response_text ?? data.responseText ?? '').trim();
        const fileUrls = parseJsonArray(data.files);

        await conn.query(
            `INSERT INTO homework_submissions
                (tenant_id, homework_id, student_id, response_text, files, status, submitted_at)
             VALUES (?, ?, ?, ?, ?, 'submitted', CURRENT_TIMESTAMP)
             ON DUPLICATE KEY UPDATE
                response_text = VALUES(response_text),
                files = VALUES(files),
                status = 'submitted',
                submitted_at = CURRENT_TIMESTAMP,
                marks_obtained = NULL,
                teacher_feedback = NULL,
                graded_by = NULL,
                graded_at = NULL,
                updated_at = CURRENT_TIMESTAMP`,
            [tenantId, Number(homeworkId), Number(studentId), responseText, JSON.stringify(fileUrls)]
        );

        await conn.commit();
        return 'submitted';
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
};

module.exports = {
    getHomeworks,
    getHomework,
    getTeacherScoping,
    createHomework,
    updateHomework,
    deleteHomework,
    publishHomework,
    closeHomework,
    getSubmissions,
    gradeSubmission,
    getStudentHomeworks,
    getStudentHomework,
    submitHomework,
    resolveStudentByUserId
};