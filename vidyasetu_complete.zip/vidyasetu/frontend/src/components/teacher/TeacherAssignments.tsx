import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Table } from '../ui/Table';
import { Pagination } from '../ui/Pagination';
import {
  Plus,
  ArrowLeft,
  BookOpen,
  ClipboardList,
  CheckCircle2,
  Edit3,
  Eye,
  FileText,
  Trash2,
  XCircle,
  Loader2,
  Upload,
  Paperclip,
  Send,
  Check,
  X
} from 'lucide-react';
import type { ExamItem } from '../../data/mockData';
import { assignmentApi } from '../../services/assignmentApi';
import type { HomeworkItem, HomeworkScoping, HomeworkSubmission, ScopingOption } from '../../services/assignmentApi';
import { subjectApi } from '../../services/subjectApi';

interface HomeworkFormState {
  id?: string;
  title: string;
  description: string;
  assignmentType: string;
  branchId: number;
  academicYearId: number;
  subjectId: number;
  batchIds: number[];
  dueDate: string;
  maxMarks: string;
  existingFiles: string[];
}

const EMPTY_HW_FORM: HomeworkFormState = {
  title: '',
  description: '',
  assignmentType: 'homework',
  branchId: 0,
  academicYearId: 0,
  subjectId: 0,
  batchIds: [],
  dueDate: '',
  maxMarks: '',
  existingFiles: []
};

const TYPE_OPTIONS = [
  { value: 'homework', label: 'Homework' },
  { value: 'worksheet', label: 'Worksheet' },
  { value: 'practice_set', label: 'Practice set' },
  { value: 'reading_task', label: 'Reading task' },
  { value: 'revision_work', label: 'Revision work' }
];

const getStatusBadgeColor = (status: string) => {
  switch (status) {
    case 'Draft': return 'bg-gray-100 text-gray-800';
    case 'Published':
    case 'Scheduled': return 'bg-blue-100 text-blue-800';
    case 'Closed':
    case 'Completed': return 'bg-green-100 text-green-800';
    case 'Cancelled': return 'bg-red-100 text-red-800';
    case 'Marks Published': return 'bg-purple-100 text-purple-800';
    case 'Marks Pending': return 'bg-orange-100 text-orange-800';
    case 'In Progress': return 'bg-teal-100 text-teal-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

const typeLabel = (value: string) => {
  const found = TYPE_OPTIONS.find(t => t.value === value);
  return found ? found.label : value;
};

export const TeacherAssignments: React.FC = () => {
  const {
    exams,
    setExams,
    currentUser,
    sendNotification,
    addToast,
    batches
  } = useApp();

  const [activePrimaryTab, setActivePrimaryTab] = useState<'homework' | 'exams'>('homework');
  const [activeSubTab, setActiveSubTab] = useState<'active' | 'drafts'>('active');

  const [scoping, setScoping] = useState<HomeworkScoping | null>(null);
  const [homeworks, setHomeworks] = useState<HomeworkItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionBusy, setActionBusy] = useState<boolean>(false);

  const [filterBranch, setFilterBranch] = useState<string>('All');
  const [filterBatch, setFilterBatch] = useState<string>('All');
  const [filterSubject, setFilterSubject] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 8;

  const [showHwForm, setShowHwForm] = useState<boolean>(false);
  const [hwForm, setHwForm] = useState<HomeworkFormState>(EMPTY_HW_FORM);
  const [cascade, setCascade] = useState<{ course: number; program: number; level: number }>({ course: 0, program: 0, level: 0 });
  const [batchPick, setBatchPick] = useState<number>(0);
  const [levelSubjectOptions, setLevelSubjectOptions] = useState<ScopingOption[]>([]);
  const [subjectsLoadedForLevel, setSubjectsLoadedForLevel] = useState(false);
  const [newFiles, setNewFiles] = useState<File[]>([]);
  const [showHwDetail, setShowHwDetail] = useState<HomeworkItem | null>(null);
  const [detailLoading, setDetailLoading] = useState<boolean>(false);
  const [submissions, setSubmissions] = useState<HomeworkSubmission[]>([]);
  const [gradeInputs, setGradeInputs] = useState<Record<string, { marks: string; feedback: string }>>({});
  const [gradingId, setGradingId] = useState<string | null>(null);

  const [showExamForm, setShowExamForm] = useState<boolean>(false);
  const [examForm, setExamForm] = useState<Partial<ExamItem>>({});
  const [showExamDetails, setShowExamDetails] = useState<ExamItem | null>(null);

  const loadScoping = useCallback(async () => {
    try {
      const data = await assignmentApi.getScoping();
      setScoping(data);
    } catch (err: any) {
      addToast(err.message || 'Failed to load your scope', 'error');
    }
  }, [addToast]);

  const loadHomeworks = useCallback(async () => {
    setLoading(true);
    try {
      const data = await assignmentApi.getHomeworks();
      setHomeworks(data);
    } catch (err: any) {
      addToast(err.message || 'Failed to load homework', 'error');
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    loadScoping();
    loadHomeworks();
  }, [loadScoping, loadHomeworks]);

  useEffect(() => {
    if (showHwForm || showExamForm) {
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
  }, [showHwForm, showExamForm]);

  useEffect(() => {
    setCurrentPage(1);
  }, [activePrimaryTab, activeSubTab, filterBranch, filterBatch, filterSubject, filterStatus, searchQuery]);

  useEffect(() => {
    if (!cascade.level) {
      setLevelSubjectOptions([]);
      setSubjectsLoadedForLevel(false);
      return;
    }
    let alive = true;
    setSubjectsLoadedForLevel(false);
    subjectApi.list({ levelId: String(cascade.level), limit: 500, status: 'active' })
      .then((res: any) => {
        if (!alive) return;
        const list: any[] = (res && Array.isArray(res.data)) ? res.data : (Array.isArray(res) ? res : []);
        const teacherIds = new Set((scoping?.subjects || []).map(s => Number(s.id)));
        const filtered = list
          .filter(s => teacherIds.has(Number(s.id)))
          .map(s => ({ id: String(s.id), name: s.name, code: s.code || '' }));
        setLevelSubjectOptions(filtered);
        setSubjectsLoadedForLevel(true);
        setHwForm(prev => {
          if (prev.subjectId && !filtered.some(s => Number(s.id) === prev.subjectId)) {
            return { ...prev, subjectId: 0 };
          }
          return prev;
        });
      })
      .catch(() => {
        if (alive) {
          setLevelSubjectOptions([]);
          setSubjectsLoadedForLevel(true);
        }
      });
    return () => { alive = false; };
  }, [cascade.level, scoping]);

  const filteredHomeworks = useMemo(() => {
    return homeworks.filter(item => {
      if (activeSubTab === 'active' && item.status === 'Draft') return false;
      if (activeSubTab === 'drafts' && item.status !== 'Draft') return false;

      if (filterBranch !== 'All' && item.branchName !== filterBranch) return false;
      if (filterBatch !== 'All' && !item.batchNames.includes(filterBatch)) return false;
      if (filterSubject !== 'All' && item.subjectName !== filterSubject) return false;
      if (filterStatus !== 'All' && item.status !== filterStatus) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchSubj = item.subjectName.toLowerCase().includes(q);
        const matchBatch = item.batchNames.some(n => n.toLowerCase().includes(q));
        if (!matchTitle && !matchSubj && !matchBatch) return false;
      }
      return true;
    });
  }, [homeworks, activeSubTab, filterBranch, filterBatch, filterSubject, filterStatus, searchQuery]);

  const filteredExams = useMemo(() => {
    return exams.filter(item => {
      if (activeSubTab === 'active' && item.status === 'Draft') return false;
      if (activeSubTab === 'drafts' && item.status !== 'Draft') return false;
      if (filterBranch !== 'All') return false;
      if (filterBatch !== 'All' && item.batch !== filterBatch) return false;
      if (filterSubject !== 'All' && item.subject !== filterSubject) return false;
      if (filterStatus !== 'All' && item.status !== filterStatus) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(q);
        const matchSubj = item.subject.toLowerCase().includes(q);
        const matchBatch = item.batch.toLowerCase().includes(q);
        if (!matchName && !matchSubj && !matchBatch) return false;
      }
      return true;
    });
  }, [exams, activeSubTab, filterBranch, filterBatch, filterSubject, filterStatus, searchQuery]);

  const currentData = activePrimaryTab === 'homework' ? filteredHomeworks : filteredExams;
  const totalPages = Math.ceil(currentData.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return currentData.slice(start, start + itemsPerPage);
  }, [currentData, currentPage, itemsPerPage]);

  const openCreateForm = () => {
    setHwForm({
      ...EMPTY_HW_FORM,
      branchId: scoping?.branches?.[0] ? Number(scoping.branches[0].id) : 0,
      academicYearId: scoping?.academicYears?.[0] ? Number(scoping.academicYears[0].id) : 0,
      subjectId: scoping?.subjects?.[0] ? Number(scoping.subjects[0].id) : 0,
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
    });
    setCascade({ course: 0, program: 0, level: 0 });
    setBatchPick(0);
    setNewFiles([]);
    setShowHwForm(true);
  };

  const openEditForm = (item: HomeworkItem | null) => {
    if (!item) return;
    setHwForm({
      id: item.id,
      title: item.title,
      description: item.description,
      assignmentType: item.assignmentType,
      branchId: Number(item.branchId),
      academicYearId: Number(item.academicYearId),
      subjectId: Number(item.subjectId),
      batchIds: item.batchIds,
      dueDate: item.dueDate || new Date().toISOString().split('T')[0],
      maxMarks: item.maxMarks !== null && item.maxMarks !== undefined ? String(item.maxMarks) : '',
      existingFiles: item.files || []
    });
    const firstBatch = (batches || []).find(b => item.batchIds.includes(Number(b.id)));
    setCascade({
      course: firstBatch?.courseId ? Number(firstBatch.courseId) : 0,
      program: firstBatch?.programId ? Number(firstBatch.programId) : 0,
      level: firstBatch?.levelId ? Number(firstBatch.levelId) : 0
    });
    setBatchPick(0);
    setNewFiles([]);
    setShowHwForm(true);
  };

  // ─── Course → Program → Level cascade against the teacher's allocated batches ───
  const allocatedBatches = useMemo(() => {
    const scopeIds = new Set((scoping?.batches || []).map(sb => Number(sb.id)));
    return (batches || []).filter(b => scopeIds.has(Number(b.id)));
  }, [batches, scoping]);

  const candidateBatches = useMemo(
    () => allocatedBatches.filter(b =>
      (hwForm.branchId === 0 || Number(b.branchId) === hwForm.branchId) &&
      (hwForm.academicYearId === 0 || Number(b.academicYearId) === hwForm.academicYearId)
    ),
    [allocatedBatches, hwForm.branchId, hwForm.academicYearId]
  );

  const cascadeCourses = useMemo(() => {
    const seen = new Map<number, string>();
    candidateBatches.forEach(b => {
      const id = Number(b.courseId);
      if (id) seen.set(id, b.courseName || `Course ${id}`);
    });
    return Array.from(seen.entries()).map(([id, name]) => ({ id, name }));
  }, [candidateBatches]);

  const cascadePrograms = useMemo(() => {
    const seen = new Map<number, string>();
    candidateBatches.forEach(b => {
      if (cascade.course && Number(b.courseId) === cascade.course) {
        const id = Number(b.programId);
        if (id) seen.set(id, b.programName || `Program ${id}`);
      }
    });
    return Array.from(seen.entries()).map(([id, name]) => ({ id, name }));
  }, [candidateBatches, cascade.course]);

  const cascadeLevels = useMemo(() => {
    const seen = new Map<number, string>();
    candidateBatches.forEach(b => {
      if (cascade.course && Number(b.courseId) === cascade.course && cascade.program && Number(b.programId) === cascade.program) {
        const id = Number(b.levelId);
        if (id) seen.set(id, b.levelName || `Level ${id}`);
      }
    });
    return Array.from(seen.entries()).map(([id, name]) => ({ id, name }));
  }, [candidateBatches, cascade.course, cascade.program]);

  const hasCascadeMeta = cascadeCourses.length > 0;

  const levelBatches = useMemo(
    () => candidateBatches.filter(b =>
      cascade.course && Number(b.courseId) === cascade.course &&
      cascade.program && Number(b.programId) === cascade.program &&
      cascade.level && Number(b.levelId) === cascade.level
    ),
    [candidateBatches, cascade.course, cascade.program, cascade.level]
  );

  const batchNameById = useMemo(() => {
    const m = new Map<number, string>();
    allocatedBatches.forEach(b => m.set(Number(b.id), b.name));
    return m;
  }, [allocatedBatches]);

  const subjectOptions = useMemo(() => {
    if (cascade.level && subjectsLoadedForLevel) return levelSubjectOptions;
    return scoping?.subjects || [];
  }, [cascade.level, subjectsLoadedForLevel, levelSubjectOptions, scoping]);

  const addTargetBatch = (batchId: number) => {
    if (!batchId) return;
    setHwForm(prev => prev.batchIds.includes(batchId) ? prev : { ...prev, batchIds: [...prev.batchIds, batchId] });
  };

  const removeTargetBatch = (batchId: number) => {
    setHwForm(prev => ({ ...prev, batchIds: prev.batchIds.filter(x => x !== batchId) }));
  };

  const changeBranch = (branchId: number) => {
    setHwForm(prev => ({ ...prev, branchId, batchIds: [] }));
    setCascade({ course: 0, program: 0, level: 0 });
    setBatchPick(0);
  };

  const changeAcademicYear = (academicYearId: number) => {
    setHwForm(prev => ({ ...prev, academicYearId, batchIds: [] }));
    setCascade({ course: 0, program: 0, level: 0 });
    setBatchPick(0);
  };

  const changeCourse = (course: number) => {
    setCascade(prev => ({ ...prev, course, program: 0, level: 0 }));
    setHwForm(prev => ({ ...prev, batchIds: [] }));
    setBatchPick(0);
  };

  const changeProgram = (program: number) => {
    setCascade(prev => ({ ...prev, program, level: 0 }));
    setHwForm(prev => ({ ...prev, batchIds: [] }));
    setBatchPick(0);
  };

  const changeLevel = (level: number) => {
    setCascade(prev => ({ ...prev, level }));
    if (!level) setHwForm(prev => ({ ...prev, batchIds: [], subjectId: 0 }));
    setBatchPick(0);
  };

  const submitHomeworkForm = async (mode: 'draft' | 'publish') => {
    if (!hwForm.title.trim() || hwForm.batchIds.length === 0 || !hwForm.dueDate) {
      addToast('Title, at least one target batch, and due date are required.', 'error');
      return;
    }
    if (!hwForm.subjectId || !hwForm.branchId || !hwForm.academicYearId) {
      addToast('Please choose a subject, branch, and academic year.', 'error');
      return;
    }

    setActionBusy(true);
    try {
      const payload = {
        title: hwForm.title.trim(),
        description: hwForm.description,
        branchId: hwForm.branchId,
        academicYearId: hwForm.academicYearId,
        subjectId: hwForm.subjectId,
        assignmentType: hwForm.assignmentType,
        batchIds: hwForm.batchIds,
        dueDate: hwForm.dueDate,
        maxMarks: hwForm.maxMarks ? Number(hwForm.maxMarks) : null,
        existingFiles: hwForm.existingFiles
      };

      let id = hwForm.id;
      if (id) {
        await assignmentApi.updateHomework(id, payload, newFiles);
        addToast(`Homework "${payload.title}" updated.`, 'success');
      } else {
        const res = await assignmentApi.createHomework(payload, newFiles);
        id = res.id;
        addToast(`Homework "${payload.title}" saved as draft.`, 'success');
      }

      if (mode === 'publish' && id) {
        await assignmentApi.publishHomework(id);
        addToast(`Homework "${payload.title}" published!`, 'success');
        sendNotification({
          id: `N-${Date.now()}`,
          title: `Assignment: ${payload.title}`,
          message: `An assignment has been published. Due Date: ${hwForm.dueDate}`,
          category: 'Academic',
          sender: currentUser?.name || 'Teacher',
          senderRole: 'Teacher',
          createdAt: new Date().toISOString(),
          direction: 'Outgoing',
          status: 'Unread',
          recipients: [{ type: 'Batch', id: id, name: 'Assigned batches' }]
        });
        setActiveSubTab('active');
      }

      setShowHwForm(false);
      await loadHomeworks();
    } catch (err: any) {
      addToast(err.message || 'Failed to save homework.', 'error');
    } finally {
      setActionBusy(false);
    }
  };

  const handleCloseAssign = async (item: HomeworkItem) => {
    setActionBusy(true);
    try {
      await assignmentApi.closeHomework(item.id);
      addToast(`Assignment "${item.title}" closed successfully.`, 'info');
      setShowHwDetail(null);
      await loadHomeworks();
    } catch (err: any) {
      addToast(err.message || 'Failed to close assignment.', 'error');
    } finally {
      setActionBusy(false);
    }
  };

  const handleDeleteAssign = async (item: HomeworkItem) => {
    if (!window.confirm(`Delete assignment "${item.title}"? ${item.status === 'Published' ? 'Published assignments must be closed first.' : ''}`)) return;
    setActionBusy(true);
    try {
      await assignmentApi.deleteHomework(item.id);
      addToast(`Assignment "${item.title}" deleted successfully.`, 'success');
      setShowHwDetail(null);
      await loadHomeworks();
    } catch (err: any) {
      addToast(err.message || 'Failed to delete assignment.', 'error');
    } finally {
      setActionBusy(false);
    }
  };

  const openDetail = async (item: HomeworkItem) => {
    setShowHwDetail(item);
    if (item.status !== 'Published' && item.status !== 'Closed') {
      setSubmissions([]);
      return;
    }
    setDetailLoading(true);
    setSubmissions([]);
    setGradeInputs({});
    try {
      const res = await assignmentApi.getSubmissions(item.id);
      setSubmissions(res.submissions);
      const initial: Record<string, { marks: string; feedback: string }> = {};
      res.submissions.forEach(s => {
        initial[s.id] = { marks: s.marksObtained !== null && s.marksObtained !== undefined ? String(s.marksObtained) : '', feedback: s.feedback || '' };
      });
      setGradeInputs(initial);
    } catch (err: any) {
      addToast(err.message || 'Failed to load submissions.', 'error');
    } finally {
      setDetailLoading(false);
    }
  };

  const handleGrade = async (submission: HomeworkSubmission) => {
    const input = gradeInputs[submission.id];
    const marks = input ? Number(input.marks) : NaN;
    if (isNaN(marks) || !input || input.marks.trim() === '') {
      addToast('Enter marks before grading.', 'error');
      return;
    }
    setGradingId(submission.id);
    try {
      await assignmentApi.gradeSubmission(submission.homeworkId, submission.id, marks, input.feedback || '');
      addToast(`Graded ${submission.studentName}.`, 'success');
      if (showHwDetail) await openDetail(showHwDetail);
    } catch (err: any) {
      addToast(err.message || 'Failed to grade submission.', 'error');
    } finally {
      setGradingId(null);
    }
  };

  // ─── Exam (mock) actions ──────────────────────────────────────────────────
  const handleSaveExamDraft = () => {
    if (!examForm.name || !examForm.batch) {
      addToast('Test title and Target Batch are required.', 'error');
      return;
    }
    const newId = examForm.id || `EX-${Date.now()}`;
    const newExam: ExamItem = {
      ...(examForm as ExamItem),
      type: examForm.type || 'Unit Test',
      id: newId,
      status: 'Draft',
      examDate: examForm.examDate || 'Not Set',
      totalMarks: examForm.totalMarks || 100,
      passingMarks: examForm.passingMarks || 40,
      average: ''
    };
    if (examForm.id) {
      setExams(prev => prev.map(e => e.id === newId ? newExam : e));
      addToast(`Exam "${newExam.name}" updated in drafts.`, 'success');
    } else {
      setExams(prev => [newExam, ...prev]);
      addToast(`Exam "${newExam.name}" saved as draft.`, 'success');
    }
    setShowExamForm(false);
  };

  const handleScheduleExam = () => {
    if (!examForm.name || !examForm.batch || !examForm.examDate) {
      addToast('Please fill in Test Name, Target Batch, and Exam Date.', 'error');
      return;
    }
    const isEditing = Boolean(examForm.id);
    const newId = examForm.id || `EX-${Date.now()}`;
    const newExam: ExamItem = {
      ...(examForm as ExamItem),
      type: examForm.type || 'Unit Test',
      id: newId,
      status: 'Scheduled',
      totalMarks: examForm.totalMarks || 100,
      passingMarks: examForm.passingMarks || 40,
      average: ''
    };
    if (isEditing) {
      setExams(prev => prev.map(e => e.id === newId ? newExam : e));
      addToast(`Exam "${newExam.name}" updated successfully!`, 'success');
    } else {
      setExams(prev => [newExam, ...prev]);
      addToast(`Exam "${newExam.name}" scheduled for ${newExam.batch}!`, 'success');
    }
    sendNotification({
      id: `N-${Date.now()}`,
      title: `Upcoming Exam: ${newExam.name}`,
      message: `An exam has been scheduled on ${newExam.examDate} for ${newExam.batch}.`,
      category: 'Examination',
      sender: currentUser?.name || 'Teacher',
      senderRole: 'Teacher',
      createdAt: new Date().toISOString(),
      direction: 'Outgoing',
      status: 'Unread',
      recipients: [{ type: 'Batch', id: newExam.batch, name: newExam.batch }]
    });
    setShowExamForm(false);
    setActiveSubTab('active');
  };

  const handleCancelExam = (id: string) => {
    const item = exams.find(e => e.id === id);
    setExams(prev => prev.map(e => e.id === id ? { ...e, status: 'Cancelled' } : e));
    setShowExamDetails(null);
    addToast(`Exam "${item?.name || ''}" cancelled.`, 'info');
  };

  const handleDeleteExam = (id: string) => {
    const item = exams.find(e => e.id === id);
    setExams(prev => prev.filter(e => e.id !== id));
    setShowExamDetails(null);
    addToast(`Exam draft "${item?.name || ''}" deleted.`, 'success');
  };

  // ─── Full page: Homework detail with submissions ─────────────────────────
  if (showHwDetail) {
    const item = showHwDetail;
    return (
      <div className="p-6 max-w-6xl mx-auto space-y-6 animate-fade-in pb-12">
        <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-5">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowHwDetail(null)}
              className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer"
            >
              <ArrowLeft size={24} />
            </button>
            <div>
              <h2 className="text-2xl font-display font-bold text-slate-900">{item.title}</h2>
              <p className="text-sm text-slate-500 mt-0.5">
                {item.subjectName} · {item.batchNames.join(', ') || 'No batches'}
                <span className={`ml-3 px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(item.status)}`}>
                  {item.status}
                </span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {item.status === 'Published' && (
              <Button variant="secondary" className="cursor-pointer" onClick={() => handleCloseAssign(item)} disabled={actionBusy}>
                <XCircle className="w-4 h-4 mr-2" /> Close Assignment
              </Button>
            )}
            {item.status !== 'Published' && (
              <Button variant="ghost" className="cursor-pointer" onClick={() => handleDeleteAssign(item)} disabled={actionBusy}>
                <Trash2 className="w-4 h-4 mr-2 text-red-500" /> Delete
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <Card className="p-5">
              <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide mb-3">Details</h3>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between"><dt className="text-slate-500">Type</dt><dd className="font-medium">{typeLabel(item.assignmentType)}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Branch</dt><dd className="font-medium text-right">{item.branchName}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Academic Year</dt><dd className="font-medium">{item.academicYearName}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Due Date</dt><dd className="font-medium">{item.dueDate}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Max Marks</dt><dd className="font-medium">{item.maxMarks ?? '—'}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Submissions</dt><dd className="font-medium">{item.submittedCount} / {item.totalCount}</dd></div>
              </dl>
              {item.description && (
                <p className="mt-4 text-sm text-slate-600 leading-relaxed whitespace-pre-line">{item.description}</p>
              )}
              {item.files.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-bold text-slate-700 mb-2">Attachments</p>
                  <div className="space-y-2">
                    {item.files.map((f, i) => (
                      <a key={i} href={f} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sm text-blue-600 hover:underline">
                        <Paperclip size={14} /> {f.split('/').pop()}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Submissions</h3>
                {detailLoading && <Loader2 className="w-4 h-4 animate-spin text-blue-600" />}
              </div>
              {item.status === 'Draft' ? (
                <p className="p-8 text-center text-slate-500 text-sm">Submissions are only visible once the homework is published.</p>
              ) : !detailLoading && submissions.length === 0 ? (
                <div className="py-12 text-center text-slate-500">
                  <FileText className="w-10 h-10 text-slate-300 mb-3 mx-auto" />
                  <p>No submissions yet.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b">
                        <th className="py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wider">Student</th>
                        <th className="py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wider">Submitted</th>
                        <th className="py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wider">Response</th>
                        <th className="py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wider">Marks</th>
                        <th className="py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wider">Feedback</th>
                        <th className="py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {submissions.map(s => {
                        const input = gradeInputs[s.id] || { marks: '', feedback: '' };
                        const grading = gradingId === s.id;
                        return (
                          <tr key={s.id} className="align-top hover:bg-slate-50 transition-colors">
                            <td className="py-3 px-4">
                              <div className="font-medium text-slate-900 text-sm">{s.studentName}</div>
                              <div className="text-xs text-slate-500">{s.studentCode || '—'}</div>
                            </td>
                            <td className="py-3 px-4 text-sm text-slate-600">
                              {s.submittedAt ? new Date(s.submittedAt).toLocaleString() : '—'}
                              <div className="text-xs">
                                <span className={`${s.status === 'Graded' ? 'text-green-600' : 'text-amber-600'} font-semibold`}>
                                  {s.status === 'Graded' ? 'Graded' : 'Pending'}
                                </span>
                              </div>
                            </td>
                            <td className="py-3 px-4 text-sm text-slate-600 max-w-[240px]">
                              <p className="whitespace-pre-line line-clamp-3">{s.responseText || '—'}</p>
                              {s.files.length > 0 && (
                                <div className="mt-1 space-y-1">
                                  {s.files.map((f, i) => (
                                    <a key={i} href={f} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs text-blue-600 hover:underline">
                                      <Paperclip size={12} /> {f.split('/').pop()}
                                    </a>
                                  ))}
                                </div>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-1">
                                <input
                                  type="number"
                                  className="w-20 border border-slate-200 rounded-lg px-2 py-1.5 text-sm outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                                  placeholder="—"
                                  value={input.marks}
                                  onChange={e => setGradeInputs(prev => ({ ...prev, [s.id]: { ...(prev[s.id] || {}), marks: e.target.value } }))}
                                />
                                {item.maxMarks && <span className="text-xs text-slate-400">/ {item.maxMarks}</span>}
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <input
                                className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-sm outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                                placeholder="Feedback…"
                                value={input.feedback}
                                onChange={e => setGradeInputs(prev => ({ ...prev, [s.id]: { ...(prev[s.id] || {}), feedback: e.target.value } }))}
                              />
                            </td>
                            <td className="py-3 px-4">
                              <Button
                                size="sm"
                                variant={s.status === 'Graded' ? 'outline' : 'primary'}
                                className="cursor-pointer"
                                onClick={() => handleGrade(s)}
                                disabled={grading}
                              >
                                {grading ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : s.status === 'Graded' ? <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> : <Send className="w-3.5 h-3.5 mr-1" />}
                                {s.status === 'Graded' ? 'Regrade' : 'Grade'}
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // ─── Full page: Homework create / edit ──────────────────────────────────────
  if (showHwForm) {
    const isEdit = Boolean(hwForm.id);
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-6 animate-fade-in pb-12">
        <div className="flex items-center gap-4 border-b border-slate-200 pb-5">
          <button
            onClick={() => setShowHwForm(false)}
            className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 className="text-2xl font-display font-bold text-slate-900">
              {isEdit ? `Edit Assignment: ${hwForm.title}` : 'Create New Assignment'}
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              {isEdit
                ? 'Update assignment details, target batches, and submission due date.'
                : 'Configure homework, practice worksheets, or revision tasks for your batches.'}
            </p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-8 space-y-6">
          <div>
            <h3 className="font-semibold text-sm text-blue-800 mb-4 uppercase tracking-wider flex items-center gap-2">
              <BookOpen size={16} className="text-blue-600" /> Basic Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Assignment Title <span className="text-red-500">*</span>
                </label>
                <Input
                  value={hwForm.title}
                  onChange={e => setHwForm({ ...hwForm, title: e.target.value })}
                  placeholder="e.g. Kinematics Problem Set #4"
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Assignment Type</label>
                <select
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  value={hwForm.assignmentType}
                  onChange={e => setHwForm({ ...hwForm, assignmentType: e.target.value })}
                >
                  {TYPE_OPTIONS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Branch</label>
                <select
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  value={hwForm.branchId}
                  onChange={e => changeBranch(Number(e.target.value))}
                >
                  <option value={0}>Select a branch...</option>
                  {(scoping?.branches || []).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Academic Year</label>
                <select
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  value={hwForm.academicYearId}
                  onChange={e => changeAcademicYear(Number(e.target.value))}
                >
                  <option value={0}>Select academic year...</option>
                  {(scoping?.academicYears || []).map(ay => <option key={ay.id} value={ay.id}>{ay.name}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <h3 className="font-semibold text-sm text-blue-800 mb-4 uppercase tracking-wider flex items-center gap-2">
              <ClipboardList size={16} className="text-blue-600" /> Target Batch & Schedule
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Course</label>
                    <select
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all disabled:bg-slate-50 disabled:text-slate-400"
                      value={cascade.course}
                      onChange={e => changeCourse(Number(e.target.value))}
                      disabled={!hasCascadeMeta}
                    >
                      <option value={0}>{hasCascadeMeta ? 'Select course...' : 'No batch data'}</option>
                      {cascadeCourses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Program</label>
                    <select
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all disabled:bg-slate-50 disabled:text-slate-400"
                      value={cascade.program}
                      onChange={e => changeProgram(Number(e.target.value))}
                      disabled={!hasCascadeMeta || !cascade.course}
                    >
                      <option value={0}>{!cascade.course ? 'Select course first' : 'Select program...'}</option>
                      {cascadePrograms.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Level</label>
                    <select
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all disabled:bg-slate-50 disabled:text-slate-400"
                      value={cascade.level}
                      onChange={e => changeLevel(Number(e.target.value))}
                      disabled={!hasCascadeMeta || !cascade.program}
                    >
                      <option value={0}>{!cascade.program ? 'Select program first' : 'Select level...'}</option>
                      {cascadeLevels.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                    </select>
                  </div>
                </div>
                <div className="mb-4">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Batch</label>
                  <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-3">
                    <select
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all disabled:bg-slate-50 disabled:text-slate-400"
                      value={batchPick}
                      onChange={e => setBatchPick(Number(e.target.value))}
                      disabled={!hasCascadeMeta || !cascade.level}
                    >
                      <option value={0}>{!cascade.level ? 'Select Course, Program and Level first' : 'Select a batch...'}</option>
                      {levelBatches.map(b => {
                        const added = hwForm.batchIds.includes(Number(b.id));
                        return (
                          <option key={b.id} value={b.id} disabled={added}>
                            {b.name}{added ? ' (added)' : ''}
                          </option>
                        );
                      })}
                    </select>
                    <Button
                      type="button"
                      variant="outline"
                      className="cursor-pointer"
                      onClick={() => { addTargetBatch(batchPick); setBatchPick(0); }}
                      disabled={!batchPick || hwForm.batchIds.includes(batchPick)}
                    >
                      <Plus className="w-4 h-4 mr-1" /> Add
                    </Button>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  {hwForm.batchIds.map(id => (
                    <span key={id} className="inline-flex items-center gap-1.5 bg-blue-50 border border-blue-200 text-blue-800 text-xs font-medium rounded-full px-3 py-1">
                      {batchNameById.get(id) || `Batch #${id}`}
                      <button
                        type="button"
                        className="text-blue-400 hover:text-red-500 cursor-pointer"
                        onClick={() => removeTargetBatch(id)}
                        aria-label={`Remove batch ${id}`}
                      >
                        <X size={14} />
                      </button>
                    </span>
                  ))}
                  {hwForm.batchIds.length === 0 && (
                    <p className="text-xs text-slate-400 px-1 py-0.5">
                      No target batches yet. Pick a Course, Program and Level, then press Add.
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Subject <span className="text-red-500">*</span></label>
                  <select
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all disabled:bg-slate-50 disabled:text-slate-400"
                    value={hwForm.subjectId}
                    onChange={e => setHwForm({ ...hwForm, subjectId: Number(e.target.value) })}
                    disabled={hasCascadeMeta && !cascade.level}
                  >
                    <option value={0}>
                      {hasCascadeMeta && !cascade.level
                        ? 'Choose filters first...'
                        : cascade.level && subjectsLoadedForLevel && levelSubjectOptions.length === 0
                          ? 'No subjects mapped to this level'
                          : 'Select a subject...'}
                    </option>
                    {subjectOptions.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
              </div>
              <div className="space-y-5">
                <div className="max-w-xs">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Due Date <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="date"
                    value={hwForm.dueDate}
                    onChange={e => setHwForm({ ...hwForm, dueDate: e.target.value })}
                  />
                </div>
                <div className="max-w-xs">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Max Marks</label>
                  <Input
                    type="number"
                    value={hwForm.maxMarks}
                    onChange={e => setHwForm({ ...hwForm, maxMarks: e.target.value })}
                    placeholder="e.g. 10"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <h3 className="font-semibold text-sm text-blue-800 mb-4 uppercase tracking-wider flex items-center gap-2">
              <FileText size={16} className="text-blue-600" /> Instructions & Attachments
            </h3>
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Instructions / Description</label>
                <textarea
                  rows={4}
                  className="w-full bg-white border border-slate-200 rounded-lg p-3 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  value={hwForm.description}
                  onChange={e => setHwForm({ ...hwForm, description: e.target.value })}
                  placeholder="Enter detailed instructions, problem numbers, or reference book chapters..."
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Attachment Files</label>
                <label className="flex items-center justify-center gap-2 border-2 border-dashed border-slate-300 rounded-lg py-4 text-sm text-slate-500 hover:border-blue-400 hover:text-blue-600 transition-all cursor-pointer">
                  <Upload size={18} />
                  Click to upload files (PDF, image, doc, xls, zip)
                  <input
                    type="file"
                    multiple
                    className="hidden"
                    onChange={e => setNewFiles(Array.from(e.target.files || []))}
                  />
                </label>
                {(hwForm.existingFiles.length > 0 || newFiles.length > 0) && (
                  <div className="mt-3 space-y-2">
                    {hwForm.existingFiles.map((f, i) => (
                      <div key={`e-${i}`} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm">
                        <span className="flex items-center gap-2 text-slate-700"><Paperclip size={14} /> {f.split('/').pop()}</span>
                        <button
                          type="button"
                          className="text-red-500 hover:text-red-700 cursor-pointer"
                          onClick={() => setHwForm(prev => ({ ...prev, existingFiles: prev.existingFiles.filter((_, idx) => idx !== i) }))}
                          title="Remove"
                        >
                          <XCircle size={16} />
                        </button>
                      </div>
                    ))}
                    {newFiles.map((f, i) => (
                      <div key={`n-${i}`} className="flex items-center justify-between bg-blue-50 border border-blue-100 rounded-lg px-3 py-2 text-sm">
                        <span className="flex items-center gap-2 text-blue-700"><Paperclip size={14} /> {f.name}</span>
                        <button
                          type="button"
                          className="text-red-500 hover:text-red-700 cursor-pointer"
                          onClick={() => setNewFiles(prev => prev.filter((_, idx) => idx !== i))}
                        >
                          <XCircle size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
            <Button type="button" variant="secondary" onClick={() => setShowHwForm(false)} className="cursor-pointer">
              Cancel
            </Button>
            <div className="flex items-center gap-3">
              <Button
                type="button"
                variant="outline"
                className="cursor-pointer"
                onClick={() => submitHomeworkForm('draft')}
                disabled={actionBusy}
              >
                {actionBusy && !isEdit ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Check className="w-4 h-4 mr-2" />}
                Save Draft
              </Button>
              <Button
                type="button"
                variant="primary"
                style={{ backgroundColor: '#2563eb', color: 'white' }}
                className="cursor-pointer font-semibold shadow-sm px-6"
                onClick={() => submitHomeworkForm('publish')}
                disabled={actionBusy}
              >
                {actionBusy && isEdit ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
                {isEdit ? 'Save & Update Assignment' : 'Publish Assignment'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ─── Full page: Exam create / edit (mock) ───────────────────────────────────
  if (showExamForm) {
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-6 animate-fade-in pb-12">
        <div className="flex items-center gap-4 border-b border-slate-200 pb-5">
          <button
            onClick={() => setShowExamForm(false)}
            className="flex items-center justify-center h-12 w-12 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm cursor-pointer"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 className="text-2xl font-display font-bold text-slate-900">
              {examForm.id ? `Edit Test: ${examForm.name}` : 'Schedule Examination / Test'}
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              {examForm.id
                ? 'Update examination schedule, target batch, marks, and evaluation parameters.'
                : 'Configure unit tests, mock exams, or chapter evaluations for your students.'}
            </p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-8 space-y-6">
          <div>
            <h3 className="font-semibold text-sm text-blue-800 mb-4 uppercase tracking-wider flex items-center gap-2">
              <ClipboardList size={16} className="text-blue-600" /> Basic Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div className="sm:col-span-3">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Test Title <span className="text-red-500">*</span>
                </label>
                <Input
                  value={examForm.name || ''}
                  onChange={e => setExamForm({ ...examForm, name: e.target.value })}
                  placeholder="e.g. Periodic Chemistry Evaluation #2"
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Test Type</label>
                <select
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  value={examForm.type || 'Unit Test'}
                  onChange={e => setExamForm({ ...examForm, type: e.target.value })}
                >
                  <option value="Unit Test">Unit Test</option>
                  <option value="Chapter Test">Chapter Test</option>
                  <option value="Weekly Test">Weekly Test</option>
                  <option value="Mock Test">Mock Test</option>
                  <option value="Term Examination">Term Examination</option>
                  <option value="Internal Assessment">Internal Assessment</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Subject</label>
                <Input
                  value={examForm.subject || ''}
                  onChange={e => setExamForm({ ...examForm, subject: e.target.value })}
                  placeholder="e.g. Chemistry"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Target Batch <span className="text-red-500">*</span>
                </label>
                <select
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  value={examForm.batch || ''}
                  onChange={e => setExamForm({ ...examForm, batch: e.target.value })}
                >
                  <option value="">Select a batch...</option>
                  {(scoping?.batches || []).map(b => (
                    <option key={b.id} value={b.name}>{b.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <h3 className="font-semibold text-sm text-blue-800 mb-4 uppercase tracking-wider flex items-center gap-2">
              <BookOpen size={16} className="text-blue-600" /> Exam Schedule & Evaluation
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Exam Date <span className="text-red-500">*</span>
                </label>
                <Input
                  type="date"
                  value={examForm.examDate === 'Not Set' ? '' : (examForm.examDate || '')}
                  onChange={e => setExamForm({ ...examForm, examDate: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Total Marks</label>
                <Input
                  type="number"
                  value={examForm.totalMarks || 100}
                  onChange={e => setExamForm({ ...examForm, totalMarks: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">Passing Threshold</label>
                <Input
                  type="number"
                  value={examForm.passingMarks || 40}
                  onChange={e => setExamForm({ ...examForm, passingMarks: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
            <Button type="button" variant="secondary" onClick={() => setShowExamForm(false)} className="cursor-pointer">
              Cancel
            </Button>
            <div className="flex items-center gap-3">
              <Button type="button" variant="outline" onClick={handleSaveExamDraft} className="cursor-pointer">
                Save Draft
              </Button>
              <Button
                type="button"
                variant="primary"
                style={{ backgroundColor: '#2563eb', color: 'white' }}
                className="cursor-pointer font-semibold shadow-sm px-6"
                onClick={handleScheduleExam}
              >
                {examForm.id ? 'Save & Update Exam' : 'Schedule Exam'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ─── Main list view ──────────────────────────────────────────────────────
  const handleResetFilters = () => {
    setFilterBranch('All');
    setFilterBatch('All');
    setFilterSubject('All');
    setFilterStatus('All');
    setSearchQuery('');
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900">Assignment and Exams</h2>
          <p className="text-sm text-slate-500 mt-1">Manage homework, practice sets, and classroom evaluations</p>
        </div>
        {activePrimaryTab === 'homework' ? (
          <Button className="bg-blue-600 text-white cursor-pointer" onClick={openCreateForm}>
            <Plus className="w-4 h-4 mr-2" /> Create Assignment
          </Button>
        ) : (
          <Button className="bg-blue-600 text-white cursor-pointer" onClick={() => { setExamForm({}); setShowExamForm(true); }}>
            <Plus className="w-4 h-4 mr-2" /> Schedule Test
          </Button>
        )}
      </div>

      {/* Primary Tabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto hide-scrollbar">
        <button
          onClick={() => { setActivePrimaryTab('homework'); setActiveSubTab('active'); }}
          className={`flex-none px-6 py-3 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
            activePrimaryTab === 'homework'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
          }`}
        >
          <BookOpen size={16} />
          Homework & Assignments
        </button>
        <button
          onClick={() => { setActivePrimaryTab('exams'); setActiveSubTab('active'); }}
          className={`flex-none px-6 py-3 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
            activePrimaryTab === 'exams'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
          }`}
        >
          <ClipboardList size={16} />
          Exams & Assessments
        </button>
        <button
          onClick={() => setActiveSubTab('drafts')}
          className={`ml-auto flex-none px-6 py-3 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors cursor-pointer ${
            activeSubTab === 'drafts'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
          }`}
        >
          Drafts ({activePrimaryTab === 'homework' ? homeworks.filter(a => a.status === 'Draft').length : exams.filter(e => e.status === 'Draft').length})
        </button>
      </div>

      {/* Scope & Filters */}
      <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Scope &amp; Filters</div>
          <Button variant="secondary" size="sm" onClick={handleResetFilters}>Reset Filters</Button>
        </div>
        <Input
          label="Search"
          placeholder={activePrimaryTab === 'homework' ? 'Search assignments by title...' : 'Search tests by name...'}
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <Select
            label="Branch"
            value={filterBranch}
            onChange={e => setFilterBranch(e.target.value)}
            options={[{ value: 'All', label: 'All Branches' }, ...(scoping?.branches || []).map(b => ({ value: b.name, label: b.name }))]}
          />
          <Select
            label="Batch"
            value={filterBatch}
            onChange={e => setFilterBatch(e.target.value)}
            options={[{ value: 'All', label: 'All Batches' }, ...(scoping?.batches || []).map(b => ({ value: b.name, label: b.name }))]}
          />
          <Select
            label="Subject"
            value={filterSubject}
            onChange={e => setFilterSubject(e.target.value)}
            options={[{ value: 'All', label: 'All Subjects' }, ...(scoping?.subjects || []).map(s => ({ value: s.name, label: s.name }))]}
          />
          <Select
            label="Status"
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            options={[{ value: 'All', label: 'All Statuses' }, ...(activeSubTab === 'drafts' ? (
              [{ value: 'Draft', label: 'Draft' }]
            ) : activePrimaryTab === 'homework' ? (
              [{ value: 'Published', label: 'Published' }, { value: 'Closed', label: 'Closed' }]
            ) : (
              [
                { value: 'Scheduled', label: 'Scheduled' },
                { value: 'In Progress', label: 'In Progress' },
                { value: 'Completed', label: 'Completed' },
                { value: 'Marks Pending', label: 'Marks Pending' },
                { value: 'Marks Published', label: 'Marks Published' },
                { value: 'Cancelled', label: 'Cancelled' }
              ]
            ))]}
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600 mb-3" />
            <p className="text-sm">Loading homework...</p>
          </div>
        ) : activePrimaryTab === 'homework' ? (
          <Table headers={[
            'Assignment',
            'Subject',
            'Target Batch',
            'Due Date',
            ...(activeSubTab === 'active' ? ['Submissions'] : []),
            'Status',
            'Actions'
          ]}>
            {(paginatedData as HomeworkItem[]).length === 0 ? (
              <tr>
                <td colSpan={activeSubTab === 'active' ? 8 : 7} className="px-6 py-12 text-center text-slate-500">
                  <FileText className="mx-auto text-slate-300 mb-3" size={32} />
                  <div className="font-medium">No {activeSubTab === 'active' ? 'active assignments' : 'assignment drafts'} found.</div>
                </td>
              </tr>
            ) : (
              (paginatedData as HomeworkItem[]).map((assign) => (
                <tr key={assign.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-semibold text-slate-900">{assign.title}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{typeLabel(assign.assignmentType)}</div>
                  </td>
                  <td className="px-6 py-4 text-slate-700">{assign.subjectName}</td>
                  <td className="px-6 py-4 text-slate-600">{assign.batchNames.join(', ')}</td>
                  <td className="px-6 py-4 font-mono text-xs text-slate-600">{assign.dueDate}</td>
                  {activeSubTab === 'active' && (
                    <td className="px-6 py-4 text-slate-600">
                      {assign.status === 'Draft' ? '—' : (
                        <span className={`font-bold ${assign.submittedCount > 0 ? 'text-emerald-600' : 'text-slate-500'}`}>
                          {assign.submittedCount}
                        </span>
                        )} / {assign.totalCount > 0 ? assign.totalCount : '—'}
                    </td>
                  )}
                  <td className="px-6 py-4">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(assign.status)}`}>
                      {assign.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => openDetail(assign)} title="View Details" className="cursor-pointer hover:bg-slate-100">
                        <Eye className="w-4 h-4 text-slate-500" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => openEditForm(assign)} title="Edit Assignment" className="cursor-pointer hover:bg-blue-50">
                        <Edit3 className="w-4 h-4 text-blue-600" />
                      </Button>
                      {assign.status === 'Published' && (
                        <Button variant="ghost" size="sm" onClick={() => handleCloseAssign(assign)} title="Close Assignment" className="cursor-pointer hover:bg-amber-50">
                          <XCircle className="w-4 h-4 text-amber-600" />
                        </Button>
                      )}
                      {assign.status !== 'Published' && (
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteAssign(assign)} title="Delete Assignment" className="cursor-pointer hover:bg-red-50">
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </Table>
        ) : (
          <Table headers={[
            'Test Name',
            'Subject',
            'Target Batch',
            'Exam Date',
            'Marks',
            ...(activeSubTab === 'active' ? ['Average'] : []),
            'Status',
            'Actions'
          ]}>
            {(paginatedData as ExamItem[]).length === 0 ? (
              <tr>
                <td colSpan={activeSubTab === 'active' ? 9 : 8} className="px-6 py-12 text-center text-slate-500">
                  <ClipboardList className="mx-auto text-slate-300 mb-3" size={32} />
                  <div className="font-medium">No {activeSubTab === 'active' ? 'scheduled examinations' : 'examination drafts'} found.</div>
                </td>
              </tr>
            ) : (
              (paginatedData as ExamItem[]).map((exam) => (
                <tr key={exam.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-semibold text-slate-900">{exam.name}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{exam.type}</div>
                  </td>
                  <td className="px-6 py-4 text-slate-700">{exam.subject}</td>
                  <td className="px-6 py-4 text-slate-600">{exam.batch}</td>
                  <td className="px-6 py-4 text-slate-600">
                    {exam.examDate}
                    {exam.startTime && <div className="text-xs text-slate-400 mt-0.5">{exam.startTime}</div>}
                  </td>
                  <td className="px-6 py-4 text-slate-600">
                    {exam.totalMarks} <span className="text-xs text-slate-400">(Pass: {exam.passingMarks})</span>
                  </td>
                  {activeSubTab === 'active' && (
                    <td className="px-6 py-4 text-slate-600">
                      {exam.average || <span className="text-slate-400 italic">Not available</span>}
                    </td>
                  )}
                  <td className="px-6 py-4">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(exam.status)}`}>
                      {exam.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => setShowExamDetails(exam)} title="View Details" className="cursor-pointer hover:bg-slate-100">
                        <Eye className="w-4 h-4 text-slate-500" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => { setExamForm({ ...exam }); setShowExamForm(true); }} title="Edit Exam" className="cursor-pointer hover:bg-blue-50">
                        <Edit3 className="w-4 h-4 text-blue-600" />
                      </Button>
                      {exam.status === 'Scheduled' && (
                        <Button variant="ghost" size="sm" onClick={() => handleCancelExam(exam.id)} title="Cancel Exam" className="cursor-pointer hover:bg-amber-50">
                          <XCircle className="w-4 h-4 text-amber-600" />
                        </Button>
                      )}
                      {exam.status === 'Draft' && (
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteExam(exam.id)} title="Delete Draft" className="cursor-pointer hover:bg-red-50">
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </Table>
        )}

        {currentData.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={currentData.length}
            pageSize={itemsPerPage}
            onPageChange={setCurrentPage}
          />
        )}
      </div>

      {/* Exam Details Modal */}
      {showExamDetails && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setShowExamDetails(null)}>
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-slate-900">{showExamDetails.name}</h3>
              <button onClick={() => setShowExamDetails(null)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <XCircle size={22} />
              </button>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Type</span><span className="font-medium">{showExamDetails.type}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Subject</span><span className="font-medium">{showExamDetails.subject}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Target Batch</span><span className="font-medium">{showExamDetails.batch}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Exam Date</span><span className="font-medium">{showExamDetails.examDate} {showExamDetails.startTime || ''}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Marks</span><span className="font-medium">{showExamDetails.totalMarks} (Pass: {showExamDetails.passingMarks})</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Status</span><span className="font-medium">{showExamDetails.status}</span></div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              {showExamDetails.status === 'Scheduled' && (
                <Button variant="secondary" className="cursor-pointer" onClick={() => handleCancelExam(showExamDetails.id)}>
                  Cancel Exam
                </Button>
              )}
              <Button
                className="bg-blue-600 text-white cursor-pointer"
                onClick={() => { setExamForm({ ...showExamDetails }); setShowExamDetails(null); setShowExamForm(true); }}
              >
                Edit Exam
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};